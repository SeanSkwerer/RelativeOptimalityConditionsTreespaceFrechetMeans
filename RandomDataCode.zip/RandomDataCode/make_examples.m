
% directories
dirRoot='/Users/Sean/Dropbox (Personal)/'
dirHome=[dirRoot,'FM/data/'];
dirWork=[dirHome,'fm/'];
% add directories to path
% /Users/sean/Dropbox (Personal)/MATLAB/Trees/phylo normal/random_augment.m
addpath(strcat(dirRoot,'/MATLAB/Trees/phylo normal'))
addpath(strcat(dirRoot,'/MATLAB/Trees/preprocessing'))
addpath(strcat(dirRoot,'/MATLAB/Trees/preprocessing/binary'))
addpath(dirWork)
addpath(dirHome)

%settings id
settingID=1;

% set rand number state
seed=9872134;
% rng(seed)

% compute distances
distances=false;


% number of replications
n_rep=1;

% sample size
n=100;

% number of leafs
r=60;


% parameters for edge length distribution
shift=0.00001-1;
scale=10;
k_collapse=11;

% parameter for randpn -- isotropic jump magnitude
sd=0.02;

dirSave0=[dirWork,'leafs',num2str(r),'/'];
dirSave=[dirSave0,'settings',num2str(settingID),'/'];
if ~exist(dirSave0,'dir')
    mkdir(dirSave0);
end
if ~exist(dirSave,'dir')
    mkdir(dirSave);
end

save([dirSave,'settings.mat'],'sd','r','shift','scale','settingID','n','seed','n_rep','k_collapse')
f=fopen([dirSave,'settings.txt'],'w');
fprintf(f,'sd %f\n',sd);
fprintf(f,'r %f\n',r);
fprintf(f,'shift %f\n',shift);
fprintf(f,'scale %f\n',scale);
fprintf(f,'settingID %f\n',settingID);
fprintf(f,'n %f\n',n);
fprintf(f,'seed %f\n',seed);
fprintf(f,'k_collapse %f\n',k_collapse);
fprintf(f,'sample size %f\n',n);
fprintf(f,'number of replications %f',n_rep);
fclose(f);

for rep=1:n_rep
    display(rep);
    svstr=[dirSave,'ex',num2str(rep)];
    svmat=[svstr,'.mat'];
    svt0=[svstr,'t0','.tpk'];
    svt=[svstr,'t','.tpk'];
    T0=randTfull(r,shift,scale);
    display(T0.L)
    T0=random_collapse(T0,k_collapse);
    [T0.E,T0.L]=treestruct2bin(T0);
    T0=bin2numeric(T0);
    savetree2(T0,svt0);
    clear T
    for i = 1:n
        if mod(i,100) == 0
            display(i);
        end
        opt.stdev=sd;
        T(i)=randpn(T0,opt);
        [T(i).E,T(i).L]=treestruct2bin(T(i));
        T(i)=bin2numeric(T(i));
    end
    savetree2(T,svt);
end
