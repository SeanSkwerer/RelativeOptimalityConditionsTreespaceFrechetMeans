function savetree(T,savestr,options)

% options
append=false;
if nargin>2
    if isfield(options,'append')
        if options.append==true
            append=true;
        end
    end
end

% open file
if append
    f=fopen(savestr,'a');
else
    f=fopen(savestr,'w');
end

% print data
n=length(T);
if n==1
    fprintf(f,'%s\n',num2str(T.numeric));
    fprintf(f,'%s',num2str(T.x));
else
    for i=1:(n-1)
        fprintf(f,'%s\n',num2str(T(i).numeric));
        fprintf(f,'%s\n',num2str(T(i).x));
    end
    fprintf(f,'%s\n',num2str(T(n).numeric));
    fprintf(f,'%s',num2str(T(n).x));
end
fclose(f);