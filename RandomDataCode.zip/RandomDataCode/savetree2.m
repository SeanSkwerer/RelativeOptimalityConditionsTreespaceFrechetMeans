function savetree2(T,savestr,options)

% options
append=false;
if nargin>2
    if isfield(options,'append')
        if options.append==true
            append=true;
        end
    end
end

% open file
if append
    f=fopen(savestr,'a');
else
    f=fopen(savestr,'w');
end

% print data
n=length(T);
if n==1
    fprintf(f,'%d ',round(T.numeric'));
    fprintf(f,'\n');
    fprintf(f,'%f ',T.x');
else
    for i=1:(n-1)
        fprintf(f,'%d ',round(T(i).numeric'));
        fprintf(f,'\n');
        fprintf(f,'%f ',T(i).x');
        fprintf(f,'\n');
    end
    fprintf(f,'%d ',round(T(n).numeric'));
    fprintf(f,'\n');
    fprintf(f,'%f ',T(n).x');
end
fclose(f);