function [Label,Parent,Length,Landmark] = read_tree(file)
%% read truncated tree from text file
fid = fopen(file,'r');
tline = fgetl(fid); % header
tline = fgetl(fid); % first line of data
i = 1;
while tline ~= -1
    [a,b] = strtok(tline,' ');
    Label(1,i) = str2double(a);
    [a,b] = strtok(b,' ');
    Parent(1,i) = str2double(a);
    [a,b] = strtok(b,' ');
    Length(1,i) = str2double(a);
    Landmark(1,i) = str2double(b);
    i = i+1;
    tline = fgetl(fid);
end
fclose(fid);

