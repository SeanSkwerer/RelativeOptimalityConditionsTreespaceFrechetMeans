function outstruct = read_and_visualize3Dhelper(name1,name2l,name2r)

ARTERY_TUBES = [];
Label=[];
Parent=[];Childrens=[];total_length=[];subtree_length=[];total_dist_lm=[];
%% read artery tubes
ARTERY_TUBES = cell(4,5);
for tree_index = 1:4
    root_counter = 0;
    clear X Y Z R head
    if tree_index == 1
        filename = strcat(name1,'\aca.tre');
    elseif tree_index == 2
        filename = strcat(name1,'\lca.tre');
    elseif tree_index == 3
        filename = strcat(name1,'\pca.tre');
    else
        filename = strcat(name1,'\rca.tre');
    end
    
    fin = fopen(filename,'r');
    i=1;
    while 1==1
        line = fgetl(fin);
        if line < 0
            break;
        end;
        if strcmp(strtok(line,':'),'VoxelSize') == 1
            [a,b] = strtok(line,' '); %a: 'VoxelSize' b:x y z
            [a,b] = strtok(b,' ');
            vox_x = str2num(a);
            [a,b] = strtok(b,' '); %a: y  b:z
            vox_y = str2num(a);
            vox_z = str2num(b);
        end
        if strcmp(strtok(line,':'),'ID')==1
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            % head(i,1) = ID number
            % head(i,2) = parent number if segment i is a child
            %             -1 if segment i is a root
            % head(i,3) = attachment point on parent segment
            %             -1 if segment i is a root
            % head(i,4:7) = the color of segment i
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            [a,b] = strtok(line,' '); % first of head i takes the ID number
            head(i,1) = str2num(b);
            line = fgetl(fin);% now line has type
            line=fgetl(fin);%%now line has artery
            line=fgetl(fin);%%now it has treetype (either child or root)
            [a,b] = strtok(line,':');
            if strcmp(b,': child')==1
                line=fgetl(fin); %now we have the parent
                [a,b] = strtok(line,' ');
                head(i,2) = str2num(b); %take the parent number to 2
                line=fgetl(fin); %now we have the attachment point
                [a,b] = strtok(line,' ');
                head(i,3) = str2num(b); %take the attachment point number to 3
                if head(i,3) == 0  % some att. pts are zero !!!???
                    head(i,3) = 1;
                end
            else  %%then we have a root for this tree (l,r,a or p)
                root_counter = root_counter +1;
                head(i,2)= -1 ;% no parent
                head(i,3)= -1;% no att. pt.
            end
            line=fgetl(fin); %now we have the color
            [a,b] = strtok(line,' ');
            head(i,4:7) = str2num(b); %take the color to 4
            
            line=fgetl(fin); %the pointdim line
            line=fgetl(fin); %NPoints
            [a,b] = strtok(line,' ');
            Npoints = str2num(b);
            line=fgetl(fin);  %%%Points header
            % X{i}(1) = head(i,1);
            % Y{i}(1) = head(i,1);
            % Z{i}(1) = head(i,1);
            % R{i}(1) = head(i,1);
            % for j=2:Npoints+1
            for j = 1:Npoints
                line=fgetl(fin); %now line has the current point
                [a,b] = strtok(line,' '); %% a:x b: y z s
                X{i}(1,j) = str2num(a)*vox_x;
                [a,b] = strtok(b,' '); %%a:y b:z s
                Y{i}(1,j) = str2num(a)*vox_y;
                [a,b] = strtok(b,' '); %%a:z b:s
                Z{i}(1,j) = str2num(a)*vox_z;
                R{i}(j)=str2num(b);
                if R{i}(1,j)>10 keyboard; end;
            end;
            
            i=i+1;
        end
        
    end
    ARTERY_TUBES{tree_index,1} = head;
    ARTERY_TUBES{tree_index,2} = X;
    ARTERY_TUBES{tree_index,3} = Y;
    ARTERY_TUBES{tree_index,4} = Z;
    ARTERY_TUBES{tree_index,5} = R;
end
fclose(fin);

%% Extract Landmarks
% alternative registry
filename = name2l;

f = fopen(filename,'r');
i = 0;
while 1==1
    line=fgetl(f);
    if line < 0
        break;
    end;
    i = i+1;
    [a,b] = strtok(line,' ');
    C_left(i,1) = str2num(a); % x position of landmark
    [a,b] = strtok(b,' ');
    C_left(i,2) = str2num(a); % y position of landmark
    C_left(i,3) = str2num(b);% z position of landmark
end
fclose(f);
n_left = i;
filename = name2r;
%filename = 'C:\Users\Sean\My Research\tree space project\DATA\Landmark_Cortical_Surface_data_alternative\NormalA-025\surf\right.registered.lpts';
f = fopen(filename,'r');
i = 0;
while 1==1
    line=fgetl(f);
    if line < 0
        break;
    end;
    i = i+1;
    [a,b] = strtok(line,' ');
    C_right(i,1) = str2num(a); % x position of landmark
    [a,b] = strtok(b,' ');
    C_right(i,2) = str2num(a); % y position of landmark
    C_right(i,3) = str2num(b);% z position of landmark
end
fclose(f);
n_right = i;

%% find landmark attachment points
% % %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% % find the point on the tree that is closest to each coordinate C(:,i)
% % %%%%%%%%
% % I(i,1) = the index of the tree (anterior=1, posterior=2, right=3, left=4)
% % I(i,2) = the index of the branch that contains the point closest
% %         to the landmark at C(i,:)
% % I(i,3) = the index in the branch tree_3D_r{2,I(i,1)} of the point
% %         closest to the landmark at C(i,:)
% % I(i,4:6) = (x,y,z) location on the the tree closest to landmark i
% % %%%%%%
% % Landmarks from the left hemisphere
I_left = zeros(n_left,2);
m = 0;
for i = 1:n_left
    % fix rotation
    x1 = -C_left(i,1); % multiply by -1 to fix rotation
    y1 = -C_left(i,2); % ""
    z1 = C_left(i,3); % coordinate good here!
    best_distance = 1000000;
    best_branch = 0;
    best_index = 0;
    for j = 1:4
        n = size(ARTERY_TUBES{j,2},2);
        for k = 2:n
            x = ARTERY_TUBES{j,2}{k}(1,:);
            y = ARTERY_TUBES{j,3}{k}(1,:);
            z = ARTERY_TUBES{j,4}{k}(1,:);
            % use squared distance to save computational time
            [current_distance, current_index] = min( (x-x1).^2 + (y-y1).^2 + (z-z1).^2 );
            if current_distance < best_distance
                best_distance = current_distance;
                best_index = current_index;
                best_branch = k;
                best_tree = j;
                best_location = [x(best_index),y(best_index),z(best_index)];
                best_branch_ID = ARTERY_TUBES{j,1}(k,1);
            end
        end
        if best_branch == 0
            'error: somehow no point closest ???'
        end
        I_left(i,1) = best_tree;
        I_left(i,2) = best_branch;
        I_left(i,3) = best_index;
        I_left(i,4:6) = best_location;
        I_left(i,7) = best_distance;
        I_left(i,8) = best_branch_ID;
        I_left(i,9) = i; % label
    end
end

% Landmarks from the right hemisphere
I_right = zeros(n_right,2);
m = 0;
for i = 1:n_right
    % fix rotation
    x1 = -C_right(i,1); % multiply by -1 here
    y1 = -C_right(i,2);% "
    z1 = C_right(i,3);% not here
    best_distance = 1000000;
    best_branch = 0;
    best_index = 0;
    for j = 1:4
        n = size(ARTERY_TUBES{j,2},2);
        for k = 2:n
            x = ARTERY_TUBES{j,2}{k}(1,:);
            y = ARTERY_TUBES{j,3}{k}(1,:);
            z = ARTERY_TUBES{j,4}{k}(1,:);
            % use squared distance to save computational time
            [current_distance, current_index] = min( (x-x1).^2 + (y-y1).^2 + (z-z1).^2 );
            if current_distance < best_distance
                best_distance = current_distance;
                best_index = current_index;
                best_branch = k;
                best_tree = j;
                best_location = [x(best_index),y(best_index),z(best_index)];
                best_branch_ID = ARTERY_TUBES{j,1}(k,1);
            end
        end
        if best_branch == 0
            'error: somehow no point closest ???'
        end
        I_right(i,1) = best_tree;
        I_right(i,2) = best_branch;
        I_right(i,3) = best_index;
        I_right(i,4:6) = best_location;
        I_right(i,7) = best_distance;
        I_right(i,8) = best_branch_ID;
        I_right(i,9) = i; %label
    end
end
%%
t = 0;
for i = 1:64
    STOP = false;
    % store the edge between landmark i and it's attachment point on the
    % tree
    t = t+1;
    Label(t,1) = 5;
    Label(t,2) = i;
    Label(t,3) = 1;
    Parent(t,1) = I_left(i,1);
    Parent(t,2) = I_left(i,8);
    Parent(t,3) = I_left(i,3);
    parent_structure = I_left(i,1);
    parent_component = I_left(i,8);
    parent_index = I_left(i,3);
    head = ARTERY_TUBES{parent_structure,1};
    % indicator1:edges with the same structure
    % indicator2: edges with the same structure and component
    % indicator3: edges with the same structure, component and index
    indicator1 = Label(:,1)==parent_structure;
    indicator2 = logical(indicator1.*(Label(:,2)==parent_component));
    indicator3 = logical(indicator2.*(Label(:,3)==parent_index));
    if sum(indicator2)>0
        % have reached a branch already included in the landmark
        % spanning subtree
        STOP = true;
        if sum(indicator3) > 0
            % attaches at the end of some other segment
        elseif sum(Label(indicator2,3) > parent_index) > 0
            % attaches along some edge
            % find edge just above attachment
            temp = Label(indicator2,3);
            %indicator4: indicates edges with the same structure and
            %component located above parent_index
            indicator4 = logical(indicator2.*(Label(:,3) == min(temp(Label(indicator2,3)>parent_index))));
            Parent(indicator4,2) = parent_component;
            Parent(indicator4,3) = parent_index;
            % create new edge
            t = t+1;
            if sum(Label(indicator2,3)<parent_index) > 0
                % there are segments below this on branch
                Parent(t,1) = parent_structure;
                Parent(t,2) = parent_component;
                indicator5 = logical(indicator2.*(Label(:,3)==max(temp(Label(indicator2,3)<parent_index))));
                Parent(t,3) = Label(indicator5,3);
                Label(t,1) = parent_structure;
                Label(t,2) = parent_component;
                Label(t,3) = parent_index;
            else
                % no segments below this on branch
                Label(t,1) = parent_structure;
                Label(t,2) = parent_component;
                Label(t,3) = parent_index;
                old_component = parent_component;
                parent_component = head(head(:,1)==old_component,2);
                parent_index = head(head(:,1) == old_component,3);
                Parent(t,1) = parent_structure;
                Parent(t,2) = parent_component;
                Parent(t,3) = parent_index;
            end
        else % attaches above every segment on this branch
            % create new edge
            t = t+1;
            Parent(t,1) = parent_structure;
            Parent(t,2) = parent_component;
            Parent(t,3) = max(Label(indicator2,3));
            Label(t,1) = parent_structure;
            Label(t,2) = parent_component;
            Label(t,3) = parent_index;
        end
    else
        t = t+1;
        Label(t,1) = parent_structure;
        Label(t,2) = parent_component;
        Label(t,3) = parent_index;
        old_component = parent_component;
        parent_component = head(head(:,1)==old_component,2);
        parent_index = head(head(:,1) == old_component,3);
        Parent(t,1) = parent_structure;
        Parent(t,2) = parent_component;
        Parent(t,3) = parent_index;
    end
    while Parent(t,2) > -1  && ~STOP
        % indicator1:edges with the same structure
        % indicator2: edges with the same structure and component
        % indicator3: edges with the same structure, component and index
        indicator1 = Label(:,1)==parent_structure;
        indicator2 = logical(indicator1.*(Label(:,2)==parent_component));
        indicator3 = logical(indicator2.*(Label(:,3)==parent_index));
        if sum(indicator2)>0
            % have reached a branch already included in the landmark
            % spanning subtree
            STOP = true;
            if sum(indicator3) > 0
                % attaches at the end of some other segment
            elseif sum(Label(indicator2,3) > parent_index) > 0
                % attaches along some edge
                % find edge just above attachment
                temp = Label(indicator2,3);
                indicator4 = logical(indicator2.*(Label(:,3) == min(temp(Label(indicator2,3)>parent_index))));
                Parent(indicator4,2) = parent_component;
                Parent(indicator4,3) = parent_index;
                % create new edge
                t = t+1;
                if sum(Label(indicator2,3)<parent_index) > 0
                    % there are segments below this on branch
                    
                    Parent(t,1) = parent_structure;
                    Parent(t,2) = parent_component;
                    indicator5 = logical(indicator2.*(Label(:,3)==max(temp(Label(indicator2,3)<parent_index))));
                    Parent(t,3) = Label(indicator5,3);
                    
                    Label(t,1) = parent_structure;
                    Label(t,2) = parent_component;
                    Label(t,3) = parent_index;
                else
                    % no segments below this on branch
                    
                    Label(t,1) = parent_structure;
                    Label(t,2) = parent_component;
                    Label(t,3) = parent_index;
                    old_component = parent_component;
                    parent_component = head(head(:,1)==old_component,2);
                    parent_index = head(head(:,1) == old_component,3);
                    Parent(t,1) = parent_structure;
                    Parent(t,2) = parent_component;
                    Parent(t,3) = parent_index;
                end
            else % attaches above every segment on this branch
                t = t+1;
                Parent(t,1) = parent_structure;
                Parent(t,2) = parent_component;
                Parent(t,3) = max(Label(indicator2,3));
                Label(t,1) = parent_structure;
                Label(t,2) = parent_component;
                Label(t,3) = parent_index;
            end
        else
            t = t+1;
            Label(t,1) = parent_structure;
            Label(t,2) = parent_component;
            Label(t,3) = parent_index;
            old_component = parent_component;
            parent_component = head(head(:,1)==old_component,2);
            parent_index = head(head(:,1) == old_component,3);
            Parent(t,1) = parent_structure;
            Parent(t,2) = parent_component;
            Parent(t,3) = parent_index;
        end
    end
end
for i = 1:64
    STOP = false;
    % store the edge between landmark i and it's attachment point on the
    % tree
    t = t+1;
    Label(t,1) = 6;
    Label(t,2) = i;
    Label(t,3) = 1;
    Parent(t,1) = I_right(i,1);
    Parent(t,2) = I_right(i,8);
    Parent(t,3) = I_right(i,3);
    parent_structure = I_right(i,1);
    parent_component = I_right(i,8);
    parent_index = I_right(i,3);
    head = ARTERY_TUBES{parent_structure,1};
    % indicator1:edges with the same structure
    % indicator2: edges with the same structure and component
    % indicator3: edges with the same structure, component and index
    indicator1 = Label(:,1)==parent_structure;
    indicator2 = logical(indicator1.*(Label(:,2)==parent_component));
    indicator3 = logical(indicator2.*(Label(:,3)==parent_index));
    if sum(indicator2)>0
        % have reached a branch already included in the landmark
        % spanning subtree
        STOP = true;
        if sum(indicator3) > 0
            % attaches at the end of some other segment
        elseif sum(Label(indicator2,3) > parent_index) > 0
            % attaches along some edge
            % find edge just above attachment
            temp = Label(indicator2,3);
            %indicator4: indicates edges with the same structure and
            %component located above parent_index
            indicator4 = logical(indicator2.* (Label(:,3) == min(temp (temp >parent_index) )));
            Parent(indicator4,2) = parent_component;
            Parent(indicator4,3) = parent_index;
            % create new edge
            t = t+1;
            if sum(Label(indicator2,3)<parent_index) > 0
                % there are segments below this on branch
                Parent(t,1) = parent_structure;
                Parent(t,2) = parent_component;
                indicator5 = logical(indicator2.*(Label(:,3)==max(temp(temp<parent_index))));
                Parent(t,3) = Label(indicator5,3);
                Label(t,1) = parent_structure;
                Label(t,2) = parent_component;
                Label(t,3) = parent_index;
            else
                % no segments below this on branch
                Label(t,1) = parent_structure;
                Label(t,2) = parent_component;
                Label(t,3) = parent_index;
                old_component = parent_component;
                parent_component = head(head(:,1)==old_component,2);
                parent_index = head(head(:,1) == old_component,3);
                Parent(t,1) = parent_structure;
                Parent(t,2) = parent_component;
                Parent(t,3) = parent_index;
            end
        else % attaches above every segment on this branch
            % create new edge
            t = t+1;
            Parent(t,1) = parent_structure;
            Parent(t,2) = parent_component;
            Parent(t,3) = max(Label(indicator2,3));
            Label(t,1) = parent_structure;
            Label(t,2) = parent_component;
            Label(t,3) = parent_index;
        end
    else
        t = t+1;
        Label(t,1) = parent_structure;
        Label(t,2) = parent_component;
        Label(t,3) = parent_index;
        old_component = parent_component;
        parent_component = head(head(:,1)==old_component,2);
        parent_index = head(head(:,1) == old_component,3);
        Parent(t,1) = parent_structure;
        Parent(t,2) = parent_component;
        Parent(t,3) = parent_index;
    end
    while Parent(t,2) > -1  && ~STOP
        % indicator1:edges with the same structure
        % indicator2: edges with the same structure and component
        % indicator3: edges with the same structure, component and index
        indicator1 = Label(:,1)==parent_structure;
        indicator2 = logical(indicator1.*(Label(:,2)==parent_component));
        indicator3 = logical(indicator2.*(Label(:,3)==parent_index));
        if sum(indicator2)>0
            % have reached a branch already included in the landmark
            % spanning subtree
            STOP = true;
            if sum(indicator3) > 0
                % attaches at the end of some other segment
            elseif sum(Label(indicator2,3) > parent_index) > 0
                % attaches along some edge
                % find edge just above attachment
                temp = Label(indicator2,3);
                indicator4 = logical(indicator2.*(Label(:,3) == min(temp( temp >parent_index))) );
                Parent(indicator4,2) = parent_component;
                Parent(indicator4,3) = parent_index;
                % create new edge
                t = t+1;
                if sum(Label(indicator2,3)<parent_index) > 0
                    % there are segments below this on branch
                    
                    Parent(t,1) = parent_structure;
                    Parent(t,2) = parent_component;
                    indicator5 = logical(indicator2.*(Label(:,3)==max(temp(temp<parent_index))));
                    Parent(t,3) = Label(indicator5,3);
                    
                    Label(t,1) = parent_structure;
                    Label(t,2) = parent_component;
                    Label(t,3) = parent_index;
                else
                    % no segments below this on branch
                    
                    Label(t,1) = parent_structure;
                    Label(t,2) = parent_component;
                    Label(t,3) = parent_index;
                    old_component = parent_component;
                    parent_component = head(head(:,1)==old_component,2);
                    parent_index = head(head(:,1) == old_component,3);
                    Parent(t,1) = parent_structure;
                    Parent(t,2) = parent_component;
                    Parent(t,3) = parent_index;
                end
            else % attaches above every segment on this branch
                t = t+1;
                Parent(t,1) = parent_structure;
                Parent(t,2) = parent_component;
                Parent(t,3) = max(Label(indicator2,3));
                Label(t,1) = parent_structure;
                Label(t,2) = parent_component;
                Label(t,3) = parent_index;
            end
        else
            t = t+1;
            Label(t,1) = parent_structure;
            Label(t,2) = parent_component;
            Label(t,3) = parent_index;
            old_component = parent_component;
            parent_component = head(head(:,1)==old_component,2);
            parent_index = head(head(:,1) == old_component,3);
            Parent(t,1) = parent_structure;
            Parent(t,2) = parent_component;
            Parent(t,3) = parent_index;
        end
    end
end

% these subtrees stop at the end of the trees they start in
% they need ot be connected to super root
tree_roots = Label(Parent(:,2) == -1,:);
location_root = zeros(1,3);
for i = 1:size(tree_roots,1)
    current_structure = tree_roots(i,1);
    current_component = tree_roots(i,2);
    current_index = tree_roots(i,3);
    indicator =  logical((Label(:,1)==current_structure).*(Label(:,2)==current_component).*(Label(:,3)==current_index));
    head = ARTERY_TUBES{current_structure,1};
    X = ARTERY_TUBES{current_structure,2};
    Y = ARTERY_TUBES{current_structure,3};
    Z = ARTERY_TUBES{current_structure,4};
    indicator = head(:,2)==-1;
    x = X{indicator};
    y = Y{indicator};
    z = Z{indicator};
    location_root = location_root+[x(1),y(1),z(1)]/size(tree_roots,1);
end



        %% 3-D visualization outstruct
        

        
        outstruct.ARTERY_TUBES = ARTERY_TUBES;
        outstruct.Label = Label;
        outstruct.Parent = Parent;
        outstruct.C_left = C_left;
        outstruct.C_right = C_right;
        outstruct.I_left = I_left;
        outstruct.I_right = I_right;
        
    
end
%% Subfunctions
function AL = arclength(x,y,z)
% Input: x,y,z are ordered coordinates (1 by n) vectors
%        along a curve
%        i.e. a 3D plot of x,y,z would look like that curve

% Output: the approximate length of that curve

n = length(x);% == length(y) == length(z)
al = 0;
for i = 1:(n-1)
    x1 = x(i); y1 = y(i); z1 = z(i);
    x2 = x(i+1); y2 = y(i+1); z2 = z(i+1);
    al = al + sqrt((x2-x1)^2+(y2-y1)^2+(z2-z1)^2);
end
AL = al;
end

function  x = compute_x_coordinates(i,Childrens,Label,Leaf_left2right_label)
if Label(i,1) == 5 || Label(i,1) == 6
    x = zeros(size(Label,1),1); % create a vector of zeros with a
    % element for each leaf in the tree
    x(i) =  Leaf_left2right_label(i); % this case occurs when i is a leaf
    % assigns x_coordinate of i as the
    % integer k such that i is the k'th
    % leaf in the left to right ordering
    % of leafs in the tree embedding;
else
    x = zeros(size(Label,1),1);
    x_i = 0;
    if size(Childrens{i},2) > 1
        childrens = Childrens{i};
        k = size(childrens,1);
        for j = 1:k
            current_structure = childrens(j,1);
            current_component = childrens(j,2);
            current_index = childrens(j,3);
            indicator = logical((Label(:,1)==current_structure).*(Label(:,2)==current_component).*(Label(:,3)==current_index));
            x = x + compute_x_coordinates(indicator,Childrens,Label,Leaf_left2right_label);
            x_i = x_i + x(indicator)/k;
        end
    end
    x(i) = x_i;
    
end



end





