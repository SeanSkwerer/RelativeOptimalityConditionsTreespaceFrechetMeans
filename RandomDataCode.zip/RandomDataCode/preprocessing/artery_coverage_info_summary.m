% make ScatPlotSM to summarize landmark subtree coverage data

% for each subject
% (1) compute total length of arteries 
% (2) compute length of landmark subtree
% (3) compute total landmark to tree distance

% order by age of subject


[S,I]=sort(artery_coverage_info(2,:),2);
aci_sorted = artery_coverage_info(:,I);
data = aci_sorted(3:5,:);
mdir = eye(3);

paramstruct = struct('irecenter',false,'labelcellstr',{{'Total Artery Length';'Landmark Subtree Length';'Landmark to Tree Distanc'}});

scatplotSM(data,mdir,paramstruct)