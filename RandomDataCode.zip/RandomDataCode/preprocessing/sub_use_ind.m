subject_use_indicator = zeros(1,109);
for i = 1:109
    if i < 10
    filename = strcat('C:\Users\Sean\Documents\Data\Trees\128 leaf trees\NormalA-00',num2str(i),'.txt');
    elseif i < 100
       filename  = strcat('C:\Users\Sean\Documents\Data\Trees\128 leaf trees\NormalA-0',num2str(i),'.txt'); 
    else
        filename = strcat('C:\Users\Sean\Documents\Data\Trees\128 leaf trees\NormalA-',num2str(i),'.txt');
    end
    if exist(filename)==2
        subject_use_indicator(i) = 1;
    end
end
subject_use_indicator = logical(subject_use_indicator);
clear filename i