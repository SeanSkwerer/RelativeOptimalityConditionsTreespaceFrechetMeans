% add a root to the 128 leaf brain trees
load 128leaf_tree_binary_LMv2.mat
for i = 1:67
    E = F_binary{i};
    E = [zeros(size(E,1),1),E];
    L = [L_F_binary{i}];
    Forest.T(i).E = E;
    Forest.T(i).L = L;
end
save('DataSet5.mat','Forest')