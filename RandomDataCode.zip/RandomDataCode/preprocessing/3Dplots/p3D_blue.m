
function h = p3D_blue(instruct)
ARTERY_TUBES = instruct.ARTERY_TUBES;
Label = instruct.Label;
Parent = instruct.Parent;
C_right = instruct.C_right;
C_left = instruct.C_left;
I_right = instruct.I_right;
I_left = instruct.I_left;

hold on
for tree = 1:4
    head = ARTERY_TUBES{tree,1};
    X = ARTERY_TUBES{tree,2};
    Y = ARTERY_TUBES{tree,3};
    Z = ARTERY_TUBES{tree,4};
    for i = 1:length(X)
        x = X{i}; y = Y{i}; z = Z{i};
        %                         m = length(x);
        %                         x = x(2:m); y = y(2:m); z = z(2:m);
        plot3(x,y,z,'blue')
        % plot from child to parent
        parent = head(i,2);
        if parent > 0
            x_att = X{head(:,1)==parent}(head(i,3));
            y_att = Y{head(:,1)==parent}(head(i,3));
            z_att = Z{head(:,1)==parent}(head(i,3));
            plot3([x_att,x(1)],[y_att,y(1)],[z_att,z(1)],'blue')
        end
    end
end


for i = 1:length(Label)
    clear x y z
    if Label(i,1) == 5 || Label(i,1) ==6
        % landmark to tree edge
        if Label(i,1) == 5
        else
        end
    elseif Parent(i,2) == -1
    elseif Label(i,2) == Parent(i,2)
        
    elseif Label(i,2) ~= Parent(i,2)
        % inter branch edge
        head = ARTERY_TUBES{Label(i,1),1};
        X = ARTERY_TUBES{Label(i,1),2};
        Y = ARTERY_TUBES{Label(i,1),3};
        Z = ARTERY_TUBES{Label(i,1),4};
        indicator = head(:,1)==Label(i,2);
        x = X{indicator};
        y = Y{indicator};
        z = Z{indicator};
        indicator = head(:,1)==Parent(i,2);
        x2 = X{indicator};
        y2 = Y{indicator};
        z2 = Z{indicator};
        a_x = x2(Parent(i,3));
        a_y = y2(Parent(i,3));
        a_z = z2(Parent(i,3));
        plot3([a_x,x(1:Label(i,3))],[a_y,y(1:Label(i,3))],[a_z,z(1:Label(i,3))],'color','blue');
    end
end
hold off
end