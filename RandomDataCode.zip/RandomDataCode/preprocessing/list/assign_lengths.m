function L1 = assign_lengths(S,L,S1)
% input:
% S is a set of splits with lengths L
% S1 is another set of splits

%output:
% L1(i) is the length of S1(i) as given by S and L for common edges
% otherwise L1(i) is zero
n = size(S,2);
n1 = size(S1,2);
L1 = zeros(1,n1);
for i = 1:n1
    found = false;
    for j = 1:n
        if size(S{1,j}) == size(S1{1,i})
            if sum(S{1,j}==S1{1,i}) == numel(S{1,j})
                if ~isempty(S{1,j})
                    found = true;
                    index = j;
                end
            end
        end
        if found == true
            L1(1,i) = L(index);
        else
            L1(1,i) = 0;
        end
    end
end