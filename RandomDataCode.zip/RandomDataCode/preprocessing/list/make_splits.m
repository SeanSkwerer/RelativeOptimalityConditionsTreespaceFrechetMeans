function [sigma,L,sigma_unordered] = make_splits(Label,Parent,Length,Landmark)
%import_tree_data;
n = size(Label,2);
sigma_unordered = cell(2,n);
for i = 1:n
    label = Label(i);
    s = get_split(label,Label,Parent,Landmark);
    sigma_unordered{1,i} = s{1,1};
    sigma_unordered{2,i} = s{1,2};
end
sigma = splits_merge_sort(sigma_unordered);


L = assign_lengths(sigma_unordered,Length,sigma);

%%%%%%%%%%% subfunctions %%%%%%%%%%%%%%%%%%
function s = get_split(label,Label,Parent,Landmark)
LIST = [Label(Parent==label) 10000000]; % 10000000 is a dummy element
k = length(LIST);
leafs = 10000000;
if k > 1
while k > 1
    l = LIST(1);
    LIST = LIST(2:k);
    lm = Landmark(Label == l);
    if lm == -1
        LIST = [Label(Parent == l) LIST];
    else
        leafs = union(leafs,lm);
    end
    k = length(LIST);
end
else
   lm = Landmark(Label == label);
   leafs = lm; 
end
s{1,1} = setdiff(leafs,10000000);
s{1,2} = setdiff(1:128,leafs);