function [T] = maketree(S)
% Input: S is a 2 by k cell array of splits
%        !!!Assumption every split in S is compatible!!! S is a valid tree!
% Output: T is a 5 by k cell array
%         T{1:2,i} is the split S{1:2,i}
%         T{3:4,i} is the split of the edge at the tail of S{1:2,i}
%         'parent'
%         T{5,i} is a cell array of the splits of the edges at the head
%         of S{1:2,i} 'children'

% The data structure of a set of splits (ie  S) has the properties
%  (i) 2 by k cell array
%      in which the 1st row of cells contains leafs in the subtree
%      rooted at the head of that edge and the second contains 
%      the complement of that.
%  (ii) the columns of the array are sorted by size (small to large) and ordinality
%       (small to large) of the 1st row.
%  (iii) the contents of each cell (ie S{1,4}) is the numerally SORTED leaf labels
%        of the leafs on that side of the split
% These properties make finding the 'parent' of an edge easier.
% The parent of an edge is the one with the smallest subtree sided split
% that contains all the leafs in the subtree sided split of that edge.
% Maintaining properties (i),(ii),(iii) means that an incremental search
% starting at i+1 and stopping at the first subtree sided split that
% contains the subtree sided split of i is the parent of i.


n = length(S);
T = cell(5,n);


% puts the splits into T
% redundent storage of information probably unnessary
% but this way the original splits are contained in the same
% data structure parrallel to their parents and children.
for i = 1:n
   T{1,i} = S{1,i};
   T{2,i} = S{2,i};
end

% find the parent
i = 0;
while i<n
    i = i+1;
    found_parent = false;
    j = i;
    while found_parent == false && j<n
        j = j+1;
        if size(intersect(S{1,i},S{1,j}))==size(S{1,i})
            if sum(intersect(S{1,i},S{1,j}) == S{1,i})==numel(S{1,i})
                found_parent = true;
                T{3,i} = S{1,j};
                T{4,i} = S{2,j};
            end
        end
    end
    if found_parent == false
        T{3,i} = [];
        T{4,i} = [];
    end
end


% find the children
i = n+1;
while i>=2
    i = i - 1;
    k = 0;
    children_of_i = cell(1);
    if i > 1
        for j = 1:(i-1)
            if numel(T{3,j}) == numel(S{1,i}) 
                if sum(T{3,j} == S{1,i})==numel(T{3,j})
                    k = k+1;
                    children_of_i{1,k} = S{1,j};
                    children_of_i{2,k} = S{2,j};
                end
            end
        end
        T{5,i} = children_of_i;
    else % i = 1 can't have any children
        T{5,i} = children_of_i;
    end
end
end

