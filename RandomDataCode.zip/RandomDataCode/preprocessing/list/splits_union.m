function S = splits_union(S1,S2)
% Input: S1 is a set of splits on N leaf nodes
%        S2 is a set of splits on N leaf nodes

% Output: S is the union of S1 and S2
%         

% The data structure of a set of splits (ie S1,S2 or S) has the properties
%  (i) 2 by k cell array
%      in which the 1st row of cells contains leafs in the subtree
%      rooted at the head of that edge and the second contains 
%      the complement of that.
%  (ii) the columns of the array are sorted by size and ordinality
%       of the 1st row.
%  (iii) the contents of each cell (ie S{1,4}) is the numerally SORTED leaf labels
%        of the leafs on that side of the split



%initialize
n_1 = size(S1,2);
n_2 = size(S2,2);

i_1 = 1;
i_2 = 1;
n = 1;
if numel(S1{1,i_1}) < numel(S2{1,i_2})
    S{1,n} = S1{1,i_1};
    S{2,n} = S1{2,i_1};
    i_1 = i_1 +1;
elseif numel(S1{1,i_1}) > numel(S2{1,i_2})
    S{1,n} = S2{1,i_2};
    S{2,n} = S2{2,i_2};
    i_2 = i_2 +1;
else % numel(S1{1,i_1}) == numel(S2{1,i_2})
    if  S1{1,i_1} == S2{1,i_2}
        S{1,n} = S1{1,i_1};
        S{2,n} = S1{2,i_1};
        i_1 = i_1 + 1;
        i_2 = i_2 + 1;
    elseif sum(S1{1,i_1} <= S2{1,i_2}) == numel(S1{1,i_1})
        S{1,n} = S1{1,i_1};
        S{2,n} = S1{2,i_1};
        i_1 = i_1 + 1;
    else%  sum(S1{1,i_1} >= S2{1,i_2}) == numel(S1{1,i_1})
        S{1,n} = S2{1,i_2};
        S{2,n} = S2{2,i_2};
        i_2 = i_2+1;
    end 
end
% loop
while i_1 <= n_1 || i_2 <= n_2
    new = true;
   if i_1 <= n_1 && i_2 <= n_2
       if numel(S1{1,i_1}) < numel(S2{1,i_2})
           for j = 1:n
               if numel(S{1,j}) == numel(S1{1,i_1})
                   if S{1,j} == S1{1,i_1}
                       new = false;
                   end
               end
           end
           if new == true
               n = n+1;
               S{1,n} = S1{1,i_1};
               S{2,n} = S1{2,i_1};
           end
           i_1 = i_1 +1;
       elseif numel(S1{1,i_1}) > numel(S2{1,i_2})
           for j = 1:n
               if numel(S{1,j}) == numel(S2{1,i_2})
                   if S{1,j} == S2{1,i_2}
                       new = false;
                   end
               end
           end
           if new == true
               n = n+1;
               S{1,n} = S2{1,i_2};
               S{2,n} = S2{2,i_2};
           end
           i_2 = i_2 +1;    
       else% numel(S1{1,i_1}) == numel(S2{1,i_2})
           if  S1{1,i_1} == S2{1,i_2} 
               for j = 1:n
                   if numel(S{1,j}) == numel(S1{1,i_1})
                       if S{1,j} == S1{1,i_1}
                           new = false;
                       end
                   end
               end
               if new == true
                   n = n + 1;
                   S{1,n} = S1{1,i_1};
                   S{2,n} = S1{2,i_1};
               end
               i_1 = i_1 + 1;
               i_2 = i_2 + 1;
               
           elseif sum(S1{1,i_1} <= S2{1,i_2}) == numel(S1{1,i_1})
               for j = 1:n
                   if numel(S{1,j}) == numel(S1{1,i_1})
                       if S{1,j} == S1{1,i_1}
                           new = false;
                       end
                   end
               end
               if new == true
                   n = n + 1;
                   S{1,n} = S1{1,i_1};
                   S{2,n} = S1{2,i_1};
               end
               i_1 = i_1 + 1;
           else % sum(S1{1,i_1} >= S2{1,i_2}) == numel(S1{1,i_1})
               for j = 1:n
                   if numel(S{1,j}) == numel(S2{1,i_2})
                       if S{1,j} == S2{1,i_2}
                           new = false;
                       end
                   end
               end
               if new == true
                   n = n+1;
                   S{1,n} = S2{1,i_2};
                   S{2,n} = S2{2,i_2};
               end
               i_2 = i_2+1;
               
           end
       end

   elseif i_1 <= n_1
       for j = 1:n
           if numel(S{1,j}) == numel(S1{1,i_1})
               if S{1,j} == S1{1,i_1}
                   new = false;
               end
           end
       end
       if new == true
           n = n+1;
           S{1,n} = S1{1,i_1};
           S{2,n} = S1{2,i_1};
       end
       i_1 = i_1 +1;
   else % i_2 <= n_2
       for j = 1:n
           if numel(S{1,j}) == numel(S2{1,i_2})
               if S{1,j} == S2{1,i_2}
                   new = false;
               end
           end
       end
       if new == true
           n = n+1;
           S{1,n} = S2{1,i_2};
           S{2,n} = S2{2,i_2};
       end
       i_2 = i_2+1;
   end
end