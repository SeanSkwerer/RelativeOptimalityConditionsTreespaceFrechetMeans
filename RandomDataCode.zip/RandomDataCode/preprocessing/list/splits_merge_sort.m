function S = splits_merge_sort(A)
%input:
% A is a cell array of splits
% A{1,i} is the leafs of the subtree rooted at i
% A{2,i} is all other leafs including the root leaf
% the entries of A are in no particular order i.e. they are 
% unsorted

% output:
% S is a splits list
% i.e. S is the splits listed in A sorted.


n = size(A,2);
for i = 1:n
    % the cell array 'current' is initialize as a collection of sets of
    % splits each containing one split. 
    current{1,i} = {A{1,i};A{2,i}};
end
m = size(current,2);
while m > 1
    % in each iteration of this loop adjacent elements of 'current' are
    % merged using 'splits_union()' and the property that every element of 
    % 'current' is a splits list is maintained.
    % the loop terminates when current contain a single element.
    %
    if m/2 == floor(m/2)
        for i = 1:(m/2)
            new{1,i} = splits_union(current{1,2*i-1},current{1,2*i});
        end
    else
        for i = 1:(m-1)/2
            new{1,i} = splits_union(current{1,2*i-1},current{1,2*i});
        end
        new{(m+1)/2} = current{m};
    end
    current = new;
    clear new;
    m = size(current,2);
end
S = current{1,1};