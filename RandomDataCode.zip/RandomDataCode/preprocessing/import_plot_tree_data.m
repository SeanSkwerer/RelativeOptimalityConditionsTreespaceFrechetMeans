%%%script to import the landmark correspondence tree data set for all cases
read_subjectinfo;
TreeData = cell(1,109);
savestr = 'C:\Users\Sean\Desktop\test delete me\tree figures';
t = 0;
%109
for count=2:109
    if count<10
        filename = strcat('C:\Users\Sean\My Research\tree space project\DATA\128 leaf trees\NormalA-00',num2str(count),'.txt');
        filename2 = strcat('C:\Users\Sean\My Research\tree space project\DATA\128 leaf and 0 root trees newick\NormalA-00',num2str(count),'.newick.txt');
        filename3 = strcat('C:\Users\Sean\My Research\tree space project\DATA\128 leaf trees binary\NormalA-00',num2str(count),'.binary.top.txt');
    filename4 = strcat('C:\Users\Sean\My Research\tree space project\DATA\128 leaf trees binary\NormalA-00',num2str(count),'.binary.len.txt');
    elseif count<100
        filename = strcat('C:\Users\Sean\My Research\tree space project\DATA\128 leaf trees\NormalA-0',num2str(count),'.txt');
        filename2 = strcat('C:\Users\Sean\My Research\tree space project\DATA\128 leaf and 0 root trees newick\NormalA-00',num2str(count),'.newick.txt');
     filename3 = strcat('C:\Users\Sean\My Research\tree space project\DATA\128 leaf trees binary\NormalA-00',num2str(count),'.binary.top.txt');
    filename4 = strcat('C:\Users\Sean\My Research\tree space project\DATA\128 leaf trees binary\NormalA-00',num2str(count),'.binary.len.txt');
    else
        filename = strcat('C:\Users\Sean\My Research\tree space project\DATA\128 leaf trees\NormalA-',num2str(count),'.txt');
        filename2 = strcat('C:\Users\Sean\My Research\tree space project\DATA\128 leaf and 0 root trees newick\NormalA-',num2str(count),'.newick.txt');
        filename3 = strcat('C:\Users\Sean\My Research\tree space project\DATA\128 leaf trees binary\NormalA-',num2str(count),'.binary.top.txt');
    filename4 = strcat('C:\Users\Sean\My Research\tree space project\DATA\128 leaf trees binary\NormalA-',num2str(count),'.binary.len.txt');
    end
    if exist(filename)==2 % check if case has been removed
        t = t+1;
        [Label,Parent,Length,Landmark] = read_tree(filename);
        
        %        TreeData{t} = [Label;Parent;Length;Landmark];
        %         TreeData{count} = [Label,Parent,Length,Landmark];
%                  str = ['Case: %g  Age: %g  Gender:',blanks(1),gender{count},'  Hand:',blanks(1),hand{count}];
%                 titlestr = sprintf(str,[count age(count)]);
%                  plot_tree(Label,Parent,Length,titlestr)
        %         ylim([0,450])
        %         orient landscape
        %         print('-dpsc','-append',savestr)
        %close
        [sigma_binary,L_binary,sigma_binary_dups] = make_splits_binary(Label,Length,Parent,Landmark);
         F_binary{t} = sigma_binary;
            L_F_binary{t} = L_binary;
      %   plot_tree_binary(sigma_binary,L_binary,titlestr)
        % orient landscape
        % print('-dpsc','-append',savestr)
        % close
%          [Label1,Pars1,Landmark1] = bin2par(sigma_binary);
%         for i = 1:size(Pars1,2)
%             Parent1(i) = Pars1{i};
%         end
%         s = list2newick(Label1,Parent1,Landmark1,L_binary);
        %[Label2,Parent2,Landmark2,Length2] = newick2list(s);

        % [sigma_check,L,sigma_unordered] = make_splits(Label1,Parent1,L_binary,Landmark1);
        % v = 1:128;
        % for i = 1:size(sigma_binary,1)
        %     sigma{1,i} = v(logical(sigma_binary(i,:)));
        %     sigma{2,i} = v(~logical(sigma_binary(i,:)));
        % end
        %plot_tree(Label1,Parent1,L_binary,titlestr)
       % plot_tree(Label2,Parent2,Length2,titlestr)
        % F{t} = maketree(sigma);
        % L_F{t} = L_binary;
        count
    end
end
%clear count filename Label Parent Length
%% export binary trees
%         M = num2str(F_binary{t});
%         L = num2str(L_F_binary{t});
%         fid3 = fopen(filename3,'w');
%         fid4 = fopen(filename4,'w');
%         fwrite(fid3,M)
%         fwrite(fid4,L)
%         fclose(fid3);
%         fclose(fid4);
%%
% t = 0;
% for i = 1:size(sigma_binary,1)
%     if sigma_binary(i,:) == zeros(1,size(sigma_binary,2))
%         t = t+1;
%     end
% end

% lambda = 1/2;
% [T_lambda,L_lambda] = P(F{1},L_F{1},F{2},L_F{2},lambda);
% [X,L_x,U] = tree_mean_binary(F_binary,L_F_binary);

%% count mutually compatible edges for each pair of tree -> collect into
%% matrix and write to file
%mut_comp = mutual_comp_matrix(F_binary);

