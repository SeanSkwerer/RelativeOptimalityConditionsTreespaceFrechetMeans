% add a root to the 128 leaf brain trees
load 128leaftreesbinary.mat
for i = 1:85
    E = F_binary{i};
    E = [zeros(size(E,1),1),E];
    L = [L_F_binary{i}];
    Forest.T(i).E = E;
    Forest.T(i).L = L;
end
save('DataSet4.mat','Forest')