%%%script to import the landmark correspondence tree data set for all cases
TreeData = cell(1,109);
for count=1:109
    if count<10
        filename = strcat('C:\Users\Sean\Desktop\for Haonan\Landmark Correspondence Trees\NormalA-00',num2str(count),'.txt');
    elseif count<100
        filename = strcat('C:\Users\Sean\Desktop\for Haonan\Landmark Correspondence Trees\NormalA-0',num2str(count),'.txt');
    else
        filename = strcat('C:\Users\Sean\Desktop\for Haonan\Landmark Correspondence Trees\NormalA-',num2str(count),'.txt');
    end
    if exist(filename)==2 % check if case has been removed
        [Label,Parent,Length,Landmark] = read_tree(filename);
        TreeData{count} = {Label,Parent,Length,Landmark};
    end
end
clear count filename Label Parent Length


% for each tree in the data set 

% tree - edge (incidence)length matrix

% edge - edge compatibility matrix

% 