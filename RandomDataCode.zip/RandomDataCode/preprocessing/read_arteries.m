function ARTERY_TUBES= read_arteries(name1)
ARTERY_TUBES = [];
%% read artery tubes
ARTERY_TUBES = cell(4,5);
for tree_index = 1:4
    root_counter = 0;
    clear X Y Z R head
    if tree_index == 1
        filename = strcat(name1,'\aca.tre');
    elseif tree_index == 2
        filename = strcat(name1,'\lca.tre');
    elseif tree_index == 3
        filename = strcat(name1,'\pca.tre');
    else
        filename = strcat(name1,'\rca.tre');
    end
    
    fin = fopen(filename,'r');
    i=1;
    while 1==1
        line = fgetl(fin);
        if line < 0
            break;
        end;
        if strcmp(strtok(line,':'),'VoxelSize') == 1
            [a,b] = strtok(line,' '); %a: 'VoxelSize' b:x y z
            [a,b] = strtok(b,' ');
            vox_x = str2num(a);
            [a,b] = strtok(b,' '); %a: y  b:z
            vox_y = str2num(a);
            vox_z = str2num(b);
        end
        if strcmp(strtok(line,':'),'ID')==1
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            % head(i,1) = ID number
            % head(i,2) = parent number if segment i is a child
            %             -1 if segment i is a root
            % head(i,3) = attachment point on parent segment
            %             -1 if segment i is a root
            % head(i,4:7) = the color of segment i
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            [a,b] = strtok(line,' '); % first of head i takes the ID number
            head(i,1) = str2num(b);
            line = fgetl(fin);% now line has type
            line=fgetl(fin);%%now line has artery
            line=fgetl(fin);%%now it has treetype (either child or root)
            [a,b] = strtok(line,':');
            if strcmp(b,': child')==1
                line=fgetl(fin); %now we have the parent
                [a,b] = strtok(line,' ');
                head(i,2) = str2num(b); %take the parent number to 2
                line=fgetl(fin); %now we have the attachment point
                [a,b] = strtok(line,' ');
                head(i,3) = str2num(b); %take the attachment point number to 3
                if head(i,3) == 0  % some att. pts are zero !!!???
                    head(i,3) = 1;
                end
            else  %%then we have a root for this tree (l,r,a or p)
                root_counter = root_counter +1;
                head(i,2)= -1 ;% no parent
                head(i,3)= -1;% no att. pt.
            end
            line=fgetl(fin); %now we have the color
            [a,b] = strtok(line,' ');
            head(i,4:7) = str2num(b); %take the color to 4
            
            line=fgetl(fin); %the pointdim line
            line=fgetl(fin); %NPoints
            [a,b] = strtok(line,' ');
            Npoints = str2num(b);
            line=fgetl(fin);  %%%Points header
            % X{i}(1) = head(i,1);
            % Y{i}(1) = head(i,1);
            % Z{i}(1) = head(i,1);
            % R{i}(1) = head(i,1);
            % for j=2:Npoints+1
            for j = 1:Npoints
                line=fgetl(fin); %now line has the current point
                [a,b] = strtok(line,' '); %% a:x b: y z s
                X{i}(1,j) = str2num(a)*vox_x;
                [a,b] = strtok(b,' '); %%a:y b:z s
                Y{i}(1,j) = str2num(a)*vox_y;
                [a,b] = strtok(b,' '); %%a:z b:s
                Z{i}(1,j) = str2num(a)*vox_z;
                R{i}(j)=str2num(b);
                if R{i}(1,j)>10 keyboard; end;
            end;
            
            i=i+1;
        end
        
    end
    ARTERY_TUBES{tree_index,1} = head;
    ARTERY_TUBES{tree_index,2} = X;
    ARTERY_TUBES{tree_index,3} = Y;
    ARTERY_TUBES{tree_index,4} = Z;
    ARTERY_TUBES{tree_index,5} = R;
end
fclose(fin);

