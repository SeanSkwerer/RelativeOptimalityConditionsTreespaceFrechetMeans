filename = 'C:\Users\Sean\Documents\Trees\DATA\subject_information_basic.txt';
fid = fopen(filename);
line1 = fgetl(fid); %subject age gender hand
line = fgetl(fid);

[a,b] = strtok(line,' ');
counter = 0;
while line ~= -1
    counter = counter+1;
    % get case number
    [a,b] = strtok(line,'A');
    case_txt = b(2:4);
    case_num(counter) = str2num(case_txt);
    % get age
    [a,b] = strtok(b,' ');
    [a,b] = strtok(b,' ');
    age(counter) = str2num(a);
    % get gender
    [a,b] = strtok(b,' ');
    gender{counter} = a;
    % get handedness
    hand{counter} = strtrim(b);
    line = fgetl(fid);
end
fclose(fid);
clear a b counter case_txt filename line1 line 