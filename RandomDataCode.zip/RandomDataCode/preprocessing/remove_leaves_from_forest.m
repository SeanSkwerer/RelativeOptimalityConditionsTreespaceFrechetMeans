load 128leaftreesbinary
%options
verbose = true;
% how many trees are there?
n_T = length(F_binary);
%remove all the pendant edges from F_binary and L_binary
F_binary_noleaves = cell(1,n_T);
L_F_binary_noleaves = cell(1,n_T);
for i = 1:n_T
    treei = F_binary{1,i};
    Li = L_F_binary{1,i};
    n_edgesi = size(treei,1);
    c1 = 0;
    clear tree_i_noleaves L_i_noleaves
    for e = 1:n_edgesi
        if sum(treei(e,:)) == 0
            if verbose
                disp('root edge with no leaves found')
            end
            % none of these are found for the brain trees
        elseif sum(treei(e,:)) == 1
            % found a leaf -> do not include this edge
        elseif sum(treei(e,:)) == size(treei,2)-1
            % found a root leaf -> do not include this edge
            if verbose
                disp('found root leaf: sum == n-1')
            end
        elseif sum(treei(e,:)) == size(treei,2)
            % fond a root leaf -> do not include this edge
            if verbose
                disp('found root leaf : sum == n')
            end
        else
            c1 = c1+1;
            tree_i_noleaves(c1,:) = treei(e,:);
            L_i_noleaves(c1) = Li(e);
        end
        
    end
    F_binary_noleaves{i} = tree_i_noleaves;
    L_F_binary_noleaves{i} = L_i_noleaves;
end
save('128leaftreesbinary_noleaves','F_binary_noleaves','L_F_binary_noleaves')