%%%script to import the landmark correspondence tree data set for all cases
read_subjectinfo;
TreeData = cell(1,109);
savestr_list = 'tree figures list';
savestr_binary = 'tree figure binary';
t = 0;
close_on = false;
print_on  = false;
%109
clear options
options.plot_lengths = false;
for count=1:109
    if count<10
        filename = strcat('C:\Users\Sean\Documents\Data\Trees\67 leaf trees LMv2\NormalA-00',num2str(count),'.txt');
    elseif count<100
        filename = strcat('C:\Users\Sean\Documents\Data\Trees\67 leaf trees LMv2\NormalA-0',num2str(count),'.txt');
    else
        filename = strcat('C:\Users\Sean\Documents\Data\Trees\67 leaf trees LMv2\NormalA-',num2str(count),'.txt');
    end
    if exist(filename)==2 % check if case has been removed
        t = t+1;
        % read parent format of tree data
        [Label,Parent,Length,Landmark] = read_tree(filename);
        % associated landmarks with new names.
        v = sort(Landmark);
        v = v(v>0);
        v2= 1:length(v);
        clear Landmark2 Landmark3
        for i = 1:length(Landmark);
            if sum(Landmark(i)==v);
                Landmark2(i) = v2(Landmark(i)==v);
                Landmark3(Landmark(i)==v) =  v2(Landmark(i)==v);
            else
                Landmark2(i) = -1;
            end
        end
        TreeData{t} = [Label;Parent;Length;Landmark;Landmark2];
        TreeDataCase(t) = count;
        str = ['Case: %g  Age: %g  Gender:',blanks(1),gender{count},'  Hand:',blanks(1),hand{count}];
        titlestr = sprintf(str,[count age(count)]);
        options.titlestr = titlestr;
        plot_tree(Label,Parent,Length,options)
        ylim([0,450])
        if print_on
            orient landscape
            print('-dpsc','-append',savestr_list)
        end
        if close_on
            close
        end
        [sigma_binary,L_binary,sigma_binary_dups] = make_splits_binary(Label,Length,Parent,Landmark2);
        F_binary{t} = sigma_binary;
        L_F_binary{t} = L_binary;
        plot_tree_binary(sigma_binary,L_binary,titlestr)
        if print_on
            orient landscape
            print('-dpsc','-append',savestr_binary)
        end
        if close_on
            close
        end
        count
    end
end
save('67leaf_tree_binary_LMv2.mat')
%mut_comp = mutual_comp_matrix(F_binary);

