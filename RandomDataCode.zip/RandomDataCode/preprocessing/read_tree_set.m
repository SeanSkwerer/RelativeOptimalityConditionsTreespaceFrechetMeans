function trees = read_tree_set(file)
%% read truncated tree from text file
fid = fopen(file,'r');
tline = fgetl(fid); % header
tline = fgetl(fid); % first line of data
i = 0;
c = 0;
while tline ~= -1
    while ~strcmp(tline(1),'.') && (tline(1) ~= -1)
        i = i+1;
        [a,b] = strtok(tline,' ');
        Label(1,i) = str2double(a);
        [a,b] = strtok(b,' ');
        Parent(1,i) = str2double(a);
        [a,b] = strtok(b,' ');
        Length(1,i) = str2double(a);
        Landmark(1,i) = str2double(b);
        tline = fgetl(fid);
    end
    if i > 0
    c = c+1;
    trees(c).Label = Label;
    trees(c).Parent = Parent;
    trees(c).Length = Length;
    trees(c).Landmark = Landmark;
    end
    clear Label Parent Length Landmark
    i = 0;
    tline = fgetl(fid);
end
fclose(fid);

