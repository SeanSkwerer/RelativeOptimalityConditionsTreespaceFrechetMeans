function outstruct = read_and_visualize_selectout(name1,name2l,name2r,case_num,plot_on,write_on,coverage_info_on)
% standard output is [ARTERY_TUBES,Label,Parent,Childrens,total_length,subtree_length,total_dist_lm]
% outstruct will contain different variables:
% now outstruct contains I_left and I_right
make_landmark_trees = false;

ARTERY_TUBES = [];
Label=[];
Parent=[];Childrens=[];total_length=[];subtree_length=[];total_dist_lm=[];
%% read artery tubes
ARTERY_TUBES = cell(4,5);
for tree_index = 1:4
    root_counter = 0;
    clear X Y Z R head
    if tree_index == 1
        filename = strcat(name1,'\aca.tre');
    elseif tree_index == 2
        filename = strcat(name1,'\lca.tre');
    elseif tree_index == 3
        filename = strcat(name1,'\pca.tre');
    else
        filename = strcat(name1,'\rca.tre');
    end
    
    fin = fopen(filename,'r');
    i=1;
    while 1==1
        line = fgetl(fin);
        if line < 0
            break;
        end;
        if strcmp(strtok(line,':'),'VoxelSize') == 1
            [a,b] = strtok(line,' '); %a: 'VoxelSize' b:x y z
            [a,b] = strtok(b,' ');
            vox_x = str2num(a);
            [a,b] = strtok(b,' '); %a: y  b:z
            vox_y = str2num(a);
            vox_z = str2num(b);
        end
        if strcmp(strtok(line,':'),'ID')==1
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            % head(i,1) = ID number
            % head(i,2) = parent number if segment i is a child
            %             -1 if segment i is a root
            % head(i,3) = attachment point on parent segment
            %             -1 if segment i is a root
            % head(i,4:7) = the color of segment i
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            [a,b] = strtok(line,' '); % first of head i takes the ID number
            head(i,1) = str2num(b);
            line = fgetl(fin);% now line has type
            line=fgetl(fin);%%now line has artery
            line=fgetl(fin);%%now it has treetype (either child or root)
            [a,b] = strtok(line,':');
            if strcmp(b,': child')==1
                line=fgetl(fin); %now we have the parent
                [a,b] = strtok(line,' ');
                head(i,2) = str2num(b); %take the parent number to 2
                line=fgetl(fin); %now we have the attachment point
                [a,b] = strtok(line,' ');
                head(i,3) = str2num(b); %take the attachment point number to 3
                if head(i,3) == 0  % some att. pts are zero !!!???
                    head(i,3) = 1;
                end
            else  %%then we have a root for this tree (l,r,a or p)
                root_counter = root_counter +1;
                head(i,2)= -1 ;% no parent
                head(i,3)= -1;% no att. pt.
            end
            line=fgetl(fin); %now we have the color
            [a,b] = strtok(line,' ');
            head(i,4:7) = str2num(b); %take the color to 4
            
            line=fgetl(fin); %the pointdim line
            line=fgetl(fin); %NPoints
            [a,b] = strtok(line,' ');
            Npoints = str2num(b);
            line=fgetl(fin);  %%%Points header
            % X{i}(1) = head(i,1);
            % Y{i}(1) = head(i,1);
            % Z{i}(1) = head(i,1);
            % R{i}(1) = head(i,1);
            % for j=2:Npoints+1
            for j = 1:Npoints
                line=fgetl(fin); %now line has the current point
                [a,b] = strtok(line,' '); %% a:x b: y z s
                X{i}(1,j) = str2num(a)*vox_x;
                [a,b] = strtok(b,' '); %%a:y b:z s
                Y{i}(1,j) = str2num(a)*vox_y;
                [a,b] = strtok(b,' '); %%a:z b:s
                Z{i}(1,j) = str2num(a)*vox_z;
                R{i}(j)=str2num(b);
                if R{i}(1,j)>10 keyboard; end;
            end;
            
            i=i+1;
        end
        
    end
    ARTERY_TUBES{tree_index,1} = head;
    ARTERY_TUBES{tree_index,2} = X;
    ARTERY_TUBES{tree_index,3} = Y;
    ARTERY_TUBES{tree_index,4} = Z;
    ARTERY_TUBES{tree_index,5} = R;
end
fclose(fin);

%% Extract Landmarks
% alternative registry
filename = name2l;

f = fopen(filename,'r');
i = 0;
while 1==1
    line=fgetl(f);
    if line < 0
        break;
    end;
    i = i+1;
    [a,b] = strtok(line,' ');
    C_left(i,1) = str2num(a); % x position of landmark
    [a,b] = strtok(b,' ');
    C_left(i,2) = str2num(a); % y position of landmark
    C_left(i,3) = str2num(b);% z position of landmark
end
fclose(f);
n_left = i;
filename = name2r;
%filename = 'C:\Users\Sean\My Research\tree space project\DATA\Landmark_Cortical_Surface_data_alternative\NormalA-025\surf\right.registered.lpts';
f = fopen(filename,'r');
i = 0;
while 1==1
    line=fgetl(f);
    if line < 0
        break;
    end;
    i = i+1;
    [a,b] = strtok(line,' ');
    C_right(i,1) = str2num(a); % x position of landmark
    [a,b] = strtok(b,' ');
    C_right(i,2) = str2num(a); % y position of landmark
    C_right(i,3) = str2num(b);% z position of landmark
end
fclose(f);
n_right = i;

%% find landmark attachment points
% % %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% % find the point on the tree that is closest to each coordinate C(:,i)
% % %%%%%%%%
% % I(i,1) = the index of the tree (anterior=1, posterior=2, right=3, left=4)
% % I(i,2) = the index of the branch that contains the point closest
% %         to the landmark at C(i,:)
% % I(i,3) = the index in the branch tree_3D_r{2,I(i,1)} of the point
% %         closest to the landmark at C(i,:)
% % I(i,4:6) = (x,y,z) location on the the tree closest to landmark i
% % %%%%%%
% % Landmarks from the left hemisphere
I_left = zeros(n_left,2);
m = 0;
for i = 1:n_left
    % fix rotation
    x1 = -C_left(i,1); % multiply by -1 to fix rotation
    y1 = -C_left(i,2); % ""
    z1 = C_left(i,3); % coordinate good here!
    best_distance = 1000000;
    best_branch = 0;
    best_index = 0;
    for j = 1:4
        n = size(ARTERY_TUBES{j,2},2);
        for k = 2:n
            x = ARTERY_TUBES{j,2}{k}(1,:);
            y = ARTERY_TUBES{j,3}{k}(1,:);
            z = ARTERY_TUBES{j,4}{k}(1,:);
            % use squared distance to save computational time
            [current_distance, current_index] = min( (x-x1).^2 + (y-y1).^2 + (z-z1).^2 );
            if current_distance < best_distance
                best_distance = current_distance;
                best_index = current_index;
                best_branch = k;
                best_tree = j;
                best_location = [x(best_index),y(best_index),z(best_index)];
                best_branch_ID = ARTERY_TUBES{j,1}(k,1);
            end
        end
        if best_branch == 0
            'error: somehow no point closest ???'
        end
        I_left(i,1) = best_tree;
        I_left(i,2) = best_branch;
        I_left(i,3) = best_index;
        I_left(i,4:6) = best_location;
        I_left(i,7) = best_distance;
        I_left(i,8) = best_branch_ID;
        I_left(i,9) = i; % label
    end
end

% Landmarks from the right hemisphere
I_right = zeros(n_right,2);
m = 0;
for i = 1:n_right
    % fix rotation
    x1 = -C_right(i,1); % multiply by -1 here
    y1 = -C_right(i,2);% "
    z1 = C_right(i,3);% not here
    best_distance = 1000000;
    best_branch = 0;
    best_index = 0;
    for j = 1:4
        n = size(ARTERY_TUBES{j,2},2);
        for k = 2:n
            x = ARTERY_TUBES{j,2}{k}(1,:);
            y = ARTERY_TUBES{j,3}{k}(1,:);
            z = ARTERY_TUBES{j,4}{k}(1,:);
            % use squared distance to save computational time
            [current_distance, current_index] = min( (x-x1).^2 + (y-y1).^2 + (z-z1).^2 );
            if current_distance < best_distance
                best_distance = current_distance;
                best_index = current_index;
                best_branch = k;
                best_tree = j;
                best_location = [x(best_index),y(best_index),z(best_index)];
                best_branch_ID = ARTERY_TUBES{j,1}(k,1);
            end
        end
        if best_branch == 0
            'error: somehow no point closest ???'
        end
        I_right(i,1) = best_tree;
        I_right(i,2) = best_branch;
        I_right(i,3) = best_index;
        I_right(i,4:6) = best_location;
        I_right(i,7) = best_distance;
        I_right(i,8) = best_branch_ID;
        I_right(i,9) = i; %label
    end
end
%%
if make_landmark_trees
t = 0;
for i = 1:64
    STOP = false;
    % store the edge between landmark i and it's attachment point on the
    % tree
    t = t+1;
    Label(t,1) = 5;
    Label(t,2) = i;
    Label(t,3) = 1;
    Parent(t,1) = I_left(i,1);
    Parent(t,2) = I_left(i,8);
    Parent(t,3) = I_left(i,3);
    parent_structure = I_left(i,1);
    parent_component = I_left(i,8);
    parent_index = I_left(i,3);
    head = ARTERY_TUBES{parent_structure,1};
    % indicator1:edges with the same structure
    % indicator2: edges with the same structure and component
    % indicator3: edges with the same structure, component and index
    indicator1 = Label(:,1)==parent_structure;
    indicator2 = logical(indicator1.*(Label(:,2)==parent_component));
    indicator3 = logical(indicator2.*(Label(:,3)==parent_index));
    if sum(indicator2)>0
        % have reached a branch already included in the landmark
        % spanning subtree
        STOP = true;
        if sum(indicator3) > 0
            % attaches at the end of some other segment
        elseif sum(Label(indicator2,3) > parent_index) > 0
            % attaches along some edge
            % find edge just above attachment
            temp = Label(indicator2,3);
            %indicator4: indicates edges with the same structure and
            %component located above parent_index
            indicator4 = logical(indicator2.*(Label(:,3) == min(temp(Label(indicator2,3)>parent_index))));
            Parent(indicator4,2) = parent_component;
            Parent(indicator4,3) = parent_index;
            % create new edge
            t = t+1;
            if sum(Label(indicator2,3)<parent_index) > 0
                % there are segments below this on branch
                Parent(t,1) = parent_structure;
                Parent(t,2) = parent_component;
                indicator5 = logical(indicator2.*(Label(:,3)==max(temp(Label(indicator2,3)<parent_index))));
                Parent(t,3) = Label(indicator5,3);
                Label(t,1) = parent_structure;
                Label(t,2) = parent_component;
                Label(t,3) = parent_index;
            else
                % no segments below this on branch
                Label(t,1) = parent_structure;
                Label(t,2) = parent_component;
                Label(t,3) = parent_index;
                old_component = parent_component;
                parent_component = head(head(:,1)==old_component,2);
                parent_index = head(head(:,1) == old_component,3);
                Parent(t,1) = parent_structure;
                Parent(t,2) = parent_component;
                Parent(t,3) = parent_index;
            end
        else % attaches above every segment on this branch
            % create new edge
            t = t+1;
            Parent(t,1) = parent_structure;
            Parent(t,2) = parent_component;
            Parent(t,3) = max(Label(indicator2,3));
            Label(t,1) = parent_structure;
            Label(t,2) = parent_component;
            Label(t,3) = parent_index;
        end
    else
        t = t+1;
        Label(t,1) = parent_structure;
        Label(t,2) = parent_component;
        Label(t,3) = parent_index;
        old_component = parent_component;
        parent_component = head(head(:,1)==old_component,2);
        parent_index = head(head(:,1) == old_component,3);
        Parent(t,1) = parent_structure;
        Parent(t,2) = parent_component;
        Parent(t,3) = parent_index;
    end
    while Parent(t,2) > -1  && ~STOP
        % indicator1:edges with the same structure
        % indicator2: edges with the same structure and component
        % indicator3: edges with the same structure, component and index
        indicator1 = Label(:,1)==parent_structure;
        indicator2 = logical(indicator1.*(Label(:,2)==parent_component));
        indicator3 = logical(indicator2.*(Label(:,3)==parent_index));
        if sum(indicator2)>0
            % have reached a branch already included in the landmark
            % spanning subtree
            STOP = true;
            if sum(indicator3) > 0
                % attaches at the end of some other segment
            elseif sum(Label(indicator2,3) > parent_index) > 0
                % attaches along some edge
                % find edge just above attachment
                temp = Label(indicator2,3);
                indicator4 = logical(indicator2.*(Label(:,3) == min(temp(Label(indicator2,3)>parent_index))));
                Parent(indicator4,2) = parent_component;
                Parent(indicator4,3) = parent_index;
                % create new edge
                t = t+1;
                if sum(Label(indicator2,3)<parent_index) > 0
                    % there are segments below this on branch
                    
                    Parent(t,1) = parent_structure;
                    Parent(t,2) = parent_component;
                    indicator5 = logical(indicator2.*(Label(:,3)==max(temp(Label(indicator2,3)<parent_index))));
                    Parent(t,3) = Label(indicator5,3);
                    
                    Label(t,1) = parent_structure;
                    Label(t,2) = parent_component;
                    Label(t,3) = parent_index;
                else
                    % no segments below this on branch
                    
                    Label(t,1) = parent_structure;
                    Label(t,2) = parent_component;
                    Label(t,3) = parent_index;
                    old_component = parent_component;
                    parent_component = head(head(:,1)==old_component,2);
                    parent_index = head(head(:,1) == old_component,3);
                    Parent(t,1) = parent_structure;
                    Parent(t,2) = parent_component;
                    Parent(t,3) = parent_index;
                end
            else % attaches above every segment on this branch
                t = t+1;
                Parent(t,1) = parent_structure;
                Parent(t,2) = parent_component;
                Parent(t,3) = max(Label(indicator2,3));
                Label(t,1) = parent_structure;
                Label(t,2) = parent_component;
                Label(t,3) = parent_index;
            end
        else
            t = t+1;
            Label(t,1) = parent_structure;
            Label(t,2) = parent_component;
            Label(t,3) = parent_index;
            old_component = parent_component;
            parent_component = head(head(:,1)==old_component,2);
            parent_index = head(head(:,1) == old_component,3);
            Parent(t,1) = parent_structure;
            Parent(t,2) = parent_component;
            Parent(t,3) = parent_index;
        end
    end
end
for i = 1:64
    STOP = false;
    % store the edge between landmark i and it's attachment point on the
    % tree
    t = t+1;
    Label(t,1) = 6;
    Label(t,2) = i;
    Label(t,3) = 1;
    Parent(t,1) = I_right(i,1);
    Parent(t,2) = I_right(i,8);
    Parent(t,3) = I_right(i,3);
    parent_structure = I_right(i,1);
    parent_component = I_right(i,8);
    parent_index = I_right(i,3);
    head = ARTERY_TUBES{parent_structure,1};
    % indicator1:edges with the same structure
    % indicator2: edges with the same structure and component
    % indicator3: edges with the same structure, component and index
    indicator1 = Label(:,1)==parent_structure;
    indicator2 = logical(indicator1.*(Label(:,2)==parent_component));
    indicator3 = logical(indicator2.*(Label(:,3)==parent_index));
    if sum(indicator2)>0
        % have reached a branch already included in the landmark
        % spanning subtree
        STOP = true;
        if sum(indicator3) > 0
            % attaches at the end of some other segment
        elseif sum(Label(indicator2,3) > parent_index) > 0
            % attaches along some edge
            % find edge just above attachment
            temp = Label(indicator2,3);
            %indicator4: indicates edges with the same structure and
            %component located above parent_index
            indicator4 = logical(indicator2.* (Label(:,3) == min(temp (temp >parent_index) )));
            Parent(indicator4,2) = parent_component;
            Parent(indicator4,3) = parent_index;
            % create new edge
            t = t+1;
            if sum(Label(indicator2,3)<parent_index) > 0
                % there are segments below this on branch
                Parent(t,1) = parent_structure;
                Parent(t,2) = parent_component;
                indicator5 = logical(indicator2.*(Label(:,3)==max(temp(temp<parent_index))));
                Parent(t,3) = Label(indicator5,3);
                Label(t,1) = parent_structure;
                Label(t,2) = parent_component;
                Label(t,3) = parent_index;
            else
                % no segments below this on branch
                Label(t,1) = parent_structure;
                Label(t,2) = parent_component;
                Label(t,3) = parent_index;
                old_component = parent_component;
                parent_component = head(head(:,1)==old_component,2);
                parent_index = head(head(:,1) == old_component,3);
                Parent(t,1) = parent_structure;
                Parent(t,2) = parent_component;
                Parent(t,3) = parent_index;
            end
        else % attaches above every segment on this branch
            % create new edge
            t = t+1;
            Parent(t,1) = parent_structure;
            Parent(t,2) = parent_component;
            Parent(t,3) = max(Label(indicator2,3));
            Label(t,1) = parent_structure;
            Label(t,2) = parent_component;
            Label(t,3) = parent_index;
        end
    else
        t = t+1;
        Label(t,1) = parent_structure;
        Label(t,2) = parent_component;
        Label(t,3) = parent_index;
        old_component = parent_component;
        parent_component = head(head(:,1)==old_component,2);
        parent_index = head(head(:,1) == old_component,3);
        Parent(t,1) = parent_structure;
        Parent(t,2) = parent_component;
        Parent(t,3) = parent_index;
    end
    while Parent(t,2) > -1  && ~STOP
        % indicator1:edges with the same structure
        % indicator2: edges with the same structure and component
        % indicator3: edges with the same structure, component and index
        indicator1 = Label(:,1)==parent_structure;
        indicator2 = logical(indicator1.*(Label(:,2)==parent_component));
        indicator3 = logical(indicator2.*(Label(:,3)==parent_index));
        if sum(indicator2)>0
            % have reached a branch already included in the landmark
            % spanning subtree
            STOP = true;
            if sum(indicator3) > 0
                % attaches at the end of some other segment
            elseif sum(Label(indicator2,3) > parent_index) > 0
                % attaches along some edge
                % find edge just above attachment
                temp = Label(indicator2,3);
                indicator4 = logical(indicator2.*(Label(:,3) == min(temp( temp >parent_index))) );
                Parent(indicator4,2) = parent_component;
                Parent(indicator4,3) = parent_index;
                % create new edge
                t = t+1;
                if sum(Label(indicator2,3)<parent_index) > 0
                    % there are segments below this on branch
                    
                    Parent(t,1) = parent_structure;
                    Parent(t,2) = parent_component;
                    indicator5 = logical(indicator2.*(Label(:,3)==max(temp(temp<parent_index))));
                    Parent(t,3) = Label(indicator5,3);
                    
                    Label(t,1) = parent_structure;
                    Label(t,2) = parent_component;
                    Label(t,3) = parent_index;
                else
                    % no segments below this on branch
                    
                    Label(t,1) = parent_structure;
                    Label(t,2) = parent_component;
                    Label(t,3) = parent_index;
                    old_component = parent_component;
                    parent_component = head(head(:,1)==old_component,2);
                    parent_index = head(head(:,1) == old_component,3);
                    Parent(t,1) = parent_structure;
                    Parent(t,2) = parent_component;
                    Parent(t,3) = parent_index;
                end
            else % attaches above every segment on this branch
                t = t+1;
                Parent(t,1) = parent_structure;
                Parent(t,2) = parent_component;
                Parent(t,3) = max(Label(indicator2,3));
                Label(t,1) = parent_structure;
                Label(t,2) = parent_component;
                Label(t,3) = parent_index;
            end
        else
            t = t+1;
            Label(t,1) = parent_structure;
            Label(t,2) = parent_component;
            Label(t,3) = parent_index;
            old_component = parent_component;
            parent_component = head(head(:,1)==old_component,2);
            parent_index = head(head(:,1) == old_component,3);
            Parent(t,1) = parent_structure;
            Parent(t,2) = parent_component;
            Parent(t,3) = parent_index;
        end
    end
end

% these subtrees stop at the end of the trees they start in
% they need ot be connected to super root
tree_roots = Label(Parent(:,2) == -1,:);
location_root = zeros(1,3);
for i = 1:size(tree_roots,1)
        current_structure = tree_roots(i,1);
        current_component = tree_roots(i,2);
        current_index = tree_roots(i,3);
    indicator =  logical((Label(:,1)==current_structure).*(Label(:,2)==current_component).*(Label(:,3)==current_index));
    head = ARTERY_TUBES{current_structure,1};
        X = ARTERY_TUBES{current_structure,2};
        Y = ARTERY_TUBES{current_structure,3};
        Z = ARTERY_TUBES{current_structure,4};
        indicator = head(:,2)==-1;
        x = X{indicator};
        y = Y{indicator};
        z = Z{indicator};
        location_root = location_root+[x(1),y(1),z(1)]/size(tree_roots,1);
end
end
if plot_on  || write_on
    %% create variables used for tree visualization and printing to file
    %%%%%%% find the children for each segment %%%%%%%%%%%%%
    Childrens = cell(size(Label,1),1);
    for i = 1:length(Label)
        child_counter = 0;
        childrens = -1;
        for j = 1:length(Label)
            if Parent(j,1) == Label(i,1) && Parent(j,2) == Label(i,2) && Parent(j,3) == Label(i,3)
                child_counter = child_counter+1;
                childrens(child_counter,1) = Label(j,1);
                childrens(child_counter,2) = Label(j,2);
                childrens(child_counter,3) = Label(j,3);
            end
        end
        Childrens{i} = childrens;
    end
    
    %%%% give the tree an embedding (i.e. a left to right ordering of children)
    %%% depth first search on the tree giving each leaf a label in the order
    %%% it is reached
    leaf_counter = 0;
    Leaf_left2right_label = -1*ones(size(Label,1),1);
    LIST = [Label(Parent(:,2)==-1,:); [10000000,-1,-1]]; % 10000000 is a dummy element
    k = size(LIST,1);
    while k > 1
        current_structure = LIST(1,1);
        current_component = LIST(1,2);
        current_index = LIST(1,3);
        indicator = logical((Label(:,1)==current_structure).*(Label(:,2)==current_component).*(Label(:,3)==current_index));
        LIST = LIST(2:k,:);
        if current_structure == 5 || current_structure == 6
            leaf_counter = leaf_counter +1;
            Leaf_left2right_label(indicator) = leaf_counter;
        else
            LIST = [Childrens{indicator} ;LIST];
        end
        k = size(LIST,1);
    end
    
    
    
    %%% compute the x-coordinates of each segment
        tree_roots = Label(Parent(:,2) == -1,:);
    x_coordinates_2D = zeros(size(Label,1),1);
    for i = 1:size(tree_roots,1)
        current_structure = tree_roots(i,1);
        current_component = tree_roots(i,2);
        current_index = tree_roots(i,3);
        indicator = logical((Label(:,1)==current_structure).*(Label(:,2)==current_component).*(Label(:,3)==current_index));
        x_coordinates_2D = x_coordinates_2D + compute_x_coordinates(indicator,Childrens,Label,Leaf_left2right_label);
    end
    
    tree_roots = Label(Parent(:,2) == -1,:);
    x_coord_root = 0;
    location_root = zeros(1,3);
    for i = 1:size(tree_roots,1)
        current_structure = tree_roots(i,1);
        current_component = tree_roots(i,2);
        current_index = tree_roots(i,3);
        indicator =  logical((Label(:,1)==current_structure).*(Label(:,2)==current_component).*(Label(:,3)==current_index));
        x_coord_root = x_coord_root+(x_coordinates_2D(indicator)/size(tree_roots,1));
        head = ARTERY_TUBES{current_structure,1};
        X = ARTERY_TUBES{current_structure,2};
        Y = ARTERY_TUBES{current_structure,3};
        Z = ARTERY_TUBES{current_structure,4};
        indicator = head(:,2)==-1;
        x = X{indicator};
        y = Y{indicator};
        z = Z{indicator};
        location_root = location_root+[x(1),y(1),z(1)]/size(tree_roots,1);
    end
    
    %% compute the length of each segment
    Length = zeros(size(Label,1),1);
    for i = 1:length(Label)
        clear x y z
        if Label(i,1) == 5 || Label(i,1) ==6
            % landmark to tree segment
            if Label(i,1) == 5
                x(1)=-C_left(Label(i,2),1);
                y(1)=-C_left(Label(i,2),2);
                z(1)=C_left(Label(i,2),3);
                x(2)=I_left(Label(i,2),4);
                y(2)=I_left(Label(i,2),5);
                z(2)=I_left(Label(i,2),6);
                Length(i) = arclength(x,y,z);
            else
                x(1)=-C_right(Label(i,2),1);
                y(1)=-C_right(Label(i,2),2);
                z(1)=C_right(Label(i,2),3);
                x(2)=I_right(Label(i,2),4);
                y(2)=I_right(Label(i,2),5);
                z(2)=I_right(Label(i,2),6);
                Length(i) = arclength(x,y,z);
            end
        elseif Parent(i,2) == -1
            % branch to super root segment
            head = ARTERY_TUBES{Label(i,1),1};
            X = ARTERY_TUBES{Label(i,1),2};
            Y = ARTERY_TUBES{Label(i,1),3};
            Z = ARTERY_TUBES{Label(i,1),4};
            indicator = head(:,1)==Label(i,2);
            x=X{indicator};
            y = Y{indicator};
            z = Z{indicator};
            a_x = location_root(1);
            a_y = location_root(2);
            a_z = location_root(3);
            Length(i) = arclength([a_x,x(1:Label(i,3))],[a_y,y(1:Label(i,3))],[a_z,z(1:Label(i,3))]);
        elseif Label(i,2) == Parent(i,2)
            % within branch segment
            head = ARTERY_TUBES{Label(i,1),1};
            X = ARTERY_TUBES{Label(i,1),2};
            Y = ARTERY_TUBES{Label(i,1),3};
            Z = ARTERY_TUBES{Label(i,1),4};
            indicator = head(:,1)==Label(i,2);
            x = X{indicator};
            y = Y{indicator};
            z = Z{indicator};
            Length(i) = arclength(x(Parent(i,3):Label(i,3)),y(Parent(i,3):Label(i,3)),z(Parent(i,3):Label(i,3)));
        elseif Label(i,2) ~= Parent(i,2)
            % inter branch segment
            head = ARTERY_TUBES{Label(i,1),1};
            X = ARTERY_TUBES{Label(i,1),2};
            Y = ARTERY_TUBES{Label(i,1),3};
            Z = ARTERY_TUBES{Label(i,1),4};
            indicator = head(:,1)==Label(i,2);
            x = X{indicator};
            y = Y{indicator};
            z = Z{indicator};
            indicator = head(:,1)==Parent(i,2);
            x2 = X{indicator};
            y2 = Y{indicator};
            z2 = Z{indicator};
            a_x = x2(Parent(i,3));
            a_y = y2(Parent(i,3));
            a_z = z2(Parent(i,3));
            Length(i) = arclength([a_x,x(1:Label(i,3))],[a_y,y(1:Label(i,3))],[a_z,z(1:Label(i,3))]);
        end
    end
    
    %%%% compute the distance from the root of each segment
    Distance_from_root = zeros(size(Label,1),1);
    LIST = [Label(Parent(:,2)==-1,:); [10000000,-1,-1]]; % 10000000 is a dummy element
    k = size(LIST,1);
    while k > 1
        current_structure = LIST(1,1);
        current_component = LIST(1,2);
        current_index = LIST(1,3);
        indicator = logical((Label(:,1)==current_structure).*(Label(:,2)==current_component).*(Label(:,3)==current_index));
        LIST = LIST(2:k,:);
        if Parent(indicator,2) == -1
            Distance_from_root(indicator) = Length(indicator);
        else
            parent_indicator = logical((Label(:,1)==Parent(indicator,1)).*(Label(:,2)==Parent(indicator,2)).*(Label(:,3)==Parent(indicator,3)));
            Distance_from_root(indicator) = Length(indicator) + Distance_from_root(parent_indicator);
        end
        if Label(indicator,1)==5 || Label(indicator,1)==6
        else
            LIST = [Childrens{indicator} ;LIST];
        end
        k = size(LIST,1);
    end
    Distance_from_root = Distance_from_root + 20;
    if plot_on
        %% create the 2-D visualization for the full tree
        figure;
        hold on
        LIST = [Label(Parent(:,2)==-1,:); [10000000,-1,-1]]; % 10000000 is a dummy element
        k = size(LIST,1);
        while k > 1
            current_structure = LIST(1,1);
            current_component = LIST(1,2);
            current_index = LIST(1,3);
            indicator = logical((Label(:,1)==current_structure).*(Label(:,2)==current_component).*(Label(:,3)==current_index));
            parent_indicator = logical((Label(:,1)==Parent(indicator,1)).*(Label(:,2)==Parent(indicator,2)).*(Label(:,3)==Parent(indicator,3)));
            LIST = LIST(2:k,:);
            if (Label(indicator,1) == 1) || (Label(indicator,1) == 2) || (Label(indicator,1) == 3) ||(Label(indicator,1) == 4)
                plot([x_coordinates_2D(indicator), x_coordinates_2D(indicator)],...
                    [Distance_from_root(indicator)-Length(indicator), Distance_from_root(indicator)], ...
                    'color',[0 0 1], ...
                    'LineWidth',1.5);
                if Parent(i) ~= 0
                    plot( [x_coordinates_2D(indicator),x_coordinates_2D(parent_indicator)],...
                        [Distance_from_root(indicator)-Length(indicator),Distance_from_root(indicator)-Length(indicator)],...
                        ':k');
                end
                LIST = [Childrens{indicator} ;LIST];
            end
            if Label(indicator,1) == 5 ||Label(indicator,1) == 6
                plot([x_coordinates_2D(indicator), x_coordinates_2D(indicator)],...
                    [Distance_from_root(parent_indicator), Distance_from_root(indicator)], ...
                    'color',[1 0 0], ...
                    'LineWidth',1.5);
                plot(x_coordinates_2D(indicator),Distance_from_root(indicator),'k.');
                if Parent(i) ~= 0
                    plot( [x_coordinates_2D(indicator),x_coordinates_2D(parent_indicator)],...
                        [Distance_from_root(indicator)-Length(indicator),Distance_from_root(indicator)-Length(indicator)],...
                        ':k');
                end
            end
            k = size(LIST,1);
        end
        hold off
        ylim([0 450])
        title(strcat('Case',' ',num2str(case_num)))
        orient landscape
        %print('-dpsc2',strcat('C:\Users\Sean\My Research\tree space project\Graphics\DataSet3_2D\Case',num2str(case_num),'_2D.ps'))
        print('-dpsc2','-append',strcat('C:\Users\Sean\My Research\tree space project\Graphics\DataSet3_2D\DataSet3_2D.ps'))
        %close gcf
        %% 3-D visualization
        
total_length = 0;       
subtree_length = 0;
total_dist_lm = 0;
        figure
                hold on
                for tree = 1:4
                    head = ARTERY_TUBES{tree,1};
                    X = ARTERY_TUBES{tree,2};
                    Y = ARTERY_TUBES{tree,3};
                    Z = ARTERY_TUBES{tree,4};
                    for i = 1:length(X)
                        x = X{i}; y = Y{i}; z = Z{i};
%                         m = length(x);
%                         x = x(2:m); y = y(2:m); z = z(2:m);
                        plot3(x,y,z,'cyan')
                        total_length = total_length+arclength(x,y,z);
                        % plot from child to parent
                        parent = head(i,2);
                        if parent > 0
                        x_att = X{head(:,1)==parent}(head(i,3));
                        y_att = Y{head(:,1)==parent}(head(i,3));
                        z_att = Z{head(:,1)==parent}(head(i,3));
                        plot3([x_att,x(1)],[y_att,y(1)],[z_att,z(1)],'cyan')
                        total_length = total_length+arclength([x_att,x(1)],[y_att,y(1)],[z_att,z(1)]);
                        end
                    end
                end
                for i = 1:length(Label)
                    clear x y z
                    if Label(i,1) == 5 || Label(i,1) ==6
                        % landmark to tree edge
                        if Label(i,1) == 5
                            x(1)=-C_left(Label(i,2),1);
                            y(1)=-C_left(Label(i,2),2);
                            z(1)=C_left(Label(i,2),3);
                            x(2)=I_left(Label(i,2),4);
                            y(2)=I_left(Label(i,2),5);
                            z(2)=I_left(Label(i,2),6);
                            plot3(x,y,z,'color',[0.8 0.5 0.3])
                            plot3(x(1),y(1),z(1),'r*')
                        else
                            x(1)=-C_right(Label(i,2),1);
                            y(1)=-C_right(Label(i,2),2);
                            z(1)=C_right(Label(i,2),3);
                            x(2)=I_right(Label(i,2),4);
                            y(2)=I_right(Label(i,2),5);
                            z(2)=I_right(Label(i,2),6);
                            plot3(x,y,z,'color',[0.8 0.5 0.3])
                            plot3(x(1),y(1),z(1),'r*')
                        end
                        total_dist_lm = total_dist_lm + arclength(x,y,z);
                    elseif Parent(i,2) == -1
                        % branch to super root edge
                        head = ARTERY_TUBES{Label(i,1),1};
                        X = ARTERY_TUBES{Label(i,1),2};
                        Y = ARTERY_TUBES{Label(i,1),3};
                        Z = ARTERY_TUBES{Label(i,1),4};
                        indicator = head(:,1)==Label(i,2);
                        x=X{indicator};
                        y = Y{indicator};
                        z = Z{indicator};
                        a_x = location_root(1);
                        a_y = location_root(2);
                        a_z = location_root(3);
                        plot3(x(1:Label(i,3)),y(1:Label(i,3)),z(1:Label(i,3)),'b');
                        plot3([a_x,x(1)],[a_y,y(1)],[a_z,z(1)],'g');
                    elseif Label(i,2) == Parent(i,2)
                        % within branch edge
                    head = ARTERY_TUBES{Label(i,1),1};
                    X = ARTERY_TUBES{Label(i,1),2};
                    Y = ARTERY_TUBES{Label(i,1),3};
                    Z = ARTERY_TUBES{Label(i,1),4};
                    indicator = head(:,1)==Label(i,2);
                    x = X{indicator};
                    y = Y{indicator};
                    z = Z{indicator};
                    plot3(x(Parent(i,3):Label(i,3)),y(Parent(i,3):Label(i,3)),z(Parent(i,3):Label(i,3)));
                    subtree_length = subtree_length + arclength(x(Parent(i,3):Label(i,3)),y(Parent(i,3):Label(i,3)),z(Parent(i,3):Label(i,3)));
                elseif Label(i,2) ~= Parent(i,2)
                    % inter branch edge
                    head = ARTERY_TUBES{Label(i,1),1};
                    X = ARTERY_TUBES{Label(i,1),2};
                    Y = ARTERY_TUBES{Label(i,1),3};
                    Z = ARTERY_TUBES{Label(i,1),4};
                    indicator = head(:,1)==Label(i,2);
                    x = X{indicator};
                    y = Y{indicator};
                    z = Z{indicator};
                    indicator = head(:,1)==Parent(i,2);
                    x2 = X{indicator};
                    y2 = Y{indicator};
                    z2 = Z{indicator};
                    a_x = x2(Parent(i,3));
                    a_y = y2(Parent(i,3));
                    a_z = z2(Parent(i,3));
                    plot3([a_x,x(1:Label(i,3))],[a_y,y(1:Label(i,3))],[a_z,z(1:Label(i,3))]);
                    subtree_length = subtree_length + arclength([a_x,x(1:Label(i,3))],[a_y,y(1:Label(i,3))],[a_z,z(1:Label(i,3))]);
                    end
                end
                hold off
    end
    if write_on
        n = size(Label,1);
        s = 2:(n+1);
        P = zeros(n+1,1);
        L = zeros(n+1,1);
        Landmark = cell(n+1,2);
        LM = -1*ones(n+1,2);
        for i = 1:n
            if Parent(i,2) > -1
                indicator = logical((Label(:,1)==Parent(i,1)).*(Label(:,2)==Parent(i,2)).*(Label(:,3)==Parent(i,3)));
                P(i+1) = s*indicator;
            else
                P(i+1) = 1;
            end
            if Label(i,1) == 5
                Landmark{i+1,1} = 'left' ;
                Landmark{i+1,2} = Label(i,2);
                LM(i+1) = Label(i,2);
            elseif Label(i,1) == 6;
                Landmark{i+1,1} = 'right';
                Landmark{i+1,2} = Label(i,2);
                LM(i+1) = 64+Label(i,2);
            else
                Landmark{i+1,1} = '-1';
                Landmark{i+1,2} = -1;
            end
        end
        L(2:n+1) = Length;
        L(1) = 20;
        P(1) = -1;
        Landmark{1,1} = '-1';
        Landmark{1,2} = -1;
        %% write truncated tree to text file
        %%% header
        if case_num< 10
            case_num_txt = strcat( '00',num2str(case_num));
        elseif case_num < 100
            case_num_txt = strcat('0',num2str(case_num));
        else
            case_num_txt = num2str(case_num);
        end
        fid = fopen(strcat('C:\Users\Sean\Desktop\test delete me\NormalA-',case_num_txt,'.txt'),'w');
        format = '%s';
        A = '% Label Parent Length Landmark';
        fprintf(fid,format,A);
        
        %%% data
        for i = 1:size(P,1);
            A = [num2str(i),' ', num2str(P(i)), ' '];
            format = '\n %s %s %s %s';
            fprintf(fid,format,A);
            fprintf(fid,'%g',L(i));
            fwrite(fid,' ');
            fwrite(fid,num2str(LM(i)));
            %             fwrite(fid,Landmark{i,1});
            %             fwrite(fid,[' ',num2str(Landmark{i,2})]);
        end
        fclose(fid);
    end
end
if coverage_info_on
    
    total_length = 0;
    subtree_length = 0;
    total_dist_lm = 0;
    for tree = 1:4
        head = ARTERY_TUBES{tree,1};
        X = ARTERY_TUBES{tree,2};
        Y = ARTERY_TUBES{tree,3};
        Z = ARTERY_TUBES{tree,4};
        for i = 1:length(X)
            x = X{i}; y = Y{i}; z = Z{i};
            %                         m = length(x);
            %                         x = x(2:m); y = y(2:m); z = z(2:m);
            total_length = total_length+arclength(x,y,z);
            % plot from child to parent
            parent = head(i,2);
            if parent > 0
                x_att = X{head(:,1)==parent}(head(i,3));
                y_att = Y{head(:,1)==parent}(head(i,3));
                z_att = Z{head(:,1)==parent}(head(i,3));
                total_length = total_length+arclength([x_att,x(1)],[y_att,y(1)],[z_att,z(1)]);
            end
        end
    end
    for i = 1:length(Label)
        clear x y z
        if Label(i,1) == 5 || Label(i,1) ==6
            % landmark to tree edge
            if Label(i,1) == 5
                x(1)=-C_left(Label(i,2),1);
                y(1)=-C_left(Label(i,2),2);
                z(1)=C_left(Label(i,2),3);
                x(2)=I_left(Label(i,2),4);
                y(2)=I_left(Label(i,2),5);
                z(2)=I_left(Label(i,2),6);
            else
                x(1)=-C_right(Label(i,2),1);
                y(1)=-C_right(Label(i,2),2);
                z(1)=C_right(Label(i,2),3);
                x(2)=I_right(Label(i,2),4);
                y(2)=I_right(Label(i,2),5);
                z(2)=I_right(Label(i,2),6);
            end
            total_dist_lm = total_dist_lm + arclength(x,y,z);
        elseif Parent(i,2) == -1
            % branch to super root edge
            head = ARTERY_TUBES{Label(i,1),1};
            X = ARTERY_TUBES{Label(i,1),2};
            Y = ARTERY_TUBES{Label(i,1),3};
            Z = ARTERY_TUBES{Label(i,1),4};
            indicator = head(:,1)==Label(i,2);
            x=X{indicator};
            y = Y{indicator};
            z = Z{indicator};
            a_x = location_root(1);
            a_y = location_root(2);
            a_z = location_root(3);
        elseif Label(i,2) == Parent(i,2)
            % within branch edge
            head = ARTERY_TUBES{Label(i,1),1};
            X = ARTERY_TUBES{Label(i,1),2};
            Y = ARTERY_TUBES{Label(i,1),3};
            Z = ARTERY_TUBES{Label(i,1),4};
            indicator = head(:,1)==Label(i,2);
            x = X{indicator};
            y = Y{indicator};
            z = Z{indicator};
            subtree_length = subtree_length + arclength(x(Parent(i,3):Label(i,3)),y(Parent(i,3):Label(i,3)),z(Parent(i,3):Label(i,3)));
        elseif Label(i,2) ~= Parent(i,2)
            % inter branch edge
            head = ARTERY_TUBES{Label(i,1),1};
            X = ARTERY_TUBES{Label(i,1),2};
            Y = ARTERY_TUBES{Label(i,1),3};
            Z = ARTERY_TUBES{Label(i,1),4};
            indicator = head(:,1)==Label(i,2);
            x = X{indicator};
            y = Y{indicator};
            z = Z{indicator};
            indicator = head(:,1)==Parent(i,2);
            x2 = X{indicator};
            y2 = Y{indicator};
            z2 = Z{indicator};
            a_x = x2(Parent(i,3));
            a_y = y2(Parent(i,3));
            a_z = z2(Parent(i,3));
            subtree_length = subtree_length + arclength([a_x,x(1:Label(i,3))],[a_y,y(1:Label(i,3))],[a_z,z(1:Label(i,3))]);
        end
    end
end
outstruct.I_left = I_left;
outstruct.I_right = I_right;
end
%% Subfunctions
    function AL = arclength(x,y,z)
        % Input: x,y,z are ordered coordinates (1 by n) vectors
        %        along a curve
        %        i.e. a 3D plot of x,y,z would look like that curve
        
        % Output: the approximate length of that curve
        
        n = length(x);% == length(y) == length(z)
        al = 0;
        for i = 1:(n-1)
            x1 = x(i); y1 = y(i); z1 = z(i);
            x2 = x(i+1); y2 = y(i+1); z2 = z(i+1);
            al = al + sqrt((x2-x1)^2+(y2-y1)^2+(z2-z1)^2);
        end
        AL = al;
    end

    function  x = compute_x_coordinates(i,Childrens,Label,Leaf_left2right_label)
        if Label(i,1) == 5 || Label(i,1) == 6
            x = zeros(size(Label,1),1); % create a vector of zeros with a
            % element for each leaf in the tree
            x(i) =  Leaf_left2right_label(i); % this case occurs when i is a leaf
            % assigns x_coordinate of i as the
            % integer k such that i is the k'th
            % leaf in the left to right ordering
            % of leafs in the tree embedding;
        else
            x = zeros(size(Label,1),1);
            x_i = 0;
            if size(Childrens{i},2) > 1
                childrens = Childrens{i};
                k = size(childrens,1);
                for j = 1:k
                    current_structure = childrens(j,1);
                    current_component = childrens(j,2);
                    current_index = childrens(j,3);
                    indicator = logical((Label(:,1)==current_structure).*(Label(:,2)==current_component).*(Label(:,3)==current_index));
                    x = x + compute_x_coordinates(indicator,Childrens,Label,Leaf_left2right_label);
                    x_i = x_i + x(indicator)/k;
                end
            end
            x(i) = x_i;
            
        end
        
        
        
    end
