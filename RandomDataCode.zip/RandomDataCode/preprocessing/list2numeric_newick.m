function [s,x] = list2numeric_newick(Label,Parent,Landmark,L)
% -1 go down to subtree  
% -2 come up from subtree
% , go over to next child
%% test example
% Label = 1:8;
% Parent(1) = -1; Landmark(1) = -1; Length(1) = 0;
% Parent(2) = 1; Landmark(2) = -1; Length(2) = 0.1;
% Parent(3) = 1; Landmark(3) = 2; Length(3) = 0.2;
% Parent(4) = 1; Landmark(4) = -1; Length(4) = 0.5;
% Parent(5) = 4; Landmark(5) = 3; Length(5) = 0.3;
% Parent(6) = 4; Landmark(6) = 4; Length(6) = 0.4;
% Parent(7) = 2; Landmark(7) = 1; Length(7) = 0.7;
% Parent(8) = 2; Landmark(8) = 5; Length(8) = 0.8;
% 
% 
% % A is 1
% % B is 2
% % C is 3
% % D is 4

%%
%%%% find children 
Children = cell(size(Label));
for i = 1:length(Label)
    child_counter = 0;
    children_labels = -1*ones(1,10);
    for j = 1:length(Label)
        if Parent(j) == Label(i)
                child_counter = child_counter+1;
                children_labels(child_counter) = Label(j);
        end
    end
    Children{i} = children_labels(children_labels>=0);
end

LIST1 = [Label(Parent==-1) 10000000]; % 10000000 is a dummy element
marker = zeros(size(Label));
k = length(LIST1);

s = [0 -1];
x=[];
while k > 1
    label = LIST1(1);
    i = [1:length(Label)]*[Label == label]';
    if ~isempty(Children{i})
        if marker(i)==false
            x(end+1)=L(i);
            marker(i) = true;
        end
        t = size(Children{i},2);
        c = [1:length(Label)]*[Label == Children{i}(1)]';
        if ~isempty(Children{c})
            s(end+1)=-1;
            LIST1 = [c LIST1];
        else
            if Landmark(c) > -1;
                x(end+1)=L(c);
                s(end+1) = -1;
                s(end+1) = Landmark(c);
                s(end+1) = -2;
            else
                display('list2newick: error1')
            end
        end
        Children{i} = Children{i}(2:t);
    else
        if Parent(i) > 0
            s(end+1)=-2;
        else
        end
        LIST1 = LIST1(2:k);
    end
    k = length(LIST1);
end

s(end+1)=-2;