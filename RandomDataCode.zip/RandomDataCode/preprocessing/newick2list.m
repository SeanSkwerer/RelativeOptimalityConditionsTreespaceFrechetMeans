function [Label,Parent,Landmark,Length] = newick2list(s,options)

%% test example
% s = '((1:0.7,5:0.8):0.1,2:0.2,(3:0.3,4:0.4):0.5):0' ;

% s = '(((C:12.1668,(D:11.2636,(E:1.7878,F:1.7878):9.4758):0.903):9.8614,(G:4.1318,H:4.1318):17.8964):25.9718,(A:5.5826,B:5.5826):42.4174)';
% s = '(((C:12.2024,(D:11.3775,(E:3.14702,F:3.14702):8.23044):0.824698):10.1843,(G:6.18841,H:6.18841):16.1983):26.2359,(A:6.60938,B:6.60938):42.0132)';
% s = '(((C:14.9758,(D:11.6617,(E:2.32366,F:2.32366):9.338):3.31396):8.47567,(G:4.38054,H:4.38054):19.0709):25.1884,(A:7.64668,B:7.64668):40.9932)';
%%
% options
newick1 = false; % written for the trees Megan sent in Fall 2010
newick2 = true; % written for the trees in from Megan 4.19.11
newick3 = false; % written for the trees in from Megan 4.13.11
change_leaf_label_alpha2num = false;
if nargin > 1
    if isfield(options,'use_newick_num')
        use_newick_num = options.use_newick_num;
    if use_newick_num == 1
        newick1 = true;
        newick2 = false;
        newick3 = false;
    elseif use_newick_num == 2
        newick1 = false;
        newick2 = true;
        newick3 = false;
    elseif use_newick_num == 3
        newick1 = false;
        newick2 = false;
        newick3 = true;
    end
    end
    if isfield(options,'leaf_label_alpha2num')
        change_leaf_label_alpha2num = options.leaf_label_alpha2num;
    end
end
if change_leaf_label_alpha2num
    n = length(s);
    for i = 1:n
        if strcmp('A',s(i))
            s(i) = '1';
        end
        if strcmp('B',s(i))
            s(i) = '2';
        end
        if strcmp('C',s(i))
            s(i) = '3';
        end
        if strcmp('D',s(i))
            s(i) = '4';
        end
        if strcmp('E',s(i))
            s(i) = '5';
        end
        if strcmp('F',s(i))
            s(i) = '6';
        end
        if strcmp('G',s(i))
            s(i) = '7';
        end
        if strcmp('H',s(i))
            s(i) = '8';
        end
        if strcmp(s(i),'I')
            s(i) = '9';
        end
        % could make this work for more alpha labels ...
    end
end
if newick1
    n = length(s);
    c = 0; % current edge (the root edge is 1)
    p = -1; % current parent (-1 means no parent)
    label = 0; % current label (the first label is 1)
    i= 1;
    while i < n
        if s(i) == '(';
            label = label +1;
            c = label;
            Parent(label) = p;
            Landmark(label) = -1;
            Label(label) = label;
            p = c;
            i = i+1;
        elseif s(i) == ')'
            p = Parent(c);
            while s(i) ~= ':'
                i = i+1;
            end
            % s(i) == ':'
            i = i+1; % first digit of length
            k = i;
            while s(k+1) ~= ' ' && k+1 < n
                k = k+1;
            end
            %k last digit of length
            Length(p) = str2num(s(i:k));
            i = k+2;
            c = p;
            p = Parent(c);
        elseif s(i) == ','
            i = i+1;
        else
            label = label+1;
            Label(label) = label;
            Parent(label) = p;
            Landmark(label) = str2num(s(i));
            while s(i) ~= ':'
                i = i+1;
            end
            % s(i) == ':'
            i = i+1; % first digit of length
            k = i;
            while s(k+1) ~= ' ' && k+1 < n
                k = k+1;
            end
            % k is last digit of length
            Length(label) = str2num(s(i:k));
            i = k+2;
            c = label;
        end
    end
    
elseif newick2
    n = length(s);
    c = 0; % current edge (the root edge is 1)
    p = -1; % current parent (-1 means no parent)
    label = 0; % current label (the first label is 1)
    i= 1;
    while i < n
        if s(i) == '(';
            label = label +1;
            c = label;
            Parent(label) = p;
            Landmark(label) = -1;
            Label(label) = label;
            p = c;
            i = i+1;
        elseif s(i) == ')'
            p = Parent(c);
            while s(i) ~= ':' && s(i) ~= ';'
                i = i+1;
            end
            if s(i) == ';'
                break
            end
            % s(i) == ':'
            i = i+1; % first digit of length
            k = i;
            while s(k+1) ~= ',' && s(k+1) ~= ')' && k+1 < n
                k = k+1;
            end
            %k last digit of length
            Length(p) = str2num(s(i:k));
            i = k+1;
            c = p;
            p = Parent(c);
        elseif s(i) == ','
            i = i+1;
        else
            label = label+1;
            Label(label) = label;
            Parent(label) = p;
            k = i;
            while s(k+1) ~= ':'
                k = k+1;
            end
            Landmark(label) = str2num(s(i:k));
            i = k+1;
            % s(i) == ':'
            i = i+1; % first digit of length
            k = i;
            while s(k+1) ~= ',' && s(k+1) ~= ')' && k+1 < n
                k = k+1;
            end
            % k is last digit of length
            Length(label) = str2num(s(i:k));
            i = k+1;
            c = label;
        end
    end
elseif newick3
    n = length(s);
    c = 0; % current edge (the root edge is 1)
    p = -1; % current parent (-1 means no parent)
    label = 0; % current label (the first label is 1)
    i= 1;
    while i < n
        if s(i) == '(';
            label = label +1;
            c = label;
            Parent(label) = p;
            Landmark(label) = -1;
            Label(label) = label;
            p = c;
            i = i+1;
        elseif s(i) == ')'
            p = Parent(c);
            while s(i) ~= ':' && s(i) ~= ';'
                i = i+1;
            end
            if s(i) == ';'
                break
            end
            % s(i) == ':'
            i = i+1; % first digit of length
            k = i;
            while s(k+1) ~= ',' && s(k+1) ~= ')' && k+1 < n
                k = k+1;
            end
            %k last digit of length
            Length(p) = str2num(s(i:k));
            i = k+1;
            c = p;
            p = Parent(c);
        elseif s(i) == ','
            i = i+1;
        else
            label = label+1;
            Label(label) = label;
            Parent(label) = p;
            k = i;
            while s(k+1) ~= ':'
                k = k+1;
            end
            Landmark(label) = str2num(s(i+1:k));
            i = k+1;
            % s(i) == ':'
            i = i+1; % first digit of length
            k = i;
            while s(k+1) ~= ',' && s(k+1) ~= ')' && k+1 < n
                k = k+1;
            end
            % k is last digit of length
            Length(label) = str2num(s(i:k));
            i = k+1;
            c = label;
        end
    end
end