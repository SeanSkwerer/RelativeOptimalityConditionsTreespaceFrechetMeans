sub_use_ind = zeros(1,109);
for i = 1:109
    if i < 10
        if exist(strcat('C:\Users\Sean\Documents\Data\Trees\DataSet3_unzipped\DataSet3\NormalA-00',num2str(i)))
            sub_use_ind(i) = 1;
        end
    elseif i < 100
        if exist(strcat('C:\Users\Sean\Documents\Data\Trees\DataSet3_unzipped\DataSet3\NormalA-0',num2str(i)))
            sub_use_ind(i) = 1;
        end
    else
        if exist(strcat('C:\Users\Sean\Documents\Data\Trees\DataSet3_unzipped\DataSet3\NormalA-',num2str(i)))
            sub_use_ind(i) = 1;
        end
    end
end
