function plot_tree(Label,Parent,Length,options)
% set options to defaults
titlestr = 'titlestr unspecified';
planarembed = true;
% unpack options structure if specified
clr = 'blue';
newfig = true;
edgelabels = false;
plot_lengths = true;
horiz_line_style = 'solid'; % or 'dashed'
if nargin > 3
    if isfield(options,'titlestr')
        titlestr = options.titlestr;
    end
    if isfield(options,'planarembed')
        planarembed = options.planarembed;
        if planarembed == false
            if isfield(options,'Leaf_left2right_label')
                Leaf_left2right_label = options.Leaf_left2right_label;
            end
        else
            disp('***************************************************************')
            disp('*planarembed == false -> specify options.Leaf_left2right_label*')
            disp('***************************************************************')
        end
    end
    if isfield(options,'color')
        clr = options.color;
    end
    if isfield(options,'newfig')
        newfig = options.newfig;
    end
    if isfield(options,'EdgeLabels')
        EdgeLabels = options.EdgeLabels;
        edgelabels = true;
    end
    if isfield(options,'plot_lengths')
        plot_lengths = options.plot_lengths;
    end
    if isfield(options,'horiz_line_style')
        horiz_line_style = options.horiz_line_style;
    end
end
%%%% find children
Children = cell(size(Label));
for i = 1:length(Label)
    child_counter = 0;
    children_labels = -1*ones(1,10);
    for j = 1:length(Label)
        if Parent(j) == Label(i)
            child_counter = child_counter+1;
            children_labels(child_counter) = Label(j);
        end
    end
    Children{i} = children_labels(children_labels>=0);
end
clear children_labels child_counter

%%%% compute the distance from the root of each segment
Distance_from_root = zeros(size(Label));
LIST = [Label(Parent==-1) 10000000]; % 10000000 is a dummy element
k = length(LIST);
while k > 1
    label = LIST(1);
    i = [1:length(Label)]*[Label == label]';
    LIST = LIST(2:k);
    if Parent(i) == -1
        Distance_from_root(i) = Length(i);
    else
        Distance_from_root(i) = Length(i) + Distance_from_root(Label == Parent(i));
    end
    if ~isempty(Children{i})
        LIST = [Children{i} LIST];
    end
    k = length(LIST);
end

if planarembed
    %%%% give the tree an embedding (i.e. a left to right ordering of children)
    % depth first search on the tree
    % the i'th leaf reached is labeled leaf i
    % 1 is the left most leaf ... n is the right most leaf
    leaf_counter = 0;
    Leaf_left2right_label = -1*ones(size(Label));
    LIST = [Label(Parent==-1) 10000000]; % 10000000 is a dummy element
    k = length(LIST);
    LIST2 = LIST;
    c = 0;
    while 1 == 1
        c = c+1;
        label = LIST(1);
        if label == 10000000
            break
        end
        LIST = LIST(2:k);
        i = [1:length(Label)]*[Label == label]';
        if isempty(Children{i})
            leaf_counter = leaf_counter +1;
            Leaf_left2right_label(i) = leaf_counter;
        else
            LIST = [Children{i} LIST];
            LIST2 = union(LIST2,Children{i});
        end
        k = length(LIST);
    end
    clear LIST LIST2 label c i leaf_counter
end

x_coordinates_2D = compute_x_coordinates(1,Children,Leaf_left2right_label,Label);

if nargin > 3
    if isfield(options,'shift')
        root_x = options.shift.x;
        root_y = options.shift.y;
    else
        root_x = 0;
        root_y = 0;
    end
else
    root_x = 0;
    root_y = 0;
end

%%% create the 2-D visualization for the truncated tree
if newfig
    figure
end
hold on
m = mean(x_coordinates_2D(Parent == -1));
plot( [m,m]+root_x,[0,Length(1)]+root_y,'LineWidth',1.5,'color',clr)
if nargin > 3
    if isfield(options,'leaf_labels');
        if ~isempty(options.leaf_labels{1})
            text(m-0.2+root_x,0.05+root_y,options.leaf_labels{1});
        end
    end
end
LIST = [Label(Parent==1) 10000000]; % 10000000 is a dummy element
k = length(LIST);
while k > 1
    label = LIST(1);
    i = [1:length(Label)]*[Label == label]';
    LIST = LIST(2:k);
    if ~isempty(Children{i})
        plot([x_coordinates_2D(i), x_coordinates_2D(i)]+root_x,...
            [Distance_from_root(i)-Length(i), Distance_from_root(i)]+root_y, ...
            'color',clr, ...
            'LineWidth',1.5);
        parent_index = [1:length(Label)]*[Label == Parent(i)]';
        if strcmp(horiz_line_style,'solid')
            plot( [x_coordinates_2D(i),x_coordinates_2D(parent_index)]+root_x,...
                [Distance_from_root(i)-Length(i),Distance_from_root(i)-Length(i)]+root_y,...
                'k');
        else
            plot( [x_coordinates_2D(i),x_coordinates_2D(parent_index)]+root_x,...
                [Distance_from_root(i)-Length(i),Distance_from_root(i)-Length(i)]+root_y,...
                ':k');
        end
        if plot_lengths
            text(x_coordinates_2D(i)+0.1+root_x,root_y+Distance_from_root(i)-Length(i)/2,num2str(Length(i)))
        end
        if edgelabels
            text(x_coordinates_2D(i)+0.1+root_x,root_y+Distance_from_root(i)-3*Length(i)/4,EdgeLabels{i})
        end
        
        LIST = [Children{i} LIST];
    else
        plot([x_coordinates_2D(i), x_coordinates_2D(i)]+root_x,...
            [Distance_from_root(i)-Length(i), Distance_from_root(i)]+root_y, ...
            'color',clr, ...
            'LineWidth',1.5);
        %         plot(x_coordinates_2D(i),Distance_from_root(i),'k.');
        text(x_coordinates_2D(i),Distance_from_root(i)+root_y,num2str(options.Landmark(i)))
        if nargin > 3
            if isfield(options,'leaf_labels');
                text(x_coordinates_2D(i)-0.1+root_x,Distance_from_root(i)+0.65+root_y,options.leaf_labels{i});
            end
        end
        parent_index = [1:length(Label)]*[Label == Parent(i)]';
        if strcmp(horiz_line_style,'solid')
            
            plot( [x_coordinates_2D(i),x_coordinates_2D(parent_index)]+root_x,...
                [Distance_from_root(i)-Length(i),Distance_from_root(i)-Length(i)]+root_y,...
                'k');
        else
            plot( [x_coordinates_2D(i),x_coordinates_2D(parent_index)]+root_x,...
                [Distance_from_root(i)-Length(i),Distance_from_root(i)-Length(i)]+root_y,...
                ':k');
        end
    end
    k = length(LIST);
end
hold off
title(titlestr)
ylabel('Distance from Root')
if nargin > 3
    if isfield(options,'axis')
        axis(options.axis);
    end
else
    %     axis([0 130 0 450])
end
%% subfunctions
function  x = compute_x_coordinates(label,Children,Leaf_left2right_label,Label)
% Type(i) = 1  if segment i is an internal segment
%           2  if segment i is a landmark segment from the right
%           hemisphere
%           3  if segment i is a landmark segment from the left
%           hemisphere
%           4  if segment i is a loose end segment
%           5  if segment i is the first segment of a tube
%           6  if segment i is the first and last semgent of a tube
%           7 if segment i is the segments form the super root to a
%             sub-super root

i = [1:length(Label)]*[Label == label]';
if ~isempty(Children{i})
    x = zeros(size(Children));
    x_i = 0;
    k = size(Children{i},2);
    for j = 1:k
        x = x + compute_x_coordinates(Children{i}(j),Children,Leaf_left2right_label,Label);
        index = [1:length(Label)]*[Label == Children{i}(j)]';
        x_i = x_i + x(index)/k;
    end
    x(i) = x_i;
else
    x = zeros(size(Children)); % create a vector of zeros with a
    % element for each leaf in the tree
    x(i) =  Leaf_left2right_label(i); % this case occurs when i is a leaf
    % assigns x_coordinate of i as the
    % integer k such that i is the k'th
    % leaf in the left to right ordering
    % of leafs in the tree embedding
    %else
    %   x = zeros(size(Type));
end
