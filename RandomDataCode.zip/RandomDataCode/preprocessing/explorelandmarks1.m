load_workspace = true;
if load_workspace
    load explorelandmarks1.mat;
end
read_landmark_info = false;
save_workspace = false;
organize_att_tree = true;
plot_att_tree = false;
make_tree_att_cnt = true;
basic_stats_tree_att_cnt = true;
plot_att_pmf = false;
plot_att_cmf = true;

use_emerald = false;
use_Java_figure = true;
if use_emerald
    use_Java_figure = false;
end

if read_landmark_info
    plot_on = false;
    write_on = false;
    write_lm = false;
    coverage_info_on = true;
    % 109
    %for count=25
    t = 0;
    artery_coverage_info = [];
    for count = 1:109
        if count<10
            name1 = strcat('C:\Users\Sean\Documents\Data\Trees\DataSet3 1\NormalA-00',num2str(count));
            name2l = strcat('C:\Users\Sean\Documents\Data\Trees\Landmark_Cortical_Surface_data_alternative\NormalA-00',num2str(count),'\surf\left.registered.lpts');
            name2r = strcat('C:\Users\Sean\Documents\Data\Trees\Landmark_Cortical_Surface_data_alternative\NormalA-00',num2str(count),'\surf\right.registered.lpts');
        elseif count<100
            name1 = strcat('C:\Users\Sean\Documents\Data\Trees\DataSet3 1\NormalA-0',num2str(count));
            name2l = strcat('C:\Users\Sean\Documents\Data\Trees\Landmark_Cortical_Surface_data_alternative\NormalA-0',num2str(count),'\surf\left.registered.lpts');
            name2r = strcat('C:\Users\Sean\Documents\Data\Trees\Landmark_Cortical_Surface_data_alternative\NormalA-0',num2str(count),'\surf\right.registered.lpts');
        else % count > 100
            name1 = strcat('C:\Users\Sean\Documents\Data\Trees\DataSet3 1\NormalA-',num2str(count));
            name2l = strcat('C:\Users\Sean\Documents\Data\Trees\Landmark_Cortical_Surface_data_alternative\NormalA-',num2str(count),'\surf\left.registered.lpts');
            name2r = strcat('C:\Users\Sean\Documents\Data\Trees\Landmark_Cortical_Surface_data_alternative\NormalA-',num2str(count),'\surf\right.registered.lpts');
        end
        strcat(name1,'\aca.tre')
        if exist(strcat(name1,'\aca.tre'))==2 && exist(name2l) == 2
            count
            outstruct = read_and_visualize_selectout(name1,name2l,name2r,count,plot_on,write_on,coverage_info_on);
            t = t+1;
            landmark_info{1,t} = outstruct;
        end
        fopen('all')
        fclose('all')
    end
    if save_workspace
        save('explorelandmarks1.mat');
    end
end


if organize_att_tree
    %I(i,1) = the index of the tree (anterior=1, posterior=2, right=3, left=4)
    % or is it (anterior=1, right=2, posterior=3, left=4)?
    for i = 1:t
        tree_att(1:64,i) = landmark_info{1,i}.I_left(:,1);
        tree_att(65:128,i) = landmark_info{1,i}.I_right(:,1);
    end
end
if plot_att_tree
    f1 = figure;
    if use_Java_figure
        set(f1,'WindowStyle','docked');
    end
    hold on
    for i = 1:128
        for j = 1:t
            plot(i+(rand(1)/10-0.05),tree_att(i,j)+(rand(1)/10-0.05),'*');
        end
        plot([i i],[0 4],'r-')
    end
    hold off
    title('Attachment Trees: Left Landmarks');
    xlabel('Landmark Label');
    ylabel('Attchement Tree');
end

if make_tree_att_cnt
    tree_att_cnt = zeros(4,128);
    for i = 1:t
        for j = 1:128
            tree_att_cnt(tree_att(j,i),j) = tree_att_cnt(tree_att(j,i),j)+1;
        end
    end
end

if basic_stats_tree_att_cnt
    sum(sum(tree_att_cnt==85))
    % ans = 16
    
    sum(sum(tree_att_cnt>80))
    %ans = 78;
    
    sum(sum(tree_att_cnt>70))
    %ans = 101;
    
    sum(sum(tree_att_cnt>60))
    %ans = 112
    
    sum(sum(tree_att_cnt>50))
    %ans = 119
    
    sum(sum(tree_att_cnt > 42))
    %ans = 126
    
end

if plot_att_pmf
    f1 = figure;
    if use_Java_figure
        set(f1,'WindowStyle','docked');
    end
    hold on
    plot(42,2,'*');
    for i = 43:1:85
        plot(i,sum(sum(tree_att_cnt==i)),'*');
    end
    hold off
    title('Number of Landmarks that are Attached to the Same Tree (L,B,R or F) in x Subjects')
    ylabel('Number of Landmarks')
    xlabel('Number of Subjects')
    orient landscape
        print('-dpsc2','explorelandmarks1_pmf.ps');
end
if plot_att_cmf
    f1 = figure;
    if use_Java_figure
        set(f1,'WindowStyle','docked');
    end
    hold on
    cm = 2;
    plot(42,cm,'*');
    for i = 43:85
        cm = cm+sum(sum(tree_att_cnt==i));
        plot(i,cm,'*');
    end
    hold off
    title('Number of Landmarks that are Attached to the Same Tree (L,B,R or F) in x Subjects Cumul.')
     ylabel('Number of Landmarks')
    xlabel('Number of Subjects')
    orient landscape
        print('-dpsc2','explorelandmarks1_cmf.ps');
end