plot_on = false;
write_on = true;
coverage_info_on = false;
% 109
%for count=25
t = 0;
artery_coverage_info = [];
for count = 6:109
    if count<10
        name1 = strcat('C:\Users\Sean\Documents\Data\Trees\DataSet3_unzipped\DataSet3\NormalA-00',num2str(count));
        name2l = strcat('C:\Users\Sean\Documents\Data\Trees\Landmarks_v2\leftMRAwhite\NormalA-00',num2str(count),'_lh_xyzSDnormal.lpts');
        name2r = strcat('C:\Users\Sean\Documents\Data\Trees\Landmarks_v2\rightMRAwhite\NormalA-00',num2str(count),'_rh_xyzSDnormal.lpts');
    elseif count<100
        name1 = strcat('C:\Users\Sean\Documents\Data\Trees\DataSet3_unzipped\DataSet3\NormalA-0',num2str(count));
        name2l = strcat('C:\Users\Sean\Documents\Data\Trees\Landmarks_v2\leftMRAwhite\NormalA-0',num2str(count),'_lh_xyzSDnormal.lpts');
        name2r = strcat('C:\Users\Sean\Documents\Data\Trees\Landmarks_v2\rightMRAwhite\NormalA-0',num2str(count),'_rh_xyzSDnormal.lpts');
    else % count > 100
        name1 = strcat('C:\Users\Sean\Documents\Data\Trees\DataSet3_unzipped\DataSet3\NormalA-',num2str(count));
        name2l = strcat('C:\Users\Sean\Documents\Data\Trees\Landmarks_v2\leftMRAwhite\NormalA-',num2str(count),'_lh_xyzSDnormal.lpts');
        name2r = strcat('C:\Users\Sean\Documents\Data\Trees\Landmarks_v2\rightMRAwhite\NormalA-',num2str(count),'_rh_xyzSDnormal.lpts');
    end
    strcat(name1,'\aca.tre')
    if exist(strcat(name1,'\aca.tre'))==2 && exist(name2l) == 2 && exist(name2r) == 2
        count
        t = t+1;
       [A,Label,Parent,Childrens,total_length,subtree_length,total_dist_lm]= read_and_visualize(name1,name2l,name2r,count,plot_on,write_on,coverage_info_on);
       if coverage_info_on
    artery_coverage_info(1,t) = count;
    artery_coverage_info(2,t) = age(count); % age must be loaded from some .mat file?
    artery_coverage_info(3,t) = total_length;
    artery_coverage_info(4,t) = subtree_length;
    artery_coverage_info(5,t) = total_dist_lm;
       end
    end
end
save('DataSet3_LMv2.mat');
%  axis equal ;
%  axis vis3d ;
%  axis off ;
% n1=60;
% az = linspace(0,360,n1);
% %el = linspace(0,90,n1);
% for i = 1:n1
%     view([az(i) 15]);
%    %orient portrait
%     %saveas(h8,strcat('C:\Users\Sean\Desktop\test delete me\_',num2str(i),'.png '));
%     orient landscape
%     print('-dpsc2','-append','C:\Users\Sean\Desktop\test delete me\landmarks.orphans.360.60.ps')
% end