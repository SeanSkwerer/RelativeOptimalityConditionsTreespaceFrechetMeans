function [A,B,D] = merge_sort_binary(A,L,option)
%input:
% A is a matrix of splits with binary representation
% L is the vector of lengths

% output:
% option 1
% A becomes A sorted: zero is less than 1 and 0001 < 0010 < 0100
% option 2
% A becomes A sorted by row sums then by ordering above
% B is A without duplicates
% D duplicate info D{i} = vector of lengths of duplicates of B(i,:)

% test data
%A = [0 0 1 0 0; 0 1 0 0 0; 0 1 0 1 0; 1 0 0 0 0; 0 1 0 0 0];
if option == 1
    % m splits; n+1 leafs (root leaf is implicit)
    [m,n] = size(A);
    t = 1;
    while t <= floor(m/2)
        r = 0;
        while r < m
            p = r+1;
            q = r+t;
            r = r + 2*t;
            if r+t >= m
                r = m;
            end
            % t = 1 -> [p,q,r] = [1,1,2],[3,3,4], ...,[m-1,m-1,m] or [m,m,m+1]
            % t = 2 -> [p,q,r] = [1,2,4],[5,6,8], ...,[m-3,m-1,m] or [m-2,m-1,m]
            % t = ceil(m/2) -> [p,q,r] = [1,m/2,m] or [1,floor(m/2),m];
            % merge
            Left = [A(p:q,:);-1*ones(1,n)];
            Right = [A(q+1:r,:);-1*ones(1,n)];
            i = 1;j = 1;
            for k = p:r
                L_R_ind = false; % false -> left is greater or equal to right
                % true - > right is greater
                for l  = 1:n
                    % first entry l with clear winner ->  break the loop
                    % otherwise Right(j,:) == Left(i,:)
                    if Right(j,l) > Left(i,l)
                        L_R_ind = true;
                        break
                    elseif Left(i,l) > Right(j,l)
                        break;
                    end
                end
                if ~L_R_ind % Left(i) >= Right(j)
                    A(k,:) = Left(i,:);
                    i = i+1;
                else
                    A(k,:) = Right(j,:);
                    j = j+1;
                end
            end
        end
        t = 2*t;
    end
else
    % m splits; n+1 leafs (root leaf is implicit)
    [m,n] = size(A);
    t = 1;
    for i = 1:m
        if sum(A(i,:)) > n/2
            A(i,:) = ~A(i,:);
        end
    end
    while t <= floor(m/2)
        r = 0;
        while r < m
            p = r+1;
            q = r+t;
            r = r + 2*t;
            if r+t >= m
                r = m;
            end
            % t = 1 -> [p,q,r] = [1,1,2],[3,3,4], ...,[m-1,m-1,m] or [m,m,m+1]
            % t = 2 -> [p,q,r] = [1,2,4],[5,6,8], ...,[m-3,m-1,m] or [m-2,m-1,m]
            % t = ceil(m/2) -> [p,q,r] = [1,m/2,m] or [1,floor(m/2),m];
            % merge
            Left = [A(p:q,:);-1*ones(1,n)];
            Right = [A(q+1:r,:);-1*ones(1,n)];
            L_left = L(p:q);
            L_right = L(q+1:r);
            i = 1;j = 1;
            for k = p:r
                L_R_ind = false; % false -> left is greater or equal to right
                % true - > right is greater
                for l  = 1:n
                    if sum(Right(j,:)) > sum(Left(i,:))
                        L_R_ind = true;
                    else
                    % first entry l with clear winner ->  break the loop
                    % otherwise Right(j,:) == Left(i,:)
                        if Right(j,l) > Left(i,l)
                            L_R_ind = true;
                            break
                        elseif Left(i,l) > Right(j,l)
                            break;
                        end
                    end
                end
                if ~L_R_ind % Left(i) >= Right(j)
                    A(k,:) = Left(i,:);
                    L(k) = L_left(i);
                    i = i+1;
                else
                    A(k,:) = Right(j,:);
                    L(k) = L_right(j);
                    j = j+1;
                end
            end
        end
        t = 2*t;
    end
end
i = 1;
c = 0;
A = [A;-1*ones(1,n)];
while i <= m
    j = i+1;
    while sum(A(i,:)==A(j,:)) == n
        j = j+1;
    end
    c = c+1;
    B(c,:) = A(i,:);
    D{c} = L(i:j-1);
    i = j;
end