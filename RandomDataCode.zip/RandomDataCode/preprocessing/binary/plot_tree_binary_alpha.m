function plot_tree_binary_alpha(sigma_binary,Length,options)
% required fields:
% xy_location_root is a required field for options
% root_label is a required field for options

% !!!! Must Include leaves !!!


% set options to defaults
useleaves = true;
titlestr = 'titlestr';
windowsize = [0 130 0 450];
landmark_left2rightlabel = false;
edgecolor = [0 0 1];
leafcolor = [0 0 1];
iscolors4all = false;
options_bin2par = [];
delta = 0.04; delta2 = 0.017;% used to offset leaf labels
ylabelstr = 'Distance from Root(mm)';


plot_internal_edge_lengths = false;
plot_leaf_edge_lengths = false;
plot_leaf_labels = false;
labeled_root = false;
root_label = 1;
spread_tree_horiz = false;
remove_root_column = false;
plot_leaf_node = false;
label_the_root_0 = false;
% unpack options structure
if nargin > 2
    if isfield(options,'useleaves')
        useleaves = options.useleaves;
    end
    if isfield(options,'windowsize')
        windowsize = options.windowsize;
    end
    if isfield(options,'titlestr')
        titlestr = options.titlestr;
    end
    if isfield(options,'landmark_left2rightlabel')
        landmark_left2rightlabel = options.landmark_left2rightlabel;
    end
    if isfield(options,'axeshandle')
        axeshandle = options.axeshandle;
    end
    if isfield(options,'leafcolor')
        leafcolor = options.leafcolor;
    end
    if isfield(options,'edgecolor')
        edgecolor = options.edgecolor;
    end
    if isfield(options,'colors4all')
        colors4all = options.colors4all;
        iscolors4all = true;
    end
    if isfield(options,'root_label')
        labeled_root = true;
        options_bin2par.labeled_root = labeled_root;
        root_label = options.root_label;
        options_bin2par.root_label = root_label;
    end
    if isfield(options,'delta')
        delta = options.delta;
    end
    if isfield(options,'plot_internal_edge_lengths')
        plot_internal_edge_lengths = options.plot_internal_edge_lengths;
    end
    if isfield(options,'plot_leaf_edge_lengths')
        plot_leaf_edge_lengths = options.plot_leaf_edge_lengths;
    end
    if isfield(options,'plot_leaf_labels')
        plot_leaf_labels = options.plot_leaf_labels;
    end
    if isfield(options,'spread_tree_horiz')
        spread_tree_horiz = options.spread_tree_horiz;
    end
    if isfield(options,'ylabelstr')
        ylabelstr = options.ylabelstr;
    end
    if isfield(options,'label_the_root_0')
         label_the_root_0 = options.label_the_root_0;
    end
    if isfield(options,'remove_root_column')
        remove_root_column = options.remove_root_column;
        if remove_root_column
            if ~isfield(options,'root_column')
                disp('must specify root column if this remove_root_column is true')
            else
                root_column = options.root_column;
            end
        end
    end
    if isfield(options,'plot_leaf_node')
        plot_leaf_node = options.plot_leaf_node;
    end
end

if remove_root_column
        sigma_binary = [sigma_binary(:,1:(root_column-1)), sigma_binary(:,(root_column+1):size(sigma_binary,2))];
end
if ~iscolors4all
    [Label,Pars,Landmark] = bin2par(sigma_binary,options_bin2par);
    disp('Label')    
    disp(Label)
    disp('Pars')
        disp(Pars)
        disp('Landmark')
        disp(Landmark)
    for i = 1:size(Pars,2)
        Parent(i) = Pars{i};
    end
    %%%% find children
    Children = cell(size(Label));
    for i = 1:length(Label)
        child_counter = 0;
        children_labels = -1*ones(1,10);
        for j = 1:length(Label)
            if Parent(j) == Label(i)
                child_counter = child_counter+1;
                children_labels(child_counter) = Label(j);
            end
        end
        Children{i} = children_labels(children_labels>=0);
    end
    disp(Children)
    clear children_labels child_counter
    %%%% compute the distance from the root of each segment
    Distance_from_root = zeros(size(Label));
    LIST = [Label(Parent==-1) 10000000]; % 10000000 is a dummy element
    k = length(LIST);
    while k > 1
        label = LIST(1);
        i = [1:length(Label)]*[Label == label]';
        LIST = LIST(2:k);
        if Parent(i) == -1
            Distance_from_root(i) = Length(i);
        else
            Distance_from_root(i) = Length(i) + Distance_from_root(Label == Parent(i));
        end
        if ~isempty(Children{i})
            LIST = [Children{i} LIST];
        end
        k = length(LIST);
    end
    %%%% give the tree an embedding (i.e. a left to right ordering of children)
    % depth first search on the tree
    % the i'th leaf reached is labeled leaf i
    % 1 is the left most leaf ... n is the right most leaf
    leaf_counter = 0;
    Leaf_left2right_label = -1*ones(size(Label));
    LIST = [Label(Parent==-1) 10000000]; % 10000000 is a dummy element
    k = length(LIST);
    LIST2 = LIST;
    c = 0;
    while 1 == 1
        c = c+1;
        label = LIST(1);
        if label == 10000000
            break
        end
        LIST = LIST(2:k);
        i = [1:length(Label)]*[Label == label]';
        if isempty(Children{i})
            leaf_counter = leaf_counter +1;
            if landmark_left2rightlabel
                Leaf_left2right_label(i) = Landmark(Label==label);
            else
                Leaf_left2right_label(i) = leaf_counter;
            end
        else
            LIST = [Children{i} LIST];
            LIST2 = union(LIST2,Children{i});
        end
        k = length(LIST);
    end
    clear LIST LIST2 label c i leaf_counter
    if labeled_root
        x_coordinates_2D = compute_x_coordinates(root_label,Children,Leaf_left2right_label,Label);
    else
        x_coordinates_2D = compute_x_coordinates(1,Children,Leaf_left2right_label,Label);
    end
    if spread_tree_horiz
        x_coordinates_2D = x_coordinates_2D*5;
    end
    %%% create the 2-D visualization for the truncated tree
    if nargin < 3
       f1 = figure;
       set(f1,'WindowStyle','docked')
    else
        if ~isfield(options,'axeshandle')
            f1 = figure;
            set(f1,'WindowStyle','docked')
        else
            axeshandle;
        end
    end
    hold on
    m = mean(x_coordinates_2D(Parent == -1));
    plot( [m,m],[0,Length(root_label)],'LineWidth',1.5)
    plot( m,0,'.k')
    if label_the_root_0
    text(m,0-delta,'0')
    end
    LIST = [Label(Parent==root_label) 10000000]; % 10000000 is a dummy element
    k = length(LIST);
    while k > 1
        label = LIST(1);
        i = [1:length(Label)]*[Label == label]';
        LIST = LIST(2:k);
        if ~isempty(Children{i})
            plot([x_coordinates_2D(i), x_coordinates_2D(i)],...
                [Distance_from_root(i)-Length(i), Distance_from_root(i)], ...
                'color',edgecolor, ...
                'LineWidth',1.5);
            if plot_internal_edge_lengths
                text(x_coordinates_2D(i),mean([Distance_from_root(i)-Length(i), Distance_from_root(i)]), num2str(Length(i)));
            end
            parent_index = [1:length(Label)]*[Label == Parent(i)]';
            plot( [x_coordinates_2D(i),x_coordinates_2D(parent_index)],...
                [Distance_from_root(i)-Length(i),Distance_from_root(i)-Length(i)],...
                ':k');
            LIST = [Children{i} LIST];
        else
            if useleaves
                plot([x_coordinates_2D(i), x_coordinates_2D(i)],...
                    [Distance_from_root(i)-Length(i), Distance_from_root(i)], ...
                    'color',leafcolor, ...
                    'LineWidth',1.5);
                if plot_leaf_edge_lengths
                    text(x_coordinates_2D(i),mean([Distance_from_root(i)-Length(i), Distance_from_root(i)]),num2str(Length(i)));
                end
                if plot_leaf_node
                plot(x_coordinates_2D(i),Distance_from_root(i),'k.');
                end
                if plot_leaf_labels
                disp('here0')
                disp(Landmark(i))
                    if Landmark(i) < 10
                        text(x_coordinates_2D(i),Distance_from_root(i)+delta,num2str(Landmark(i)),'FontSize',6);
                    elseif Landmark(i) < 100
                        lm_str = num2str(Landmark(i));
                        text(x_coordinates_2D(i),Distance_from_root(i)+delta+delta2,lm_str(1),'FontSize',6);
                        text(x_coordinates_2D(i),Distance_from_root(i)+delta,lm_str(2),'FontSize',6);
                    else
                        lm_str = num2str(Landmark(i));
                        text(x_coordinates_2D(i),Distance_from_root(i)+delta+delta2*2,lm_str(1),'FontSize',6);
                        text(x_coordinates_2D(i),Distance_from_root(i)+delta+delta2,lm_str(2),'FontSize',6);
                        text(x_coordinates_2D(i),Distance_from_root(i)+delta,lm_str(3),'FontSize',6);
                    end
                end
                parent_index = [1:length(Label)]*[Label == Parent(i)]';
                plot( [x_coordinates_2D(i),x_coordinates_2D(parent_index)],...
                    [Distance_from_root(i)-Length(i),Distance_from_root(i)-Length(i)],...
                    ':k');
            end
        end
        k = length(LIST);
    end
    hold off
    title(titlestr)
    ylabel(ylabelstr)
    axis(windowsize)
    
    
else %if iscolors4all
    [Label,Pars,Landmark] = bin2par(sigma_binary,options_bin2par);
    
    for i = 1:size(Pars,2)
        Parent(i) = Pars{i};
    end
    %%%% find children
    Children = cell(size(Label));
    for i = 1:length(Label)
        child_counter = 0;
        children_labels = -1*ones(1,10);
        for j = 1:length(Label)
            if Parent(j) == Label(i)
                child_counter = child_counter+1;
                children_labels(child_counter) = Label(j);
            end
        end
        Children{i} = children_labels(children_labels>=0);
    end
    clear children_labels child_counter
    
    %%%% compute the distance from the root of each segment
    Distance_from_root = zeros(size(Label));
    LIST = [Label(Parent==-1) 10000000]; % 10000000 is a dummy element
    k = length(LIST);
    while k > 1
        label = LIST(1);
        i = [1:length(Label)]*[Label == label]';
        LIST = LIST(2:k);
        if Parent(i) == -1
            Distance_from_root(i) = Length(i);
        else
            Distance_from_root(i) = Length(i) + Distance_from_root(Label == Parent(i));
        end
        if ~isempty(Children{i})
            LIST = [Children{i} LIST];
        end
        k = length(LIST);
    end
    
    %%%% give the tree an embedding (i.e. a left to right ordering of children)
    % depth first search on the tree
    % the i'th leaf reached is labeled leaf i
    % 1 is the left most leaf ... n is the right most leaf
    leaf_counter = 0;
    Leaf_left2right_label = -1*ones(size(Label));
    LIST = [Label(Parent==-1) 10000000]; % 10000000 is a dummy element
    k = length(LIST);
    LIST2 = LIST;
    c = 0;
    while 1 == 1
        c = c+1;
        label = LIST(1);
        if label == 10000000
            break
        end
        LIST = LIST(2:k);
        i = [1:length(Label)]*[Label == label]';
        if isempty(Children{i})
            leaf_counter = leaf_counter +1;
            if landmark_left2rightlabel
                Leaf_left2right_label(i) = Landmark(Label==label);
            else
                Leaf_left2right_label(i) = leaf_counter;
            end
        else
            LIST = [Children{i} LIST];
            LIST2 = union(LIST2,Children{i});
        end
        k = length(LIST);
    end
    clear LIST LIST2 label c i leaf_counter
    if labeled_root
        x_coordinates_2D = compute_x_coordinates(root_label,Children,Leaf_left2right_label,Label);
    else
        x_coordinates_2D = compute_x_coordinates(1,Children,Leaf_left2right_label,Label);
    end
    if spread_tree_horiz
        x_coordinates_2D = x_coordinates_2D*5;
    end
    %%% create the 2-D visualization for the truncated tree
    if nargin < 3
        figure
    else
        if ~isfield(options,'axeshandle')
            figure
        else
            axeshandle;
        end
    end
    hold on
    m = mean(x_coordinates_2D(Parent == -1));
    plot( [m,m],[0,Length(root_label)],'LineWidth',1.5, 'color', colors4all(1,:))
    plot( m,0,'.k')
    plot( m,0-delta,'0')
    LIST = [Label(Parent==root_label) 10000000]; % 10000000 is a dummy element
    k = length(LIST);
    while k > 1
        label = LIST(1);
        i = [1:length(Label)]*[Label == label]';
        LIST = LIST(2:k);
        if ~isempty(Children{i})
            plot([x_coordinates_2D(i), x_coordinates_2D(i)],...
                [Distance_from_root(i)-Length(i), Distance_from_root(i)], ...
                'color',colors4all(i,:), ...
                'LineWidth',1.5);
            parent_index = [1:length(Label)]*[Label == Parent(i)]';
            plot( [x_coordinates_2D(i),x_coordinates_2D(parent_index)],...
                [Distance_from_root(i)-Length(i),Distance_from_root(i)-Length(i)],...
                ':k');
            LIST = [Children{i} LIST];
        else
            if useleaves
                plot([x_coordinates_2D(i), x_coordinates_2D(i)],...
                    [Distance_from_root(i)-Length(i), Distance_from_root(i)], ...
                    'color',colors4all(i,:), ...
                    'LineWidth',1.5);
                plot(x_coordinates_2D(i),Distance_from_root(i),'k.');
                text(x_coordinates_2D(i),Distance_from_root(i)+delta,num2str(Landmark(i)));
                parent_index = [1:length(Label)]*[Label == Parent(i)]';
                plot( [x_coordinates_2D(i),x_coordinates_2D(parent_index)],...
                    [Distance_from_root(i)-Length(i),Distance_from_root(i)-Length(i)],...
                    ':k');
                if plot_leaf_edge_lengths
                    text(x_coordinates_2D(i),mean([Distance_from_root(i)-Length(i), Distance_from_root(i)]),num2str(Length(i)));
                end
                if plot_leaf_node
                plot(x_coordinates_2D(i),Distance_from_root(i),'k.');
                end
                if plot_leaf_labels
                    if Landmark(i) < 10
                        text(x_coordinates_2D(i),Distance_from_root(i)+delta,num2str(Landmark(i)),'FontSize',6);
                    elseif Landmark(i) < 100
                        lm_str = num2str(Landmark(i));
                        text(x_coordinates_2D(i),Distance_from_root(i)+delta+delta2,lm_str(1),'FontSize',6);
                        text(x_coordinates_2D(i),Distance_from_root(i)+delta,lm_str(2),'FontSize',6);
                    else
                        lm_str = num2str(Landmark(i));
                        text(x_coordinates_2D(i),Distance_from_root(i)+delta+delta2*2,lm_str(1),'FontSize',6);
                        text(x_coordinates_2D(i),Distance_from_root(i)+delta+delta2,lm_str(2),'FontSize',6);
                        text(x_coordinates_2D(i),Distance_from_root(i)+delta,lm_str(3),'FontSize',6);
                    end
                end
            end
        end
        k = length(LIST);
    end
    hold off
    title(titlestr)
    ylabel(ylabelstr)
    axis(windowsize)
end
%% subfunctions
function  x = compute_x_coordinates(label,Children,Leaf_left2right_label,Label)
% Type(i) = 1  if segment i is an internal segment
%           2  if segment i is a landmark segment from the right
%           hemisphere
%           3  if segment i is a landmark segment from the left
%           hemisphere
%           4  if segment i is a loose end segment
%           5  if segment i is the first segment of a tube
%           6  if segment i is the first and last semgent of a tube
%           7 if segment i is the segments form the super root to a
%             sub-super root

i = [1:length(Label)]*[Label == label]';
if ~isempty(Children{i})
    x = zeros(size(Children));
    x_i = 0;
    k = size(Children{i},2);
    for j = 1:k
        x = x + compute_x_coordinates(Children{i}(j),Children,Leaf_left2right_label,Label);
        index = [1:length(Label)]*[Label == Children{i}(j)]';
        x_i = x_i + x(index)/k;
    end
    x(i) = x_i;
else
    x = zeros(size(Children)); % create a vector of zeros with a
    % element for each leaf in the tree
    x(i) =  Leaf_left2right_label(i); % this case occurs when i is a leaf
    % assigns x_coordinate of i as the
    % integer k such that i is the k'th
    % leaf in the left to right ordering
    % of leafs in the tree embedding
    %else
    %   x = zeros(size(Type));
end
