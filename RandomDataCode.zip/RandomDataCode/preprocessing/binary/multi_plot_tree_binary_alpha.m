function multi_plot_tree_binary_alpha(F_sigma_binary,F_Length,options)
% required fields:
% xy_location_root is a required field for options
% root_label is a required field for options

% set options to defaults
titlestr = 'titlestr';
windowsize = [0 130 0 450];
landmark_left2rightlabel = false;
% unpack options structure
if nargin > 2
    if isfield(options,'windowsize')
        windowsize = options.windowsize;
    end
    if isfield(options,'titlestr')
        titlestr = options.titlestr;
    end
    if isfield(options,'landmark_left2rightlabel')
        landmark_left2rightlabel = options.landmark_left2rightlabel;
    end
    if isfield(options,'axeshandle')
        axeshandle = options.axeshandle;
    end
    if isfield(options,'tree_options_seq')
        tree_options_seq = options.tree_options_seq;
    end
end
n_trees = length(F_sigma_binary);
xy_location_root = options.xy_location_root;
for tree_index = 1:n_trees
    sigma_binary = F_sigma_binary{1,tree_index};
    Length = F_Length{1,tree_index};
    % set tree_options to defaults
    useleaves = true;
    edgecolor = [0 0 1];
    leafcolor = [0 0 1];
    iscolors4all = false;
    options_bin2par = [];
    delta = 0.1; % used to offset leaf labels
    plot_internal_edge_lengths = false;
    plot_leaf_edge_lengths = false;
    plot_leaf_labels = true;
    % unpack tree_options for current tree
    if isfield(options,'tree_options_seq')
        tree_options = tree_options_seq{tree_index};
        if isfield(tree_options,'useleaves')
            useleaves = tree_options.useleaves;
        end
        if isfield(tree_options,'leafcolor')
            leafcolor = tree_options.leafcolor;
        end
        if isfield(tree_options,'edgecolor')
            edgecolor = tree_options.edgecolor;
        end
        if isfield(tree_options,'colors4all')
            colors4all = tree_options.colors4all;
            iscolors4all = true;
        end
        if isfield(tree_options,'root_label')
            labeled_root = true;
            options_bin2par.labeled_root = labeled_root;
            root_label = tree_options.root_label;
            options_bin2par.root_label = root_label;
        end
        if isfield(tree_options,'delta')
            delta = tree_options.delta;
        end
        if isfield(tree_options,'plot_internal_edge_lengths')
            plot_internal_edge_lengths = tree_options.plot_internal_edge_lengths;
        end
        if isfield(tree_options,'plot_leaf_edge_lengths')
            plot_leaf_edge_lengths = tree_options.plot_leaf_edge_lengths;
        end
        
    end
    if ~iscolors4all
        [Label,Pars,Landmark] = bin2par(sigma_binary,options_bin2par);
        for i = 1:size(Pars,2)
            Parent(i) = Pars{i};
        end
        %%%% find children
        Children = cell(size(Label));
        for i = 1:length(Label)
            child_counter = 0;
            children_labels = -1*ones(1,10);
            for j = 1:length(Label)
                if Parent(j) == Label(i)
                    child_counter = child_counter+1;
                    children_labels(child_counter) = Label(j);
                end
            end
            Children{i} = children_labels(children_labels>=0);
        end
        clear children_labels child_counter
        %%%% compute the distance from the root of each segment
        Distance_from_root = zeros(size(Label));
        LIST = [Label(Parent==-1) 10000000]; % 10000000 is a dummy element
        k = length(LIST);
        while k > 1
            label = LIST(1);
            i = [1:length(Label)]*[Label == label]';
            LIST = LIST(2:k);
            if Parent(i) == -1
                Distance_from_root(i) = Length(i);
            else
                Distance_from_root(i) = Length(i) + Distance_from_root(Label == Parent(i));
            end
            if ~isempty(Children{i})
                LIST = [Children{i} LIST];
            end
            k = length(LIST);
        end
        %%%% give the tree an embedding (i.e. a left to right ordering of children)
        % depth first search on the tree
        % the i'th leaf reached is labeled leaf i
        % 1 is the left most leaf ... n is the right most leaf
        leaf_counter = 0;
        Leaf_left2right_label = -1*ones(size(Label));
        LIST = [Label(Parent==-1) 10000000]; % 10000000 is a dummy element
        k = length(LIST);
        LIST2 = LIST;
        c = 0;
        while 1 == 1
            c = c+1;
            label = LIST(1);
            if label == 10000000
                break
            end
            LIST = LIST(2:k);
            i = [1:length(Label)]*[Label == label]';
            if isempty(Children{i})
                leaf_counter = leaf_counter +1;
                if landmark_left2rightlabel
                    Leaf_left2right_label(i) = Landmark(Label==label);
                else
                    Leaf_left2right_label(i) = leaf_counter;
                end
            else
                LIST = [Children{i} LIST];
                LIST2 = union(LIST2,Children{i});
            end
            k = length(LIST);
        end
        clear LIST LIST2 label c i leaf_counter
        
        if labeled_root
            x_coordinates_2D = compute_x_coordinates(root_label,Children,Leaf_left2right_label,Label);
        else
            x_coordinates_2D = compute_x_coordinates(1,Children,Leaf_left2right_label,Label);
        end
        x_coordinates_2D = x_coordinates_2D + xy_location_root(1,tree_index);
        Distance_from_root = Distance_from_root + xy_location_root(2,tree_index);
        %%% create the 2-D visualization for the truncated tree
        if nargin < 3
            f1 = figure;
            set(f1,'WindowStyle','docked')
        else
            if ~isfield(options,'axeshandle')
                f1 = figure;
                set(f1,'WindowStyle','docked')
            else
                axeshandle;
            end
        end
        hold on
        m = mean(x_coordinates_2D(Parent == -1));
        plot( [m,m],[0,Length(root_label)]+ xy_location_root(2,tree_index),'LineWidth',1.5)
        plot( m,0+ xy_location_root(2,tree_index),'.k')
        text(m,0-delta+ xy_location_root(2,tree_index),'0')
        LIST = [Label(Parent==root_label) 10000000]; % 10000000 is a dummy element
        k = length(LIST);
        while k > 1
            label = LIST(1);
            i = [1:length(Label)]*[Label == label]';
            LIST = LIST(2:k);
            if ~isempty(Children{i})
                plot([x_coordinates_2D(i), x_coordinates_2D(i)],...
                    [Distance_from_root(i)-Length(i), Distance_from_root(i)], ...
                    'color',edgecolor, ...
                    'LineWidth',1.5);
                if plot_internal_edge_lengths
                    text(x_coordinates_2D(i),mean([Distance_from_root(i)-Length(i), Distance_from_root(i)]), num2str(Length(i)));
                end
                parent_index = [1:length(Label)]*[Label == Parent(i)]';
                plot( [x_coordinates_2D(i),x_coordinates_2D(parent_index)],...
                    [Distance_from_root(i)-Length(i),Distance_from_root(i)-Length(i)],...
                    ':k');
                LIST = [Children{i} LIST];
            else
                if useleaves
                    plot([x_coordinates_2D(i), x_coordinates_2D(i)],...
                        [Distance_from_root(i)-Length(i), Distance_from_root(i)], ...
                        'color',leafcolor, ...
                        'LineWidth',1.5);
                    if plot_leaf_edge_lengths
                        text(x_coordinates_2D(i),mean([Distance_from_root(i)-Length(i), Distance_from_root(i)]),num2str(Length(i)));
                    end
                    plot(x_coordinates_2D(i),Distance_from_root(i),'k.');
                    if plot_leaf_labels
                        text(x_coordinates_2D(i),Distance_from_root(i)+delta,num2str(Landmark(i)));
                    end
                    parent_index = [1:length(Label)]*[Label == Parent(i)]';
                    plot( [x_coordinates_2D(i),x_coordinates_2D(parent_index)],...
                        [Distance_from_root(i)-Length(i),Distance_from_root(i)-Length(i)],...
                        ':k');
                end
            end
            k = length(LIST);
        end
        hold off
        title(titlestr)
        ylabel('Distance from Root(mm)')
        axis(windowsize)
        
        
    else %if iscolors4all
        [Label,Pars,Landmark] = bin2par(sigma_binary,options_bin2par);
        
        for i = 1:size(Pars,2)
            Parent(i) = Pars{i};
        end
        %%%% find children
        Children = cell(size(Label));
        for i = 1:length(Label)
            child_counter = 0;
            children_labels = -1*ones(1,10);
            for j = 1:length(Label)
                if Parent(j) == Label(i)
                    child_counter = child_counter+1;
                    children_labels(child_counter) = Label(j);
                end
            end
            Children{i} = children_labels(children_labels>=0);
        end
        clear children_labels child_counter
        
        %%%% compute the distance from the root of each segment
        Distance_from_root = zeros(size(Label));
        LIST = [Label(Parent==-1) 10000000]; % 10000000 is a dummy element
        k = length(LIST);
        while k > 1
            label = LIST(1);
            i = [1:length(Label)]*[Label == label]';
            LIST = LIST(2:k);
            if Parent(i) == -1
                Distance_from_root(i) = Length(i);
            else
                Distance_from_root(i) = Length(i) + Distance_from_root(Label == Parent(i));
            end
            if ~isempty(Children{i})
                LIST = [Children{i} LIST];
            end
            k = length(LIST);
        end
        
        %%%% give the tree an embedding (i.e. a left to right ordering of children)
        % depth first search on the tree
        % the i'th leaf reached is labeled leaf i
        % 1 is the left most leaf ... n is the right most leaf
        leaf_counter = 0;
        Leaf_left2right_label = -1*ones(size(Label));
        LIST = [Label(Parent==-1) 10000000]; % 10000000 is a dummy element
        k = length(LIST);
        LIST2 = LIST;
        c = 0;
        while 1 == 1
            c = c+1;
            label = LIST(1);
            if label == 10000000
                break
            end
            LIST = LIST(2:k);
            i = [1:length(Label)]*[Label == label]';
            if isempty(Children{i})
                leaf_counter = leaf_counter +1;
                if landmark_left2rightlabel
                    Leaf_left2right_label(i) = Landmark(Label==label);
                else
                    Leaf_left2right_label(i) = leaf_counter;
                end
            else
                LIST = [Children{i} LIST];
                LIST2 = union(LIST2,Children{i});
            end
            k = length(LIST);
        end
        clear LIST LIST2 label c i leaf_counter
        if labeled_root
            x_coordinates_2D = compute_x_coordinates(root_label,Children,Leaf_left2right_label,Label);
        else
            x_coordinates_2D = compute_x_coordinates(1,Children,Leaf_left2right_label,Label);
        end
        x_coordinates_2D = x_coordinates_2D + xy_location_root(1,tree_index);
        Distance_from_root = Distance_from_root + xy_location_root(2,tree_index);
        %%% create the 2-D visualization for the truncated tree
        if nargin < 3
            figure
        else
            if ~isfield(options,'axeshandle')
                figure
            else
                axeshandle;
            end
        end
        hold on
        m = mean(x_coordinates_2D(Parent == -1));
        plot( [m,m],[0,Length(root_label)],'LineWidth',1.5, 'color', colors4all(1,:))
        plot( m,0,'.k')
        plot( m,0-delta,'0')
        LIST = [Label(Parent==root_label) 10000000]; % 10000000 is a dummy element
        k = length(LIST);
        while k > 1
            label = LIST(1);
            i = [1:length(Label)]*[Label == label]';
            LIST = LIST(2:k);
            if ~isempty(Children{i})
                plot([x_coordinates_2D(i), x_coordinates_2D(i)],...
                    [Distance_from_root(i)-Length(i), Distance_from_root(i)], ...
                    'color',colors4all(i,:), ...
                    'LineWidth',1.5);
                parent_index = [1:length(Label)]*[Label == Parent(i)]';
                plot( [x_coordinates_2D(i),x_coordinates_2D(parent_index)],...
                    [Distance_from_root(i)-Length(i),Distance_from_root(i)-Length(i)],...
                    ':k');
                LIST = [Children{i} LIST];
            else
                if useleaves
                    plot([x_coordinates_2D(i), x_coordinates_2D(i)],...
                        [Distance_from_root(i)-Length(i), Distance_from_root(i)], ...
                        'color',colors4all(i,:), ...
                        'LineWidth',1.5);
                    plot(x_coordinates_2D(i),Distance_from_root(i),'k.');
                    text(x_coordinates_2D(i),Distance_from_root(i)+delta,num2str(Landmark(i)));
                    parent_index = [1:length(Label)]*[Label == Parent(i)]';
                    plot( [x_coordinates_2D(i),x_coordinates_2D(parent_index)],...
                        [Distance_from_root(i)-Length(i),Distance_from_root(i)-Length(i)],...
                        ':k');
                end
            end
            k = length(LIST);
        end
        hold off
        title(titlestr)
        ylabel('Distance from Root(mm)')
        axis(windowsize)
    end
end
%% subfunctions
function  x = compute_x_coordinates(label,Children,Leaf_left2right_label,Label)
% Type(i) = 1  if segment i is an internal segment
%           2  if segment i is a landmark segment from the right
%           hemisphere
%           3  if segment i is a landmark segment from the left
%           hemisphere
%           4  if segment i is a loose end segment
%           5  if segment i is the first segment of a tube
%           6  if segment i is the first and last semgent of a tube
%           7 if segment i is the segments form the super root to a
%             sub-super root

i = [1:length(Label)]*[Label == label]';
if ~isempty(Children{i})
    x = zeros(size(Children));
    x_i = 0;
    k = size(Children{i},2);
    for j = 1:k
        x = x + compute_x_coordinates(Children{i}(j),Children,Leaf_left2right_label,Label);
        index = [1:length(Label)]*[Label == Children{i}(j)]';
        x_i = x_i + x(index)/k;
    end
    x(i) = x_i;
else
    x = zeros(size(Children)); % create a vector of zeros with a
    % element for each leaf in the tree
    x(i) =  Leaf_left2right_label(i); % this case occurs when i is a leaf
    % assigns x_coordinate of i as the
    % integer k such that i is the k'th
    % leaf in the left to right ordering
    % of leafs in the tree embedding
    %else
    %   x = zeros(size(Type));
end