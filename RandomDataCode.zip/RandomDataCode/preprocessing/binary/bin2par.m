function [Label,Parent,Landmark] = bin2par(sigma_binary,options)
labeled_root = false;
if nargin > 1
    if isfield(options,'labeled_root')
        labeled_root = options.labeled_root;
        root_label = options.root_label;
    end
end

if labeled_root
    n = size(sigma_binary,1); m = size(sigma_binary,2);
    Label = zeros(1,n);
    Parent = cell(1,n);
    Landmark = -1*ones(1,n);
    for i = 1:n
        % assumes: sigma_binary(root_label,:) = [0 1 1 ... 1] or all ones
        % with a zero for the root leaf.
        if sigma_binary(i,root_label)==1
            sigma_binary(i,:)=~sigma_binary(i,:);
        end 
%         if sum(sigma_binary(i,~logical(sigma_binary(root_label,:)))) == 1
%             disp('here')
%             sigma_binary(i,:) = ~sigma_binary(i,:);
%         end
    end
    for i = 1:n
        Label(i) = i;
        %if root_label == i
        %    par = -1;
        %else
            min_sum = m+1;
            par = -1;
            for j = 1:n
%                 if sigma_binary(i,logical(sigma_binary(root_label,:))) == sigma_binary(j,logical(sigma_binary(root_label,:)))
% if i == 6
%     disp((sum(sigma_binary(i,:).*sigma_binary(j,:)) == sum(sigma_binary(i,:)) ) && (sum(sigma_binary(j,:))> sum(sigma_binary(i,:))))
% end
                    if (sum(sigma_binary(i,:).*sigma_binary(j,:)) == sum(sigma_binary(i,:)) ) && (sum(sigma_binary(j,:))> sum(sigma_binary(i,:)))
                        if sum(sigma_binary(j,:)) < min_sum
                            par = j;
                            min_sum = sum(sigma_binary(j,:));
                        end
                    end
%                 else
%                     if (sum(sigma_binary(i,:).*~sigma_binary(j,:)) == sum(sigma_binary(i,:)) ) && (sum(~sigma_binary(j,:))> sum(sigma_binary(i,:)))
%                         if sum(~sigma_binary(j,:)) < min_sum
%                             par = j;
%                             min_sum = sum(~sigma_binary(j,:));
%                         end
%                     end
%                 end
            end
            if sum(sigma_binary(i,:)) == 1
                Landmark(i) = [1:size(sigma_binary,2)]*sigma_binary(i,:)'-1; % subtract 1 becuase size(sigma_binary,2) includes the root
%                 if Landmark(i) > [1:size(sigma_binary,2)]*~sigma_binary(root_label,:)';
%                     Landmark(i) = Landmark(i) -1;
%                 end
            end
        %end
        Parent{i} = par;
    end
    
else
    n = size(sigma_binary,1); m = size(sigma_binary,2);
    Label = zeros(1,n);
    Parent = cell(1,n);
    Landmark = -1*ones(1,n);
    for i = 1:n
        Label(i) = i;
        min_sum = m+1;
        par =0;
        c = 1;
        for j = 1:n
            if sum(sigma_binary(i,:)) == m % root
                par = -1;
            else
                if (sum(sigma_binary(i,:).*sigma_binary(j,:)) == sum(sigma_binary(i,:)) ) && (sum(sigma_binary(j,:))> sum(sigma_binary(i,:)))
                    if sum(sigma_binary(j,:)) < min_sum
                        par = j;
                        min_sum = sum(sigma_binary(j,:));
                    end
                end
            end
        end
        % search for vertices with two edges
        % par(1) = parent
        % par(2:...) = label of vertices that induce the same split on the
        % leafs
        for j = 1:n
            if (sum(sigma_binary(i,:).*sigma_binary(j,:)) == sum(sigma_binary(i,:)) ) && (sum(sigma_binary(j,:))== sum(sigma_binary(i,:)))
                if i ~=j
                    c = c+1;
                    par(c) = j;
                end
            end
        end
        Parent{i} = par;
        if sum(sigma_binary(i,:)) == 1
            Landmark(i) = [1:size(sigma_binary,2)]*sigma_binary(i,:)';
        end
        %     if sum(sigma_binary(i,:)) ==  size(sigma_binary(i,:),2)-1
        %         Landmark(i) = [1:size(sigma_binary,2)]*~sigma_binary(i,:)';
        %     end
    end
end