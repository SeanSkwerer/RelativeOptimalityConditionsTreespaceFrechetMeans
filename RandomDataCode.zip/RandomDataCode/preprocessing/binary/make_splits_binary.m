function [sigma_binary,L,sigma_binary_dups,LM_edges] = make_splits_binary(Label,Length,Parent,Landmark)
% this routine applied to brain artery tree data from read_and
% _visualize().m combines segments that "should" be part of the same edge
% (induce the same split on teh elaves) and does not nclude the segments
% from teh landmark location to the artery. The landmark segment lengths
% are stored in L_M_edges.
%import_tree_data;
n = size(Label,2);
m = sum(Landmark > 0);

sigma_binary = sparse(zeros(n,m));
tum_sum = 0;
c = 0;
for i = 1:n
    label = Label(i);
    s = get_split_binary(label,Label,Parent,Landmark,m);
    tum_sum = tum_sum + sum(s);
    if sum(s) > 0 && Landmark(i) > -1
        c = c+1;
    end
    sigma_binary(i,:) = sparse(s);
end
% get landmark to tree edges
LM_edges = zeros(1, sum(Landmark > 0));
for i = 1:n
    if Landmark(i) > 0
        LM_edges(Landmark(i)) = Length(i);
    end
end

% reconcile duplicate edges
A = sparse(false(n));% duplicate indicator matrix
for i = 1:n
    for j = (i+1):n
        if sum(sigma_binary(i,:) == sigma_binary(j,:)) == size(sigma_binary,2)
            A(i,j) = true;
        end
    end
end
keep = true(n,1);
L = zeros(size(Length));
for i = 1:n
    if sum(A(i,:)) > 0
        for j = 1:n
            if (A(i,j) && Landmark(j) < 0) || (i == j && Landmark(j) < 0)
             L(i) = L(i) + Length(j);
            end
        end
        keep(A(i,:)) = false;
    else
        if Landmark(i) < 0
        L(i) = Length(i);
        end
    end
end
L = L(keep);
sigma_binary_dups = sparse(sigma_binary);
sigma_binary = sparse(sigma_binary(keep,:));

%%%%%%%%%%% subfunctions %%%%%%%%%%%%%%%%%%
function leafs_binary = get_split_binary(label,Label,Parent,Landmark,m)
% returns binary indicator vector of the leafs in the subtree rooted
% at the edge 'label'
LIST = [Label(Parent==label) 10000000]; % 10000000 is a dummy element
k = length(LIST);
leafs_binary = zeros(1,m);
if Landmark(Label == label) > -1
   leafs_binary( Landmark(Label == label)) = 1;
else
while k > 1
    l = LIST(1);
    LIST = LIST(2:k);
    lm = Landmark(Label == l);
    if lm == -1
        LIST = [Label(Parent == l) LIST];
    else
        leafs_binary(lm) =1;
    end
    k = length(LIST);
end
end
