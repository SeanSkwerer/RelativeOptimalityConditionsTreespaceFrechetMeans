
function [A,B,D_L,D_T,D_I] = msb(A,L,T,I)
%input:
% A is a matrix of splits with binary representation
% L is the vector of lengths

% output:
% B is A without duplicates
% D duplicate info D{i} = vector of lengths of duplicates of B(i,:)
% D_I the index of the edge in the original tree

% test data
%A = [0 0 1 0 0; 0 1 0 0 0; 0 1 0 1 0; 1 0 0 0 0; 0 1 0 0 0];

% m splits; n+1 leafs (root leaf is implicit)
[m,n] = size(A);
m2 = log2(m);
m2 = ceil(m2);
m2 = 2^m2-m;
A = [A;zeros(m2,n)];
T = [T; zeros(m2,1)];
L = [L;zeros(m2,1)];
I = [I;zeros(m2,1)];
[m,n] = size(A);
t = 1;
for i = 1:m
    if sum(A(i,:)) > n/2
        A(i,:) = ~A(i,:);
    end
end
while t <= floor(m/2)
    r = 0;
    while r < m
        p = r+1;
        q = r+t;
        r = r + 2*t;
        if r+t >= m
            r = m;
        end
        % t = 1 -> [p,q,r] = [1,1,2],[3,3,4], ...,[m-1,m-1,m] or [m,m,m+1]
        % t = 2 -> [p,q,r] = [1,2,4],[5,6,8], ...,[m-3,m-1,m] or [m-2,m-1,m]
        % t = ceil(m/2) -> [p,q,r] = [1,m/2,m] or [1,floor(m/2),m];
        % merge
        Left = [A(p:q,:);-1*ones(1,n)];
        Right = [A(q+1:r,:);-1*ones(1,n)];
        L_left = L(p:q);
        L_right = L(q+1:r);
        T_left = T(p:q);
        T_right = T(q+1:r);
        I_left = I(p:q);
        I_right = I(q+1:r);
        i = 1;j = 1;
        for k = p:r
            L_R_ind = false; % false -> left is greater or equal to right
            % true - > right is greater
            for l  = 1:n
                %                     if sum(Right(j,:)) > sum(Left(i,:))
                %                         L_R_ind = true;
                %                     else
                % first entry l with clear winner ->  break the loop
                % otherwise Right(j,:) == Left(i,:)
                if Right(j,l) > Left(i,l)
                    L_R_ind = true;
                    break
                elseif Left(i,l) > Right(j,l)
                    break;
                end
                %                     end
            end
            if ~L_R_ind % Left(i) >= Right(j)
                A(k,:) = Left(i,:);
                L(k) = L_left(i);
                T(k) = T_left(i);
                I(k) = I_left(i);
                i = i+1;
            else
                A(k,:) = Right(j,:);
                L(k) = L_right(j);
                T(k) = T_right(j);
                I(k) = I_right(j);
                j = j+1;
            end
        end
        %             disp([t,i,j])
    end
    t = 2*t;
end
i = 1;
c = 0;
A = [A;-1*ones(1,n)];
% count number of unique edges
while i <= m
    j = i+1;
    if sum(A(i,:)) == 0 || sum(A(i,:)) == -1*n
        break
    end
    while sum(A(i,:)==A(j,:)) == n
        j = j+1;
    end
    c = c+1;
    i = j;
end
B = zeros(c,n);
D_L = cell(1,c);
D_T = cell(1,c);
D_I = cell(1,c);
i = 1;
c = 0;
while i <= m
    j = i+1;
    if  sum(A(i,:)) == -1*n || sum(A(i,:)) == 0
        break
    end
    while sum(A(i,:)==A(j,:)) == n
        j = j+1;
    end
    c = c+1;
    B(c,:) = A(i,:);
    D_L{c} = L(i:j-1);
    D_T{c} = T(i:j-1);
    D_I{c} = I(i:j-1);
    i = j;
end
A = A(1:i-1,:);

