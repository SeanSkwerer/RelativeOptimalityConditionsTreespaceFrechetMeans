function t=bin2parent(t0)
% e = T0.e
% e has fields
% e(i).p parent
% e(i).ch children
% e(i).x length
% e(i).sl smallest leaf label in subtree
% T0.nleaf = number of leafs
% T0.m = number of edges (including pendants)

m=size(t0.E,1);
nlfs=size(t0.E,2);
E=zeros(size(t0.E));
L=zeros(size(t0.L));
v=1:nlfs;
E(1:nlfs,1:nlfs)=eye(nlfs);
c=nlfs;
for i=1:m
    if sum(t0.E(i,:),2)==1
        L(t0.E(i,:)*v')=t0.L(i);
    else
       c=c+1;
       E(c,:)=t0.E(i,:);
       L(c)=t0.L(i);
    end
end
opt_bin2par.labeled_root=true;
opt_bin2par.root_label=1;
[Label,Parent,Landmark] = bin2par(E,opt_bin2par);
e=[];
p=[Parent{:}];
for i=1:m
    e(i).ch=[];
end
for i=1:m
    e(i).p=p(i);
    if (p(i)>0) 
        e(p(i)).ch(end+1)=i;
    end
    e(i).x=L(i);
    e(i).sl=-1;
    for j=1:nlfs
        if E(i,j)>0
            e(i).sl=j;
            break
        end
    end
end
for i=1:m
    if isempty(e(i).ch)
        e(i).ch=-1;
    end
end

t.e=e;
t.E=E;
t.L=L;
t.m=m;
t.nleaf=nlfs;
