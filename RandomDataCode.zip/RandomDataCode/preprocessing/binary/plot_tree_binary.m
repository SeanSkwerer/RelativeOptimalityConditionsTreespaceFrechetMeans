function plot_tree_binary(sigma_binary,Length,titlestr,options)
% This has changed... now root is always the leaf of the left most column
% of simga_binary

% % this function does not work without a root which is represented as a
% % binary edge of all ones. 
% if sum(sum(sigma_binary,2) == size(sigma_binary,2)) < 1
%     sigma_binary = [ones(1,size(sigma_binary,2)); sigma_binary];
%     Length = [min(Length)/10; Length];
% end
axis_brain_trees = false;
opt.root_label = 1;
opt.labeled_root = true;
if nargin<3
    titlestr='title';
end

if nargin > 3
if isfield(options,'no_leafs');
    n_leaf = size(sigma_binary,2);
    m_internal = size(sigma_binary,1);
    sigma_binary = [sigma_binary; eye(n_leaf)];
    sigma_binary(m_internal+1,:) = ~sigma_binary(m_internal+1,:);
end
end
[Label,Pars,Landmark] = bin2par(sigma_binary,opt);
for i = 1:size(Pars,2)
    Parent(i) = Pars{i};
end
%%%% find children 
Children = cell(size(Label));
for i = 1:length(Label)
    child_counter = 0;
    children_labels = -1*ones(1,10);
    for j = 1:length(Label)
        if Parent(j) == Label(i)
                child_counter = child_counter+1;
                children_labels(child_counter) = Label(j);
        end
    end
    Children{i} = children_labels(children_labels>=0);
end
clear children_labels child_counter

%%%% compute the distance from the root of each segment
Distance_from_root = zeros(size(Label));
LIST = [Label(Parent==-1) 10000000]; % 10000000 is a dummy element
k = length(LIST);
while k > 1
    label = LIST(1);
    i = [1:length(Label)]*[Label == label]';
    LIST = LIST(2:k);
    if Parent(i) == -1
        Distance_from_root(i) = Length(i);
    else
        Distance_from_root(i) = Length(i) + Distance_from_root(Label == Parent(i));
    end
    if ~isempty(Children{i})
        LIST = [Children{i} LIST];
    end
    k = length(LIST);
end

%%%% give the tree an embedding (i.e. a left to right ordering of children)
% depth first search on the tree
% the i'th leaf reached is labeled leaf i
% 1 is the left most leaf ... n is the right most leaf
leaf_counter = 0;
Leaf_left2right_label = -1*ones(size(Label));
LIST = [Label(Parent==-1) 10000000]; % 10000000 is a dummy element
k = length(LIST);
LIST2 = LIST;
c = 0;
while 1 == 1
    c = c+1;
    label = LIST(1);
    if label == 10000000
        break
    end
    LIST = LIST(2:k);
    i = [1:length(Label)]*[Label == label]';
    if isempty(Children{i})
        leaf_counter = leaf_counter +1;
        Leaf_left2right_label(i) = leaf_counter;
    else
        LIST = [Children{i} LIST];
        LIST2 = union(LIST2,Children{i});
    end
    k = length(LIST);
end
clear LIST LIST2 label c i 
root_index=Label(Parent==-1);
x_coordinates_2D = compute_x_coordinates(root_index,Children,Leaf_left2right_label,Label);

%%% create the 2-D visualization for the truncated tree
f1=figure;
set(f1,'WindowStyle','docked')
hold on
m = mean(x_coordinates_2D(Parent == -1));
plot( [m,m],[0,Length(root_index)],'LineWidth',1.5)

LIST = [Label(Parent==root_index) 10000000]; % 10000000 is a dummy element
k = length(LIST);

while k > 1
    label = LIST(1);
    i = [1:length(Label)]*[Label == label]';
    LIST = LIST(2:k);
    if ~isempty(Children{i})
        plot([x_coordinates_2D(i), x_coordinates_2D(i)],...
            [Distance_from_root(i)-Length(i), Distance_from_root(i)], ...
            'color',[0 0 1], ...
            'LineWidth',1.5);
            parent_index = [1:length(Label)]*[Label == Parent(i)]';
            plot( [x_coordinates_2D(i),x_coordinates_2D(parent_index)],...
                [Distance_from_root(i)-Length(i),Distance_from_root(i)-Length(i)],...
                ':k');
        LIST = [Children{i} LIST];
    else
        plot([x_coordinates_2D(i), x_coordinates_2D(i)],...
            [Distance_from_root(i)-Length(i), Distance_from_root(i)], ...
            'color',[0 0 1], ...
            'LineWidth',1.5);
        plot(x_coordinates_2D(i),Distance_from_root(i),'k.');
            parent_index = [1:length(Label)]*[Label == Parent(i)]';
            plot( [x_coordinates_2D(i),x_coordinates_2D(parent_index)],...
                [Distance_from_root(i)-Length(i),Distance_from_root(i)-Length(i)],...
                ':k');
    end
    k = length(LIST);
end
hold off
title(titlestr)
ylabel('Distance from Root')
axis([0 leaf_counter+1 0 max(Distance_from_root)+min(Distance_from_root)/10])
if axis_brain_trees
axis([0 130 0 450])
end
%% subfunctions
function  x = compute_x_coordinates(label,Children,Leaf_left2right_label,Label)
% Type(i) = 1  if segment i is an internal segment
%           2  if segment i is a landmark segment from the right
%           hemisphere
%           3  if segment i is a landmark segment from the left
%           hemisphere
%           4  if segment i is a loose end segment
%           5  if segment i is the first segment of a tube
%           6  if segment i is the first and last semgent of a tube
%           7 if segment i is the segments form the super root to a
%             sub-super root

    i = [1:length(Label)]*[Label == label]';
  if ~isempty(Children{i})
      x = zeros(size(Children));
      x_i = 0;
      k = size(Children{i},2);
      for j = 1:k
          x = x + compute_x_coordinates(Children{i}(j),Children,Leaf_left2right_label,Label);
          index = [1:length(Label)]*[Label == Children{i}(j)]';
          x_i = x_i + x(index)/k;
      end
      x(i) = x_i;
  else
      x = zeros(size(Children)); % create a vector of zeros with a
      % element for each leaf in the tree
      x(i) =  Leaf_left2right_label(i); % this case occurs when i is a leaf
      % assigns x_coordinate of i as the
      % integer k such that i is the k'th
      % leaf in the left to right ordering
      % of leafs in the tree embedding
  %else
   %   x = zeros(size(Type));
  end
