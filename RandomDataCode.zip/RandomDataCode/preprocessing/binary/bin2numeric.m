function T=bin2numeric(T)
options.labeled_root=true;
options.root_label=1;
[T.Label,T.Parent,T.Landmark]=bin2par(T.E,options);
for i=1:length(T.Parent)
    T.p(i)=T.Parent{i}(1);
end
[T.numeric,T.x] = list2numeric_newick(T.Label,T.p,T.Landmark,T.L);
