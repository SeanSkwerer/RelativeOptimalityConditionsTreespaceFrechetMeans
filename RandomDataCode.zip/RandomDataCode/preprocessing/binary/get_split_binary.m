function leafs_binary = get_split_binary(label,Label,Parent,Landmark,m)
% returns binary indicator vector of the leafs in the subtree rooted
% at the edge 'label'
LIST = [Label(Parent==label) 10000000]; % 10000000 is a dummy element
k = length(LIST);
leafs_binary = zeros(1,m);
if Landmark(Label == label) > -1
    leafs_binary( Landmark(Label == label)) = 1;
else
    while k > 1
        l = LIST(1);
        LIST = LIST(2:k);
        lm = Landmark(Label == l);
        if lm == -1
            LIST = [Label(Parent == l) LIST];
        else
            leafs_binary(lm) =1;
        end
        k = length(LIST);
    end
end
