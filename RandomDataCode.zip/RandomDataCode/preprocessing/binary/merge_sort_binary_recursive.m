function [A,D] = merge_sort_binary_recursive(A,p,r)%,L)
%input:
% A is a matrix of splits with binary representation
% L is the vector of lengths

% output:
% A becomes A sorted: zero is less than 1 and 0001 < 0010 < 0100
% D duplicate info

% test data
%A = [0 0 1 0 0; 0 1 0 0 0; 0 1 0 1 0; 1 0 0 0 0; 0 1 0 0 0];

D = 0;

if p < r
    q = floor((p+r)/2);
    A = merge_sort_binary_recursive(A,p,q);
    A = merge_sort_binary_recursive(A,q+1,r);
    A = merge_binary(A,p,q,r);
end

function A = merge_binary(A,p,q,r)
n = size(A,2);
            Left = [A(p:q,:);-1*ones(1,n)];
            Right = [A(q+1:r,:);-1*ones(1,n)];
             i = 1;j = 1;
            for k = p:r
                L_R_ind = false; % false -> left is greater or equal to right
                                 % true - > right is greater
                for l  = 1:n
                    % first entry l with clear winner ->  break the loop
                    % otherwise Right(j,:) == Left(i,:)
                    if Right(j,l) > Left(i,l)
                        L_R_ind = true;
                        break
                    elseif Left(i,l) > Right(j,l)
                        break;
                    end                    
                end
                if ~L_R_ind % Left(i) >= Right(j)
                    A(k,:) = Left(i,:);
                    i = i+1;
                else
                    A(k,:) = Right(j,:);
                    j = j+1;
                end
            end
