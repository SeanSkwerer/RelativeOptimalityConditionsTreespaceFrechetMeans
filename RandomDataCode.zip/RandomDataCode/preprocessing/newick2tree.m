function T = newick2tree(s)
% binary tree only! no edge lengths!
% output
% T is a struct
% T.m is the number of edges in T
% T.e(1) is the root pendant
% T.e(2:nleaf) are the leafs of T
% T.e(nleaf+1:m) are the internal edges of T

% e(i).p is label of the parent
% e(i).ch is a vector containing the labels of the children of i
% e(i).sl is the smallest leaf label in the subtree rooted at i.
% assume edges are directed with tail closest to root.

% sample 1
% s = '0(1(2,3));'
% T.m = 5
% T.e(1).p = -1
% T.e(1).ch = [2 5]
% T.e(1).sl = 1;
% T.e(2).p = 1;
% T.e(2).ch = -1;
% T.e(2).sl = 1;
% T.e(3).p = 5;
% T.e(3).ch = -1;
% T.e(3).sl = 2;
% T.e(4).p = 5;
% T.e(4).ch = -1;
% T.e(4).sl = 3;
% T.e(5).p = 1;
% T.e(5).ch = [3 4]
% T.e(5).sl = 2;

% sample 2
% s = '0((5,4)(1(2,3)));'

% Make the order parent, children, smallest label
T.e(1).p = nan;
T.e(1).ch = nan;
T.e(1).sl = nan;

len = length(s);
% find the largest leaf labels. assume leafs are labeled 0,1,2...,max
max = 0;
for i = 1:len
    if s(i) >= 48 && s(i) <= 57
        k = i+1;
        while s(k) >= 48 && s(k) <= 57
            k = k+1;
        end
        k = k-1;
        %         s(i:k) is an integer leaf label
        if max < str2num(s(i:k))
            max = str2num(s(i:k));
        end
    end
end


% fill in the smallest label and children for the leafs
for i = 1:max
    T.e(i).sl = i;
    T.e(i).ch = [-1 -1];
end
% BFS starting from the root
% assume that s(1) == 0
LIST  = 2;
labels = max+1;
c = max+1;
T.e(max+1).p = -1;
while ~isempty(LIST)
    i = LIST(1);
    label = labels(1);
    sl = max;
    if s(i+1) == '('
        % found a new edge with a subtree
        LIST(end+1) = i+1; % store at end of list for BFS
        c = c+1;
        labels(end+1) = c;
        T.e(label).ch(1) = c;
        T.e(c).p = label;
        depth = 1;
        k = i+1;
        while depth > 0
            k = k+1;
            if s(k) == '('
                depth = depth+1;
            elseif s(k) == ')'
                depth = depth-1;
            elseif s(k) >= '0' && s(k) <= '9'
                k1 = k+1;
                while s(k1) >= '0' && s(k1) <= '9'
                    k1 = k1+1;
                end
                k1 = k1-1;
                if sl > str2num(s(k:k1))
                    sl = str2num(s(k:k1));
                end
            end
        end
        % depth == 0 -> s(k) == ')'
        k = k+1;
        % now s(k) == '(' or is a leaf label
    elseif s(i+1) >= '0' && s(i+1) <= '9'
        % found a pendant
        k = i+1;
        while s(k) >= '0' && s(k) <= '9'
            k = k+1;
        end
        pendant = str2num(s(i+1:k-1));
        if pendant < sl
            sl = pendant;
        end
        T.e(label).ch(1) = pendant+1;
        T.e(pendant).p = label;
        % now s(k) == '(' or s(k) == ','
    end
    % now s(k) == '(' or s(k) == ',' or s(k) is a leaf label
    if s(k) == '('
        % found a new edge with a subtree
        LIST(end+1) = k; % store at end of list for BFS
        c = c+1;
        labels(end+1) = c;
        T.e(label).ch(2) = c;
        T.e(c).p = label;
        depth = 1;
        while depth > 0
            k = k+1;
            if s(k) == '('
                depth = depth+1;
            elseif s(k) == ')'
                depth = depth-1;
            elseif s(k) >= '0' && s(k) <= '9'
                k1 = k+1;
                while s(k1) >= '0' && s(k1) <= '9'
                    k1 = k1+1;
                end
                k1 = k1-1;
                if sl > str2num(s(k:k1))
                    sl = str2num(s(k:k1));
                end
            end
        end
        % depth == 0 -> s(k) == ')'
        % now s(k) == ')'
    elseif s(k) == ','
        % found another pendant
        k1 = k+1;
        while s(k1) >= '0' && s(k1) <= '9'
            k1 = k1+1;
        end
        pendant = str2num(s(k+1:k1-1));
        if pendant < sl
            sl = pendant;
        end
        T.e(label).ch(2) = pendant+1;
        T.e(pendant).p = label;
        k = k1;
        % now s(k) == ')'
    elseif s(k) >= '0' && s(k) <= '9'
        % found a pendant
        k1 = k+1;
        while s(k1) >= '0' && s(k1) <= '9'
            k1 = k1+1;
        end
        pendant = str2num(s(k:k1-1));
        if pendant < sl
            sl = pendant;
        end
        T.e(pendant).p = label;
        T.e(label).ch(2) = pendant+1;
        k = k1;
        % now s(k) == ')'
    end
    % Now left and right subtrees of e(c) have been checked
    % thus sl is the smallest label in both subtrees
    T.e(label).sl = sl;
    LIST(1) = [];
    labels(1) = [];
end
T.m = length(T.e);
temp.e = T.e(max+1);
for i = max:-1:1
    T.e(i+1) = T.e(i);
end
T.e(1) = temp.e;
T.e(T.e(1).ch(1)).p = 1;
T.e(T.e(1).ch(2)).p = 1;
nleaf = 1;
while nleaf < T.m
    if T.e(nleaf+1).ch(1) == -1
        nleaf = nleaf+1;
    else
        break
    end
end
T.nleaf = nleaf;