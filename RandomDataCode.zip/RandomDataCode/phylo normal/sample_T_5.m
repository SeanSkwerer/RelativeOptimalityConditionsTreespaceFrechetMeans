init_mu = true;
gen_tree_sample = true;
record_tree_sample = true;
read_sample = true;
visualize_sample = false;
get_splits = true;
visualize_binary_trees = false;
FM_sample = true;

save_str = 'test_sample_T_5.doc';
sample_size = 10^4;
% sample_size seed elapsed_time
% 10^4  1   58.400
% 10^4  2   60.367

seed = 2;
tic;
% initialize the mean tree
if init_mu
    % e(i).x length
    % e(i).p parent
    % e(i).s sister
    % e(i).l left
    % e(i).r right
    % e(i).sl smallest leaf label in subtree
    % all edges have tails closer to the root leaf labeled zero.
    e(1).x = 1;
    e(1).p = -1;
    e(1).s = -1;
    e(1).l = 7;
    e(1).r = 8;
    e(1).sl = 1;
    
    e(2).x = 1;
    e(2).p = 7;
    e(2).s = 3;
    e(2).l = -1;
    e(2).r = -1;
    e(2).sl = 1;
    
    e(3).x = 1;
    e(3).p = 7;
    e(3).s = 2;
    e(3).l = -1;
    e(3).r = -1;
    e(3).sl = 2;
    
    e(4).x = 1;
    e(4).p = 8;
    e(4).s = 9;
    e(4).l = -1;
    e(4).r = -1;
    e(4).sl = 3;
    
    e(5).x = 1;
    e(5).p = 9;
    e(5).s = 6;
    e(5).l = -1;
    e(5).r = -1;
    e(5).sl = 4;
    
    e(6).x = 1;
    e(6).p = 9;
    e(6).s = 5;
    e(6).l = -1;
    e(6).r = -1;
    e(6).sl = 5;
    
    e(7).x = 0.04;
    e(7).p = 1;
    e(7).s = 8;
    e(7).l = 2;
    e(7).r = 3;
    e(7).sl = 1;
    
    e(8).x = 0.367;
    e(8).p = 1;
    e(8).s = 7;
    e(8).l = 4;
    e(8).r = 9;
    e(8).sl = 3;
    
    e(9).x = 0.12;
    e(9).p = 8;
    e(9).s = 4;
    e(9).l = 5;
    e(9).r = 6;
    e(9).sl = 4;
    mu = e;
end

% generate tree sample
if gen_tree_sample
    % set random seed
    randn('seed',seed);
    rand('seed',seed);
    % header for output file
    if record_tree_sample
        fid = fopen(save_str,'w');
        fprintf(fid,'length parent leaf \n');
        fclose(fid);
    end
    n_s = 0;
    while n_s < sample_size
        e = mu;
        n_s = n_s+1;
        % get a random direction d
        m = length(e);
        d = randn(m,1);
        d = d/norm(d);
        % get a random step radius r
        r = abs(randn(1));
        alpha = nan(m,1);
        for i = 1:m
            alpha(i) = -1*e(i).x/d(i);
        end
        % The nearest neighbor interchanges must be applied in the order they
        % occur along the geodesic.
        [V,I] = sort(alpha,'ascend');
        for i = 1:m
            if I(i) > (m+3)/2
                j = I(i);
                if V(i) < 0
                    e(j).x = e(j).x + r*d(j);
                elseif V(i) <= r
                    % nearest neighbor interchange
                    parent = e(j).p;
                    sister = e(j).s;
                    right = e(j).r;
                    left = e(j).l;
                    
                    sl_left = e(e(j).l).sl;
                    sl_right = e(e(j).r).sl;
                    
                    rn = rand(1);
                    % if rn <= 0.5 swap sister for child with smaller smallest label
                    % if rn > 0.5 swap sister for child with larger smallest label
                    if rn <= 0.5
                        if sl_left < sl_right
                            case1 = true;
                        else
                            case1 = false;
                        end
                    else
                        if sl_left >= sl_right
                            case1 = true;
                        else
                            case1 = false;
                        end
                    end
                    % case1 is true then swap the sister for the left child
                    % case1 is false then swap the sister for the right child
                    if case1
                        e(j).l = sister;
                        e(j).s = left;
                        e(sister).p = j;
                        e(sister).s = right;
                        e(left).p = parent;
                        e(left).s = j;
                        e(right).s = sister;
                        e(parent).l = left;
                        e(parent).r = j;
                    else
                        e(j).r = sister;
                        e(j).s = right;
                        e(sister).p = j;
                        e(sister).s = left;
                        e(right).p = parent;
                        e(right).s = j;
                        e(left).s = sister;
                        e(parent).l = right;
                        e(parent).r = j;
                    end
                    sl_left = e(e(j).l).sl;
                    sl_right = e(e(j).r).sl;
                    e(j).sl = min(sl_left,sl_right);
                    e(j).x = -1*(r-V(i))*d(j);
                else
                    e(j).x = e(j).x + r*d(j);
                end
            end
        end
        % record sample
        if record_tree_sample
            fid = fopen(save_str,'a');
            for i = 1:m
                %                 fprintf(fid,'%9.9f %i %i %i %i %i;',[e(i).x e(i).p e(i).s e(i).l e(i).r e(i).sl]);
                fprintf(fid,'%i %i %9.9f ',[i e(i).p e(i).x]);
                if e(i).l < 0
                    fprintf(fid,'%i\n',e(i).sl);
                elseif e(i).p < 0
                    fprintf(fid,'%i\n',0);
                else
                    fprintf(fid,'%i\n',-1);
                end
            end
            fprintf(fid,'. \n');
            fclose(fid);
        end
    end
end
toc;

if read_sample
    
    trees = read_tree_set(save_str);
    
end
if visualize_sample
    n_s = length(trees);
    options.axis = [0 6 0 5];
    for i = 1:n_s
        plot_tree(trees(i).Label,trees(i).Parent,trees(i).Length,options);
        set(gcf,'WindowStyle','docked')
    end
    
end

if get_splits
    
    n_s = length(trees);
    for i = 1:n_s
        Landmark = trees(i).Landmark;
        for j = 1:length(Landmark)
            if Landmark(j) >= 0
                Landmark(j) = Landmark(j)+1;
            end
        end
        trees(i).Splits = par2bin(trees(i).Label,trees(i).Parent,Landmark);
    end
end

if visualize_binary_trees
    n_s = length(trees);
    for i = 1:n_s
    sigma_binary = trees(i).Splits;
    sigma_binary(:,1) = [];
    sigma_binary(1,:) = ones(1,size(sigma_binary,2));
        plot_tree_binary(sigma_binary,trees(i).Length,'titlestr')
        set(gcf,'WindowStyle','docked')
    end
end

if FM_sample
    tic;
    n_s = length(trees);
    LEN = cell(1,n_s);
    TOP = cell(1,n_s);
    for i = 1:n_s
        LEN{i} = trees(i).Length;
        TOP{i} = trees(i).Splits;
    end
    Trees.LEN = LEN;
    Trees.TOP = TOP;
    options.cdmax = 5;
    options.comax = 10;
    options.ms = n_s*2;
    outstruct = sturms_descent_alternating2(Trees,options);
    toc;
end

% Preliminary run
% Elapsed time for generation 5.4 sec.
% Elapsed time for s-d-a2 574.5 sec.
% Setting cdmax = 15, comax = 10, ms = n_s*2, n_s = 10^3, seed = 2;
% outstruct.Lz = [0.0580083 0.3363507 0.10109925]
% mu = [0.04 0.367 0.12]

% Another Preliminary run
% generation 5.4 seconds
% s-d-a2 unknown < 20sec.
% Setting cdmax = 2, comax = 2, ms = 2, n_s = 10^3, seed = 2;
% outstruct.Lz = [0.058008234 0.336350714 0.101099332]
% mu = [0.04 0.367 0.12]

% yet another preliminary run
% Setting cdmax = 5, comax = 2, ms = 2*n_s, n_s = 10^4, seed = 2;
% generation 53.85 sec.
% s-d-a2 elapsed time  1828.701850 seconds.
% outstruct.Lz = [0.062584 0.351035 0.114336];
% mu = [0.04 0.367 0.12];

% Analysis of Results
% Compare the SSD for mu, the answer from Sturm's algorithms, and the
% answer from the sturm-descent_alternating2. In this case the mean should
% not be sticky therefore we should expect the sample mean to behave the
% same as the Euclidean case. Emperical evidence from these simulations
% should show that the variability around the mu is sigma/sqrt(n).