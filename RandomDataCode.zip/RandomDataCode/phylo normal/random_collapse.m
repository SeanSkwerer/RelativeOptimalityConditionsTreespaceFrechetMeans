function T = random_collapse(T,k)
if isfield(T,'m')
    m = T.m;
else
    m = length(T.e);
end
if k > 0
% assume that T.e(1) is the root
% increment i until past the leafs
i = 2;
while T.e(i).ch == -1
    i = i+1;
end
nleaf = i-1;
% now T(1:nleaf) are leafs and T(nleaf+1:m) are internal edges
% collapse k randomly selected internal edges
e = T.e;
order = (nleaf+1):m;
order = order(randperm(m-nleaf));
if k > length(order)
    k = length(order);
    disp('Warning k is larger than the number of internal edges of T')
end
for i = 1:k
    c = order(i);
    % collapse edge c
    % children of c become the children of c's parent
    parent = e(c).p;
    for j = 1:length(e(c).ch)
        child_j = e(c).ch(j);
        e(parent).ch(end+1) = child_j;
        e(child_j).p = parent;
        e(parent).ch(e(parent).ch == c) = [];
    end
    % delete c
    e(c) = [];
    % decrement any relevant indices
    for j = 1:length(e)
        if e(j).p > c;
            e(j).p = e(j).p -1;
        end
        for l = 1:length(e(j).ch)
            if e(j).ch(l) > c
                e(j).ch(l) = e(j).ch(l) -1;
            end
        end
    end
    for j = i+1:length(order)
        if order(j) > c;
            order(j) = order(j) -1;
        end
    end
end
T.e = e;
T.m = m-k;
end