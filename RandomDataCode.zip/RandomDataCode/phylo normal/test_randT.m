trial1 = true;

if trial1
    nleaf = 20;
    T = randT(nleaf);
    Label = 1:T.m;
    Parent = [T.e(:).p];
    Length = [T.e(:).x];
    plot_tree(Label,Parent,Length)
    set(gcf,'WindowStyle','docked')
    xlim([-1 nleaf+1])
    disp(Length)
end