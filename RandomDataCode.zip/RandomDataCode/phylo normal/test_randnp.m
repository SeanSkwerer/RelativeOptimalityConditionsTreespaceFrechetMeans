test_face = false;
test_face2 = true;
test_facet = false;

% set rand number seed
% rng(15);

if test_face
filestr = ['BinaryTrees9leaves.tre'];
fid = fopen(filestr,'r');
line = fgetl(fid);
T = newick2tree(line);
for i = 1:length(T.e)
    T.e(i).x = 0;
end
T0 = random_collapse(T,3);
T2 = randpn(T0);

Label = 1:T2.m;
Parent = [T2.e(:).p];
Length = [T2.e(:).x];

plot_tree(Label,Parent,Length)

set(gcf,'WindowStyle','docked')
end

if test_face2
filestr = ['BinaryTrees9leaves.tre'];
fid = fopen(filestr,'r');
line = fgetl(fid);
T = newick2tree(line);
for i = 1:length(T.e)
    T.e(i).x = 1;
end
T0 = random_collapse(T,3);
T2 = randpn(T0);

Label = 1:T2.m;
Parent = [T2.e(:).p];
Length = [T2.e(:).x];

plot_tree(Label,Parent,Length)

set(gcf,'WindowStyle','docked')
end

if test_facet
filestr = ['BinaryTrees9leaves.tre'];
fid = fopen(filestr,'r');
line = fgetl(fid);
T = newick2tree(line);
for i = 1:length(T.e)
    T.e(i).x = 0.1;
end
T0 = T;
options.stdev = 10;
T2 = randpn(T0,options);

Label = 1:T2.m;
Parent = [T2.e(:).p];
Length = [T2.e(:).x];

plot_tree(Label,Parent,Length)

set(gcf,'WindowStyle','docked')
end