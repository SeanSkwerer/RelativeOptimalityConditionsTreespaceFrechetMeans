function T = randT(nleaf,options)
% input
% nleaf: integer greater than 4.
% nedges_remove: ineger less than nleaf

% T is a tree structure
% T.m is the number of edges in T.
% T.e(1) is the root
% T.e(2:nleaf) are the pendants.
% T.e(nleaf+1:m) are the internal edges
% Each edge i has fields
% e(i).p the parent of i
% e(i).ch the children of i
% e(i).sl the smallest label in the subtree rooted at i.
% e(i).x the length of edge i.

% set options to defaults
edge_lengths.random = false;
%edge_lengths.distribution = 'uniform'; % 'uniform' or 'expo';
edge_lengths.fixed = 1;
%random_length = false; % edge lengths are uniform [0,1];
%use_exponential = false; % edge lengths are exponential with lambda
fixed_length = -1;
if nargin > 1
    if isfield(options,'edge_lengths')
        edge_lengths = options.edge_lengths;
    end
    if nleaf < 3
        display('nleaf must be at least 3')
        T = [];
        return;
    end
end


e(1).p = -1;
e(1).ch = 2:nleaf;
e(1).sl = 1;
for i = 2:nleaf
    e(i).p = 1;
    e(i).ch = -1;
    e(i).sl = i-1;
end

list = 1;
nedge = nleaf;
while ~isempty(list)
    c = list(1);
    chil = e(c).ch;
    nchil = length(chil);
    if nchil > 2
        rn = 2+floor(rand(1)*(nchil-2));
        rp = randperm(nchil);
        s1 = chil(rp(1:rn));
        s2 = chil(rp(rn+1:nchil));
        e(nedge+1).p = c;
        e(nedge+1).ch = s1;
        e(nedge+1).sl = min(s1)-1;
        if length(s2) > 1
            e(nedge+2).p = c;
            e(nedge+2).ch = s2;
            e(nedge+2).sl = min(s2)-1;
            e(c).ch = [nedge+1 nedge+2];
            list(end+1) = nedge+1;
            list(end+1) = nedge+2;
            nedge = nedge+2;
        else
            e(s2).p = c;
            e(c).ch = [nedge+1 s2];
            list(end+1) = nedge+1;
            nedge = nedge+1;
        end
        list(1) = [];
    else
        e(chil(1)).p = c;
        e(chil(2)).p = c;
        list(1) = [];
    end
end

if edge_lengths.random;
    if strcmp(edge_lengths.distribution,'uniform')
        for i = 1:nedge
            e(i).x = rand(1);
        end
    else
        pd = ProbDistUnivParam('exponential',edge_lengths.lambda);
        for i = 1:nedge
            e(i).x = random(pd,1);
        end
    end
else
    if fixed_length > -1
        l = fixed_length;
    else
        l = 1;
    end
    for i = 1:nedge
        e(i).x = l;
    end
end
T.e = e;
T.m = nedge;
T.nleaf = nleaf;