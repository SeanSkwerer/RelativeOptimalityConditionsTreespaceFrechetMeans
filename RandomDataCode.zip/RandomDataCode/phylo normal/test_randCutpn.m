try1 = false;
try2 = true;

if try1
    % set and save random stream
    s = RandStream('mrg32k3a','Seed',10588674);
    RandStream.setGlobalStream(s);
    savedState = s.State;
    nleaf = 20;
mu = randT(nleaf);
mu = random_collapse(mu,12);
options.stdev = 1;
options.edge_collapse = [1 2 3];
T2 = randCutpn(mu,options);


Label = 1:mu.m;
Parent = [mu.e(:).p];
Length = [mu.e(:).x];
plot_tree(Label,Parent,Length)
set(gcf,'WindowStyle','docked')

Label = 1:T2.m;
Parent = [T2.e(:).p];
Length = [T2.e(:).x];
plot_tree(Label,Parent,Length)
set(gcf,'WindowStyle','docked')
end

if try2
    % set and save random stream
    s = RandStream('mrg32k3a','Seed',1987987);
    RandStream.setGlobalStream(s);
    savedState = s.State;
    nleaf = 20;
mu = randT(nleaf);
mu = random_collapse(mu,12);
options.stdev = 1;
options.edge_collapse = [1 2 3];
T2 = randCutpn(mu,options);


Label = 1:mu.m;
Parent = [mu.e(:).p];
Length = [mu.e(:).x];
plot_tree(Label,Parent,Length)
set(gcf,'WindowStyle','docked')

Label = 1:T2.m;
Parent = [T2.e(:).p];
Length = [T2.e(:).x];
plot_tree(Label,Parent,Length)
set(gcf,'WindowStyle','docked')
end