function newtree = NNIgeostep(tree,d,r)

% e = tree.e
% e is a tree structure
% e(i).x length
% e(i).p parent
% e(i).s sister
% e(i).l left
% e(i).r right
% e(i).sl smallest leaf label in subtree
% tree.nleaf = number of leafs 
% tree.m = number of edges (including pendants)
% all edges have tails closer to the root leaf labeled zero.
% e(1:nleaf) are leaf edges, e(1) is the root, and e(k+1) is leaf labeled k, for k
% = 0:(nleaf-1). 
% e(nleaf+1:m) are internal edges
% d is a direction scaled so that norm(d(nleaf+1:m)) = 1
% r is a step length

% leaf edges are not effected by this procedure, only the internal edge
% length and topology of e are changed.
e = tree.e;
% check r
if r < 0
    disp('r must be positive')
    r = -1*r;
end
if r > 0
% check if tree has l and r or ch.
if isfield(e,'ch')
    if ~isfield(e,'l')
        for i = 1:length(e)
            e(i).l = e(i).ch(1);
            e(i).r = e(i).ch(2);
        end
    end
end
% check if tree has s
if ~isfield(e,'s')
    for i = 1:length(e)
        if e(i).p == -1
            e(i).s = -1;
        else
        if i == e(e(i).p).l
            e(i).s = e(e(i).p).r;
        else
            e(i).s = e(e(i).p).l;
        end
        end
    end
end
alpha = nan(tree.m,1);
for i = 1:tree.m
    if e(i).x > 0 && d(i)~=0
    alpha(i) = -1*e(i).x/d(i);
    elseif e(i).x == 0
       alpha(i) = -1;
       if d(i) < 0
           d(i) = d(i)*-1;
           disp('warning zero length edges cannot decrease')
           disp('d(i) = d(i)*-1')
       end
    else
      if e(i).x<0
        disp('error e(i) <0')
        break
      end
    end
end
% The nearest neighbor interchanges must be applied in order they occur
% along the geodesic.
[V,I] = sort(alpha,'ascend');
for i = 1:tree.m
    if I(i) > tree.nleaf
        j = I(i);
        if V(i) < 0
            e(j).x = e(j).x + r*d(j);
            if e(j).x < 0
                disp('flag1')
                disp(d(j))
                disp(r)
                
            end
        elseif V(i) <= r
            % nearest neighbor interchange
            parent = e(j).p;
            sister = e(j).s;
            right = e(j).r;
            left = e(j).l;
            
            sl_left = e(e(j).l).sl;
            sl_right = e(e(j).r).sl;
            
            % flip a coin to decide which edge enters
            rn = rand(1);
            % if rn <= 0.5 swap sister for child with smaller smallest label
            % if rn > 0.5 swap sister for child with larger smallest label
            if rn <= 0.5
                if sl_left < sl_right
                    case1 = true;
                else
                    case1 = false;
                end
            else
                if sl_left >= sl_right
                    case1 = true;
                else
                    case1 = false;
                end
            end
            % case1 is true then swap the sister for the left child
            % case1 is false then swap the sister for the right child
            if case1
                e(j).l = sister;
                e(j).s = left;
                e(sister).p = j;
                e(sister).s = right;
                e(left).p = parent;
                e(left).s = j;
                e(right).s = sister;
                e(parent).l = left;
                e(parent).r = j;
            else
                e(j).r = sister;
                e(j).s = right;
                e(sister).p = j;
                e(sister).s = left;
                e(right).p = parent;
                e(right).s = j;
                e(left).s = sister;
                e(parent).l = right;
                e(parent).r = j;
            end
            sl_left = e(e(j).l).sl;
            sl_right = e(e(j).r).sl;
            e(j).sl = min(sl_left,sl_right);
            e(j).x = -1*(r-V(i))*d(j);
            if e(j).x < 0
                disp('flag2')
            end
        else
            e(j).x = e(j).x + r*d(j);
            if e(j).x < 0
                disp('flag3')
            end
        end
    end
end
tree.e = e;
newtree = tree;
else
    newtree = tree;
end