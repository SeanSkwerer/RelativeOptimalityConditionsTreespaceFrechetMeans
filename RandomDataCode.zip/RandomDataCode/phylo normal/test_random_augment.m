test_tree1 = false;
test_tree2 = false;
test_rand_collapse = true;
if test_tree1
T.e(1).p = -1;
T.e(1).ch = [2 3 4];
T.e(1).sl = 1;
T.e(1).x = 0.1;
T.e(2).p = 1;
T.e(2).ch = -1;
T.e(2).sl = 1;
T.e(2).x = 0.2;
T.e(3).p = 1;
T.e(3).ch = -1;
T.e(3).sl = 2;
T.e(3).x = 0.3;
T.e(4).p = 1;
T.e(4).ch = -1;
T.e(4).sl = 3;
T.e(4).x = 0.4;

S = random_augment(T);
end

if test_tree2
    T.e(1).p = -1;
    T.e(1).ch = [2 8];
    T.e(1).sl = 1;
    T.e(1).x = 0.1;
    T.e(2).p = 1;
    T.e(2).ch = -1;
    T.e(2).sl = 1;
    T.e(2).x = 0.2;
    T.e(3).p = 8;
    T.e(3).ch = -1;
    T.e(3).sl = 2;
    T.e(3).x = 0.3;
    T.e(4).p = 9;
    T.e(4).ch = -1;
    T.e(4).sl = 3;
    T.e(4).x = 0.4;
    T.e(5).p = 9;
    T.e(5).ch = -1;
    T.e(5).sl = 4;
    T.e(5).x = 0.5;
    T.e(6).p = 9;
    T.e(6).ch = -1;
    T.e(6).sl = 5;
    T.e(6).x = 0.5;
    T.e(7).p = 8;
    T.e(7).ch = -1;
    T.e(7).sl = 6;
    T.e(7).x = 0.6;
    T.e(8).p = 1;
    T.e(8).ch = [3 9 7];
    T.e(8).sl = 2;
    T.e(8).x = 0.8;
    T.e(9).p = 8;
    T.e(9).ch = [4 5 6];
    T.e(9).sl = 3;
    T.e(9).x = 0.9;
    
    S = random_augment(T);
end

if test_rand_collapse
    rng(7,'twister');
    filestr = ['BinaryTrees9leaves.tre'];
    fid = fopen(filestr,'r');
    line = fgetl(fid);
    T = newick2tree(line);
    for i = 1:length(T.e)
        T.e(i).x = 0;
    end
    T2 = random_collapse(T,3);
    T3 = random_augment(T2);
end