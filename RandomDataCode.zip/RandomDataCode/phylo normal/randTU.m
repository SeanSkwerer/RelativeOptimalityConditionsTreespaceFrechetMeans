function T = randTU(nleaf,options)
% purpose: sample uniformely from binary tree topologies with nleaf leafs.

% input
% nleaf: integer greater or equal to 5.

% ouput
% T is a random binary tree with nleafs sampled with uniform probability.
% T is a tree structure
% T.m is the number of edges in T.
% T.e(1) is the root
% T.e(2:nleaf) are the pendants.
% T.e(nleaf+1:m) are the internal edges
% Each edge i has fields
% e(i).p the parent of i
% e(i).ch the children of i
% e(i).sl the smallest label in the subtree rooted at i.
% e(i).x the length of edge i.

% set options to defaults
random_length = false;
fixed_length = -1;
if nargin > 1
    if isfield(options,'random_lengths')
        random_length = true;
    end
    if isfield(options,'fixed_length')
        fixed_length = options.fixed_length;
    end
end
    if nleaf < 4
        display('nleaf must be at least 4')
        T = [];
        return;
    end

rn = rand(1);
if rn < 1/3
    str = '0(1(2,3));';
elseif rn < 2/3
    str = '0(2(1,3));';
else
    str = '0(3(1,2));';
end
str1 = str;
c = 4;
while c <= nleaf
    n = c;
    str = str1;
    rn_j = ceil(rand(1)*(n*2-3));
    index = 2;
    symb = str(index);
    j = 1;
    while j <= nleaf*2-3
        if strcmp(symb,',')
            index = index+1;
            symb = str(index);
        elseif strcmp(symb,')')
            index = index+1;
            symb = str(index);
        elseif strcmp(symb,'(')
            % found a subtree
            index2 = index+1;
            depth = 1;
            while depth > 0
                if strcmp(str(index2),'(')
                    depth = depth+1;
                    index2 = index2+1;
                elseif strcmp(str(index2),')')
                    depth = depth-1;
                    if depth == 0
                        break
                    end
                    index2 = index2+1;
                else
                    index2 = index2+1;
                end
            end
            if j == rn_j
                str1 = [str(1:index-1),'(',num2str(n),...
                    str(index:index2),')',str(index2+1:end)];
                break;
            end
            index = index+1;
            symb = str(index);
            j = j+1;
        else
            % found a leaf
            % leaf starts at index
            k = index;
            k1 = k+1;
            while str(k1) ~= ',' && str(k1) ~= ')' && str(k1) ~= '('
                k1 = k1+1;
            end
            if strcmp(str(k1),',')
                if j == rn_j
                    str1 = [str(1:index-1),'(',num2str(n),',',...
                        str(k:k1-1),')',str(k1:end)];
                    break
                end
            elseif strcmp(str(index-1),',')
                if j == rn_j
                    str1 = [str(1:index-2),'(',num2str(n),',',...
                        str(k:k1-1),')',str(k1:end)];
                    break
                end
                
            else
                if j == rn_j
                    str1 = [str(1:index-1),'(',num2str(n),',',...
                        str(k:k1-1),')',str(k1:end)];
                    break
                end
            end
            index = k1;
            symb = str(index);
            j = j+1;
        end
    end
    c = c+1;
end
T = newick2tree(str);
if length(T.e) ~= 2*nleaf-3
    disp('err')
end
e = T.e;
if random_length
    for i = 1:T.m
        e(i).x = rand(1);
    end
else
    if fixed_length > -1
        l = fixed_length;
    else
        l = 1;
    end
    for i = 1:T.m
        e(i).x = l;
    end
end
T.e = e;
T.m = T.m;
T.nleaf = nleaf;