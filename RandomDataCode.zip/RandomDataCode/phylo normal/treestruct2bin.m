function [sigma_binary,L] = treestruct2bin(T)
Label = 1:T.m;
Parent = [T.e(:).p];
Landmark = -1*ones(1,T.m);
for i = 1:T.m
    if T.e(i).ch(1) < 0
        Landmark(i) = T.e(i).sl+1;
        %Landmark(i) = T.e(i).sl;
    elseif T.e(i).p < 0
        Landmark(i) = 1;
    else
        Landmark(i) = -1;
    end
end
if (max(Landmark)>sum(Landmark>0))
    for i=1:T.m
        if (Landmark(i)>1)
            Landmark(i)=Landmark(i)-1;
        end
    end
end

L = [T.e(:).x];
%import_tree_data;
n = size(Label,2);
m = sum(Landmark > 0);

sigma_binary = zeros(n,m);
tum_sum = 0;
c = 0;
for i = 1:n
    label = Label(i);
    s = get_split_binary(label,Label,Parent,Landmark,m);
    tum_sum = tum_sum + sum(s);
    if sum(s) > 0 && Landmark(i) > -1
        c = c+1;
    end
    sigma_binary(i,:) = s;
end
for i=1:length(Landmark)
    if (Landmark(i)>0)
        Landmark(i)=Landmark(i)-1;
    end
end
