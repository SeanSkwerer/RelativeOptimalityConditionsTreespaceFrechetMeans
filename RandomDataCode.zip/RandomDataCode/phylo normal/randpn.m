function T = randpn(T0,options)
% e = T0.e
% e has fields
% e(i).p parent
% e(i).ch children
% e(i).x length
% e(i).sl smallest leaf label in subtree
% T0.nleaf = number of leafs
% T0.m = number of edges (including pendants)

% edges are directed from the root( leaf labeled 0) to the other leafs.
% e(1:nleaf) are leaf edges, e(1) is the root, and e(k+1) is leaf labeled k, for k
% = 0:(nleaf-1).
% e(nleaf+1:m) are internal edges

% options
% options.stdev standard deviation of distribution

% set options to defaults
stdev = 1;
if nargin > 1
    if isfield(options,'stdev')
        stdev = options.stdev;
    end
end

if T0.nleaf <= 3
    T = T0;
    return
end
if T0.m < 2*T0.nleaf-3
    % augment T0 to T a full bifurcating tree
    T = random_augment(T0);
else
    T = T0;
end
clear T0;
% need to use NNIgeostep(tree,d,r) which has some additional fields
% e new fields:
% e(i).s sister
% e(i).l left <- e.ch(1)
% e(i).r right <- e.ch(2)
e = T.e;
for i = 1:T.m
    if T.e(i).ch(1) == -1
        T.e(i).l = -1;
        T.e(i).r = -1;
    else
        T.e(i).l = T.e(i).ch(1);
        T.e(i).r = T.e(i).ch(2);
    end
end
T.e = rmfield(T.e,'ch');
% NNIgeostep
% for this function input d is a rate of change vector
% d(i) is the rate of change of e(i) scaled so that norm(d(nleaf+1:m)) = 1
% r is the step length (positive number)

d = [zeros(T.nleaf,1); randn(T.m-T.nleaf,1)];
r = norm(d(T.nleaf+1:T.m)*stdev);
r1 = norm(d(T.nleaf+1:T.m));
d = d/r1;
for i = 1:T.m
    if T.e(i).x == 0
        if d(i) < 0
            d(i) = -1*d(i);
        end
    end
end
T = NNIgeostep(T,d,r);
% update e(i).ch
for i = 1:T.m
    T.e(i).ch(1) = T.e(i).l;
    T.e(i).ch(2) = T.e(i).r;
end
T.e = rmfield(T.e,'l');
T.e = rmfield(T.e,'r');
T.m = length(T.e);


