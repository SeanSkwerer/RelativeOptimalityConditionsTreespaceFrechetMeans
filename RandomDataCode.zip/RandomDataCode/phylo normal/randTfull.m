function [T]=randTfull(r,shift,scale)
T=randT(r);
[T.E,T.L]=treestruct2bin(T);
T.L=shift+T.L+scale*rand(size(T.L));
T=bin2numeric(T);
t=bin2parent(T);
T.e=t.e;
