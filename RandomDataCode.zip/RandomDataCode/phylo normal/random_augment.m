function T = random_augment(T)
% T is a tree structure
% T.m is the number of edges in T.
% T.e(1) is the root
% T.e(2:nleaf) are the pendants.
% T.e(nleaf+1:m) are the internal edges
% Each edge i has fields
% e(i).p the parent of i
% e(i).ch the children of i
% e(i).sl the smallest label in the subtree rooted at i.
% e(i).x the length of edge i.

% each vertex v of T with degree d greater than three is expanded vis a vis
% some random element t from the treespace with leafs {0,1,...,d}. Each of
% the edges of v are each associated with one leafs of t. The parent edge
% of v is assocated with the root of t, the i'th child of v is associated
% with the i'th leaf of t.
e = T.e;
if isfield('m',T)
    m = T.m;
else
    m = length(e);
end
nleaf = 2;
while e(nleaf).ch == -1;
    nleaf = nleaf+1;
    if nleaf > m
        break
    end
end
nleaf = nleaf-1;
% now nleaf is exactly the number of leafs in T (including the root).
% check the degree of the internal vertex after the root
i = 1;
childn = e(i).ch;
d_i = length(childn)+1;
if d_i > 3
    % the degree of the head of edge i is greater than 3.
    % select an element from the treespace d_i leafs.
%     filestr = ['BinaryTrees',num2str(d_i),'leaves.tre'];
%     fid = fopen(filestr,'r');
%     % select a random element from the (2*d-5)!! trees with d leafs
%     n_trees = prod((2*d_i-5):-2:1);
%     rand_n = ceil(rand(1)*n_trees);
%     for c = 1:rand_n-1
%         fgetl(fid);
%     end
%     line = fgetl(fid);
% %     disp(line);
%     T2 = newick2tree(line);
    T2 = randTU(d_i);
        nleaf2 = d_i; % T2 has d_i leafs;
    %         e(i).ch = T2.e(1).ch;
    e(i).ch = [];
    if T2.e(1).ch(1) > nleaf2
        e(i).ch(1) = T2.e(1).ch(1)+m-nleaf2;
    else
        e(i).ch(1) = childn(T2.e(T2.e(1).ch(1)).sl);
    end
    if T2.e(1).ch(2) > nleaf2
        e(i).ch(2) = T2.e(1).ch(2)+m-nleaf2;
    else
        e(i).ch(2) = childn(T2.e(T2.e(1).ch(2)).sl);
    end
    
    LIST2 = T2.e(1).ch;
    while ~isempty(LIST2)
        % grab the first element of LIST2
        v = LIST2(1);
        LIST2(1) = [];
        if T2.e(v).ch ~= -1
            LIST2(end+1) = T2.e(v).ch(1);
            LIST2(end+1) = T2.e(v).ch(2);
        end
        if v <= nleaf2 % v is a leaf of T2
            % parent
            if T2.e(v).p == 1
                e(childn(T2.e(v).sl)).p = i;
            else
                e(childn(T2.e(v).sl)).p = m + T2.e(v).p - nleaf2;
            end
            % children stay the same
            % x stays the same
            % sl stays the same
        else
            % v is an internal edge of T2
            % parent
            if T2.e(v).p > nleaf2
                e(m+v-nleaf2).p = T2.e(v).p-nleaf2+m;
            else
                e(m+v-nleaf2).p = i;
            end
            % length
            e(m+v-nleaf2).x = 0;
            % children
            if T2.e(v).ch(1) <= nleaf2
                % child is a leaf of T2
                if T2.e(v).ch(1) == 1
                    % child is the root! can't happen
                else
                    e(m+v-nleaf2).ch(1) = childn(T2.e(T2.e(v).ch(1)).sl);
                end
            else
                % child is an internal edge of T2
                e(m+v-nleaf2).ch(1) = T2.e(v).ch(1)+m-nleaf2;
            end
            if T2.e(v).ch(2) <= nleaf2
                % child is a leaf of T2
                e(m+v-nleaf2).ch(2) = childn(T2.e(T2.e(v).ch(2)).sl);
            else
                % child is an internal edge of T2
                e(m+v-nleaf2).ch(2) = T2.e(v).ch(2)+m-nleaf2;
            end
            % smallest label
            % can't be done yet
        end
    end
end
m_original = m;
m = length(e);
for i = nleaf+1:m_original
    % check the degree of each internal vertex
    childn = e(i).ch;
    d_i = length(childn)+1;
    if d_i > 3
%         % the degree of the head of edge i is greater than 3.
%         % select an element from the treespace d_i leafs.
%         filestr = ['BinaryTrees',num2str(d_i),'leaves.tre'];
%         fid = fopen(filestr,'r');
%         % select a random element from the (2*d-5)!! trees with d leafs
%         n_trees = prod((2*d_i-5):-2:1);
%         rand_n = ceil(rand(1)*n_trees);
%         for c = 1:rand_n-1
%             fgetl(fid);
%         end
%         line = fgetl(fid);
% %         disp(line);
%         T2 = newick2tree(line);
        T2 = randTU(d_i);
        nleaf2 = d_i; % T2 has d_i leafs;
        %         e(i).ch = T2.e(1).ch;
        e(i).ch = [];
        if T2.e(1).ch(1) > nleaf2
            e(i).ch(1) = T2.e(1).ch(1)+m-nleaf2;
        else
            e(i).ch(1) = childn(T2.e(T2.e(1).ch(1)).sl);
        end
        if T2.e(1).ch(2) > nleaf2
            e(i).ch(2) = T2.e(1).ch(2)+m-nleaf2;
        else
            e(i).ch(2) = childn(T2.e(T2.e(1).ch(2)).sl);
        end
        
        LIST2 = T2.e(1).ch;
        while ~isempty(LIST2)
            % grab the first element of LIST2
            v = LIST2(1);
            LIST2(1) = [];
            if T2.e(v).ch ~= -1
                LIST2(end+1) = T2.e(v).ch(1);
                LIST2(end+1) = T2.e(v).ch(2);
            end
            if v <= nleaf2 % v is a leaf of T2
                % parent
                if T2.e(v).p == 1
                    e(childn(T2.e(v).sl)).p = i;
                else
                    e(childn(T2.e(v).sl)).p = m + T2.e(v).p - nleaf2;
                end
                %e(chldn(v)).ch  stays the same
                %e(chldn(v)).x stays the same
                %e(chlnd(v)).sl stays the same
            else
                % v is an internal edge of T2
                % parent
                if T2.e(v).p > nleaf2
                    e(m+v-nleaf2).p = T2.e(v).p-nleaf2+m;
                else
                    e(m+v-nleaf2).p = i;
                end
                % length
                e(m+v-nleaf2).x = 0;
                % children
                if T2.e(v).ch(1) <= nleaf2
                    % child is a leaf of T2
                    e(m+v-nleaf2).ch(1) = childn(T2.e(T2.e(v).ch(1)).sl);
                else
                    % child is an internal edge of T2
                    e(m+v-nleaf2).ch(1) = T2.e(v).ch(1)+m-nleaf2;
                end
                if T2.e(v).ch(2) <= nleaf2
                    % child is a leaf of T2
                    e(m+v-nleaf2).ch(2) = childn(T2.e(T2.e(v).ch(2)).sl);
                else
                    % child is an internal edge of T2
                    e(m+v-nleaf2).ch(2) = T2.e(v).ch(2)+m-nleaf2;
                end
                % smallest label
                e(m+v-nleaf2).sl = -1;
            end
        end
    end
    m = length(e);
end
% update the smallest labels in the subtree
for i = 1:m
    e(i).chx = 0;
end
u = 1;
while v ~= -1
    if e(u).chx == 2 || e(u).ch(1) == -1
        if e(u).chx == 2
            e(u).sl = min(e(e(u).ch).sl);
        end
        v = e(u).p;
    else
        e(u).chx = e(u).chx+1;
        v = e(u).ch(e(u).chx);
    end
    u = v;
end
e = rmfield(e,'chx');

% output
T.e = e;
T.m = length(e);