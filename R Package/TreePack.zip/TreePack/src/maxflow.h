// maxflow.h
#ifndef MAXFLOW_H
#define MAXFLOW_H
#include <R.h>
#include <Rcpp.h>

using namespace Rcpp;

#include "make_outfile.h"

//#include <cstdlib>

//using namespace std;

void min_weight_cover(int *n1_in, int *n2_in, int *g, int *gg1, int *gn1, int *gg2, int *gn2, double *u1, double *u2, double *x, double *x1, double* x2, int *c1, int *c2, int *nc1, int *nc2);

void find_MWC(int n1, int n2, int *g, int *gg1, int *gn1, int *gg2, int *gn2, double *u1, double *u2, double *x, double *x1, double *x2, int *d1, int *d2, int *c1, int *c2, int *nc1, int *nc2);

void aug_flow_MWC(int n1, int n2, int *g, int *gg1, int *gn1, int *gg2, int *gn2, double *u1, double *u2, double *x, double *x1, double *x2, int *d1, int *d2, int *p, int *n, double *c);

void find_aug_path_MWC(int n1, int n2, int *g, int *gg1, int *gn1, int *gg2, int *gn2, double *u1, double *u2, double *x, double *x1, double *x2, int *d1, int *d2, int *p, int *n, double *c);

void push_flow_MWC(int n1, int n2, int *g, double *u1, double *u2, double *x, double *x1, double* x2,int* p, int n, double c);
#endif
