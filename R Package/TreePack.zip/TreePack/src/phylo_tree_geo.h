// phylo_tree_geo.h
#ifndef PHYLO_TREE_GEO_H
#define PHYLO_TREE_GEO_H
#include<R.h>
//#include<cstdlib>
//using namespace std;

#include "maxflow.h"
#include "make_outfile.h"

extern "C"{
  void geo_step(int *k1_in, int *k2_in, int *t1, int *t2, double *l1, double *l2, int *a, int *b, double *lambda, int *t, double *l, int *k);
}
void geo_step_outfile(int *k1_in, int *k2_in, int *t1, int *t2, double *l1, double *l2, int *a, int *b, double *lambda, int *t, double *l, int *k, ofstream &outfilestream);

void geo_step_incomp(double lambda,int k1, int k2, int *t1, int *t2, double *l1, double *l2, int *a, int *b, double *an, double *bn, int leg, int *t, double *l, int *k, int k_start);

void geo_step_comp(double lambda,int k1, int k2, int *t1, int *t2, double *l1, double *l2, int *a, int *b, double *an, double *bn, int *t, double *l, int *k, int k_start);

void find_leg(int k1, int k2, double *an, double *bn, double lambda, int *leg);

void support_norms(int k1, int k2, double *l1, double *l2, int *a, int *b, double *an, double *bn);

void support_norms_restricted(int k1, int k2, double *l1, double *l2, int *a, int *b, double *an, double *bn, int *activeA, int *activeB, int nactiveA, int nactiveB);


extern "C"{
  void geo_dist_in(int *k1, int *k2, int *t1, int *t2, double *l1, double *l2, int *g, int *n, int *a, int *b, double *d);
}

void geo_dist(int* k1, int* k2, int* a, int *b, double *l1, double *l2, double *d);

void geo_dist_comp(int k1, int k2, int *a, int *b, double *l1, double *l2, double *d);

void geo_dist_incomp(int k1, int k2, int *a, int *b, double *l1, double *l2, double *d);

void phylo_tree_geo(int *k1_in, int *k2_in, int *t1, int *t2, double *l1, double *l2, int *g, int n, int *a, int *b);


void phylo_tree_geo_no_alloc(int *k1_in, int *k2_in, int *t1, int *t2, double *l1, double *l2, int *g, int n, int *a, int *b,
                               int *g0, int *g1, int *i1, int *i2, int *a1, int *b1, double *ll1, double *ll2);

void phylo_tree_geo_warm_start(int *k1_in, int *k2_in, int *t1, int *t2, double *l1, double *l2, int *g, int n, int *a, int *b,
                               int *g0, int *g1, int *i1, int *i2, int *a1, int *b1, double *ll1, double * ll2);

void make_incomp_graph(int k1, int k2, int* t1, int* t2, int *g, int n, int* g0);

void phylo_tree_g(int k1, int k2, double *l1, double *l2, int *g0, int *a, int *b);

void phylo_tree_g_warm_start(int k1, int k2, double *l1, double *l2, int *g0, int *a, int *b);

void phylo_tree_geo_hot_start();

#endif
