// make_link.h
#ifndef MAKE_LINK_H
#define MAKE_LINK_H

#include <R.h>
#include <Rcpp.h>
using namespace Rcpp;


extern "C"{
 void make_link(int *n, int* nt, int* t, int *ne, int *max, int *ngd, int *gd, int *ngdi, int* g, int *ng, int *gt, int *gte, int* ti);
}

void compare_edges(int* a, int* b, int n, int *v);

void convert_edge(int *tree, int n, int e, int *a, int val, int m);

#endif
