// make_link.c
#include "make_link.h"
extern "C"{
  //void distinct_edges(int *n_in, int* nt, int* t, int *ne, int *max_in, int *ngd, int *gd, int *ngdi, int* g, int *ng, int *gt, int *gte, int* ti)
  void distinct_edges(int *n_in, int* nt, int* t, int *ne, int *max_in, int *ng, int *gt, int *gte, int* ti)
  {
    // ************************************************************************
    // input descriptions
    // ************************************************************************
    // n is the number of trees
    // nt is an arrray with n elements nt[i] is length of t used by tree i
    // ne is an array with n elements ne[i] is number of edges in tree i
    // t is a sum(nt) length array
    //    entries 0 to nt[1]-1 represents tree 1
    //    entries nt[i] to nt[1]+nt[2] represents tree 2 and so on
    //    **** sequence starts with the root index which is always 0 ****
    //    subtrees are delimeted with -1 on the left and -2 on the right
    //    pendants count as subtrees
    //    the tree ends with -3
    //    e.g. using index set 0 1 2 3 4
    //    0 -1 -1 1 -2 -1 -1 -1 2 -2 -1 3 -2 -2 -1 4 -2 -2 -2
    //    is the tree with 5 pendants
    //    and two other splits
    //    0 1 | 2 3 4
    //    0 1 4 | 2 3
    //
    // max -- index set ranges from 0 to max-1
    // ng is the number of distinct edges
    // ti array which stores indexed representations of trees
    //    0 to ne[0]-1 represents tree 0
    //    ne[0] to ne[0]+ne[1] represents tree 1 and so on
    // edge gte[i] in tree gt[i] is an example of edge for row i of g
    // ************************************************************************
    // ************************************************************************
    // variables
    // ************************************************************************
    // e and f index edges; take values between 0 and max-1
    // i and j index trees; take values from 0 to n-1
    // k counts the number of distinct edges
    // k0 stores the corrent number of distinct edges before the next tree is checked
    // ng0 is the total of the number of edges in each tree
    // val stores integer values for input or output of subroutines
    // found_edge 1 indicates duplicate edge found, 0 otherwise
    // max is the size of the index set
    // n is the number of trees
    // a array storing indicator version of an edge; 1 by max array.
    // b array storing indicator version of edge; 1 by max array.
    // st[i] is the starting index for the i'th tree in t
    // sti[i] is the starting index for the i'th tree in ti
    int e,f,i,j,k,k0,ng0,val,found_edge;
    int max,n;
    max=*max_in;
    n=*n_in;
    int *a,*b,*st,*sti;
    //ng0=*ngd;
    a=Calloc(max,int); b=Calloc(max,int);
    st=Calloc(n,int); sti=Calloc(n,int);
    k=0;
    st[0]=0;
    for (i=1;i<n;i++) st[i]=st[i-1]+nt[i-1];
    sti[0]=0;
    for (i=1;i<n;i++) sti[i]=sti[i-1]+ne[i-1];

    for (e=0;e<ne[0];e++)
    {
      // for (f=0;f<ne[0];f++)
      // {
      //   g[e*ng0+f]=1;
      // }
      gt[e]=0;
      gte[e]=e;
      ti[e]=k;
      // convert_edge(t+st[0],max,e,a,1,nt[0]);
      // Rcout<<"new edge found! k="<<k+1<<"\n";
      // Rcout<<"a: ";
      // for (int l=0;l<max;l++)
      // {
      //   Rcout<<a[l]<<" ";
      // }
      // Rcout<<"\n";
      k++;
    }
    for (i=1;i<n;i++)
    {
      k0=k;
      // compare each edge of tree i to all previous edges
      for (e=0;e<ne[i];e++)
      {
        found_edge=0;
        for (j=0;j<k0;j++)
        {
          convert_edge(t+st[i],max,e,a,1,nt[i]);
          convert_edge(t+st[gt[j]],max,gte[j],b,-1,nt[gt[j]]);
          compare_edges(a,b,max,&val);
          // if (val==1)
          // {
          //   g[j*ng0+k]=1;
          //   g[k*ng0+j]=1;
          // }
          if (val==2)
          {
            found_edge=1;
            break;
          }
        }
        if (found_edge==1)
        {
          ti[sti[i]+e]=j;
          // for (f=0;f<j;f++)
          // {
          //   g[k*ng0+f]=0;
          //   g[f*ng0+k]=0;
          // }
        }
        else
        {
          // Rcout<<"new edge found! k="<<k+1<<"\n";
          // Rcout<<"a: ";
          // for (int l=0;l<max;l++)
          // {
          //   Rcout<<a[l]<<" ";
          // }
          // Rcout<<"\n";
          gt[k]=i;
          gte[k]=e;
          ti[sti[i]+e]=k;
          k++;
        }
      }
      // for (e=k0;e<k;e++)
      // {
      //   for (f=k0;f<k;f++)
      //   {
      //     g[e*ng0+f]=1;
      //   }
      // }
    }
    *ng=k;
    Free(a);Free(b);Free(st); Free(sti);
  }
}

void distinct_edges_old(int *n_in, int* nt, int* t, int *ne, int *max_in, int *ng, int *gt, int *gte, int* ti)
{
  // ************************************************************************
  // input descriptions
  // ************************************************************************
  // n is the number of trees
  // nt is an arrray with n elements nt[i] is length of t used by tree i
  // ne is an array with n elements ne[i] is number of edges in tree i
  // t is a sum(nt) length array
  //    entries 0 to nt[1]-1 represents tree 1
  //    entries nt[i] to nt[1]+nt[2] represents tree 2 and so on
  //    **** sequence starts with the root index which is always 0 ****
  //    subtrees are delimeted with -1 on the left and -2 on the right
  //    pendants count as subtrees
  //    the tree ends with -3
  //    e.g. using index set 0 1 2 3 4
  //    0 -1 -1 1 -2 -1 -1 -1 2 -2 -1 3 -2 -2 -1 4 -2 -2 -2
  //    is the tree with 5 pendants
  //    and two other splits
  //    0 1 | 2 3 4
  //    0 1 4 | 2 3
  //
  // max -- index set ranges from 0 to max-1
  // ng is the number of distinct edges
  // ti array which stores indexed representations of trees
  //    0 to ne[0]-1 represents tree 0
  //    ne[0] to ne[0]+ne[1] represents tree 1 and so on
  // edge gte[i] in tree gt[i] is an example of edge for row i of g
  // ************************************************************************
  // ************************************************************************
  // variables
  // ************************************************************************
  // e and f index edges; take values between 0 and max-1
  // i and j index trees; take values from 0 to n-1
  // k counts the number of distinct edges
  // k0 stores the corrent number of distinct edges before the next tree is checked
  // ng0 is the total of the number of edges in each tree
  // val stores integer values for input or output of subroutines
  // found_edge 1 indicates duplicate edge found, 0 otherwise
  // max is the size of the index set
  // n is the number of trees
  // a array storing indicator version of an edge; 1 by max array.
  // b array storing indicator version of edge; 1 by max array.
  // st[i] is the starting index for the i'th tree in t
  // sti[i] is the starting index for the i'th tree in ti
  int e,f,i,j,k,k0,ng0,val,found_edge;
  int max,n;
  max=*max_in;
  n=*n_in;
  int *a,*b,*st,*sti;
  //ng0=*ngd;
  a=Calloc(max,int); b=Calloc(max,int);
  st=Calloc(n,int); sti=Calloc(n,int);
  k=0;
  st[0]=0;
  for (i=1;i<n;i++) st[i]=st[i-1]+nt[i-1];
  sti[0]=0;
  for (i=1;i<n;i++) sti[i]=sti[i-1]+ne[i-1];

  for (e=0;e<ne[0];e++)
  {
    // for (f=0;f<ne[0];f++)
    // {
    //   g[e*ng0+f]=1;
    // }
    gt[e]=0;
    gte[e]=e;
    ti[e]=k;
    // convert_edge(t+st[0],max,e,a,1,nt[0]);
    // Rcout<<"new edge found! k="<<k+1<<"\n";
    // Rcout<<"a: ";
    // for (int l=0;l<max;l++)
    // {
    //   Rcout<<a[l]<<" ";
    // }
    // Rcout<<"\n";
    k++;
  }
  for (i=1;i<n;i++)
  {
    k0=k;
    // compare each edge of tree i to all previous edges
    for (e=0;e<ne[i];e++)
    {
      found_edge=0;
      for (j=0;j<k0;j++)
      {
        convert_edge(t+st[i],max,e,a,1,nt[i]);
        convert_edge(t+st[gt[j]],max,gte[j],b,-1,nt[gt[j]]);
        compare_edges(a,b,max,&val);
        // if (val==1)
        // {
        //   g[j*ng0+k]=1;
        //   g[k*ng0+j]=1;
        // }
        if (val==2)
        {
          found_edge=1;
          break;
        }
      }
      if (found_edge==1)
      {
        ti[sti[i]+e]=j;
        // for (f=0;f<j;f++)
        // {
        //   g[k*ng0+f]=0;
        //   g[f*ng0+k]=0;
        // }
      }
      else
      {
        // Rcout<<"new edge found! k="<<k+1<<"\n";
        // Rcout<<"a: ";
        // for (int l=0;l<max;l++)
        // {
        //   Rcout<<a[l]<<" ";
        // }
        // Rcout<<"\n";
        gt[k]=i;
        gte[k]=e;
        ti[sti[i]+e]=k;
        k++;
      }
    }
    // for (e=k0;e<k;e++)
    // {
    //   for (f=k0;f<k;f++)
    //   {
    //     g[e*ng0+f]=1;
    //   }
    // }
  }
  *ng=k;
  Free(a);Free(b);Free(st); Free(sti);
}

extern "C"{
  void make_link(int *n_in, int* nt, int* t, int *ne, int *max_in, int *ngd, int *gd, int *ngdi, int* g, int *ng, int *gt, int *gte, int* ti)
  {
    // ************************************************************************
    // input descriptions
    // ************************************************************************
    // n is the number of trees
    // nt is an arrray with n elements nt[i] is length of t used by tree i
    // ne is an array with n elements ne[i] is number of edges in tree i
    // t is a sum(nt) length array
    //    entries 0 to nt[1]-1 represents tree 1
    //    entries nt[i] to nt[1]+nt[2] represents tree 2 and so on
    //    **** sequence starts with the root index which is always 0 ****
    //    subtrees are delimeted with -1 on the left and -2 on the right
    //    pendants count as subtrees
    //    the tree ends with -3
    //    e.g. using index set 0 1 2 3 4
    //    0 -1 -1 1 -2 -1 -1 -1 2 -2 -1 3 -2 -2 -1 4 -2 -2 -2
    //    is the tree with 5 pendants
    //    and two other splits
    //    0 1 | 2 3 4
    //    0 1 4 | 2 3
    //
    // max -- index set ranges from 0 to max-1
    // gd is storage for directed link graph
    //    gd[i*ngd to (i+1)*ngd-1] includes j if i contains j and includes -j if the complement of i contains j
    //    ngdi[i] is the number of elements stored in row i
    // g is storage for link graph g[i*ng+j] is 1 if i contains j, -1 if the complement of i contains j, and 0 otherwise
    //   ****** assumes g is initialize to zeros prior to input *********
    // ngd -- g is ngd x ngd array
    // ng is the number of distinct edges
    // ti array which stores indexed representations of trees
    //    0 to ne[0]-1 represents tree 0
    //    ne[0] to ne[0]+ne[1] represents tree 1 and so on
    // edge gte[i] in tree gt[i] is an example of edge for row i of g
    // ************************************************************************
    // ************************************************************************
    // variables
    // ************************************************************************
    // e and f index edges; take values between 0 and max-1
    // i and j index trees; take values from 0 to n-1
    // k counts the number of distinct edges
    // k0 stores the corrent number of distinct edges before the next tree is checked
    // ng0 is the total of the number of edges in each tree
    // val stores integer values for input or output of subroutines
    // found_edge 1 indicates duplicate edge found, 0 otherwise
    // max is the size of the index set
    // n is the number of trees
    // a array storing indicator version of an edge; 1 by max array.
    // b array storing indicator version of edge; 1 by max array.
    // st[i] is the starting index for the i'th tree in t
    // sti[i] is the starting index for the i'th tree in ti
    int e,f,i,j,k,k0,ng0,val,found_edge;
    int max,n;
    max=*max_in;
    n=*n_in;
    int *a,*b,*st,*sti;
    ng0=*ngd;
    a=Calloc(max,int); b=Calloc(max,int);
    st=Calloc(n,int); sti=Calloc(n,int);
    k=0;
    st[0]=0;
    for (i=1;i<n;i++) st[i]=st[i-1]+nt[i-1];
    sti[0]=0;
    for (i=1;i<n;i++) sti[i]=sti[i-1]+ne[i-1];

    int i0,j0;
    for (i0=0;i0<(ng0-1);i0++)
    {
      for (j0=(i0+1);j0<ng0;j0++)
      {
        i=gt[i0];
        j=gt[j0];
        e=gte[i0];
        f=gte[j0];
        convert_edge(t+st[i],max,e,a,1,nt[i]);
        convert_edge(t+st[j],max,f,b,-1,nt[j]);
        compare_edges(a,b,max,&val);
        if (val==1)
        {
          g[i0*ng0+j0]=1;
          g[j0*ng0+i0]=1;
        }
      }
      g[i0*ng0+i0]=1;
    }
    g[ng0*ng0-1]=1;

    // for (e=0;e<ne[0];e++)
    // {
    //   for (f=0;f<ne[0];f++)
    //   {
    //     g[e*ng0+f]=1;
    //     g[f*ng0+e]=1;
    //   }
    //   //gt[e]=0;
    //   //gte[e]=e;
    //   //ti[e]=k;
    //   k++;
    // }
    // for (i=1;i<n;i++)
    // {
    //   k0=k;
    //   // compare each edge of tree i to all previous edges
    //   for (e=0;e<ne[i];e++)
    //   {
    //     found_edge=0;
    //     for (j=0;j<k0;j++)
    //     {
    //       convert_edge(t+st[i],max,e,a,1,nt[i]);
    //       convert_edge(t+st[gt[j]],max,gte[j],b,-1,nt[gt[j]]);
    //       compare_edges(a,b,max,&val);
    //       if (val==1)
    //       {
    //         g[j*ng0+k]=1;
    //         g[k*ng0+j]=1;
    //       }
    //       if (val==2)
    //       {
    //         found_edge=1;
    //         break;
    //       }
    //     }
    //     if (found_edge==1)
    //     {
    //       ti[sti[i]+e]=j;
    //       for (f=0;f<j;f++)
    //       {
    //         g[k*ng0+f]=0;
    //         g[f*ng0+k]=0;
    //       }
    //     }
    //     else
    //     {
    //       //  gt[k]=i;
    //       //  gte[k]=e;
    //       //  ti[sti[i]+e]=k;
    //       g[ng0*k+k]=1;
    //       k++;
    //     }
    //     if (k==ng0) break; //found all distinct edges
    //   }
    //   for (e=k0;e<k;e++)
    //   {
    //     for (f=k0;f<k;f++)
    //     {
    //       g[e*ng0+f]=1;
    //       g[f*ng0+e]=1;
    //     }
    //   }
    // }
    // Rcout<<k<<"\n";
    *ng=ng0;
    Free(a);Free(b);Free(st); Free(sti);
  }
}

extern "C"{
 void make_link_old(int *n_in, int* nt, int* t, int *ne, int *max_in, int *ngd, int *gd, int *ngdi, int* g, int *ng, int *gt, int *gte, int* ti)
 {
  // ************************************************************************
  // input descriptions
  // ************************************************************************
  // n is the number of trees
  // nt is an arrray with n elements nt[i] is length of t used by tree i
  // ne is an array with n elements ne[i] is number of edges in tree i
  // t is a sum(nt) length array
  //    entries 0 to nt[1]-1 represents tree 1
  //    entries nt[i] to nt[1]+nt[2] represents tree 2 and so on
  //    **** sequence starts with the root index which is always 0 ****
  //    subtrees are delimeted with -1 on the left and -2 on the right
  //    pendants count as subtrees
  //    the tree ends with -3
  //    e.g. using index set 0 1 2 3 4
  //    0 -1 -1 1 -2 -1 -1 -1 2 -2 -1 3 -2 -2 -1 4 -2 -2 -2
  //    is the tree with 5 pendants
  //    and two other splits
  //    0 1 | 2 3 4
  //    0 1 4 | 2 3
  //
  // max -- index set ranges from 0 to max-1
  // gd is storage for directed link graph
  //    gd[i*ngd to (i+1)*ngd-1] includes j if i contains j and includes -j if the complement of i contains j
  //    ngdi[i] is the number of elements stored in row i
  // g is storage for link graph g[i*ng+j] is 1 if i contains j, -1 if the complement of i contains j, and 0 otherwise
  //   ****** assumes g is initialize to zeros prior to input *********
  // ngd -- g is ngd x ngd array
  // ng is the number of distinct edges
  // ti array which stores indexed representations of trees
  //    0 to ne[0]-1 represents tree 0
  //    ne[0] to ne[0]+ne[1] represents tree 1 and so on
  // edge gte[i] in tree gt[i] is an example of edge for row i of g
  // ************************************************************************
  // ************************************************************************
  // variables
  // ************************************************************************
  // e and f index edges; take values between 0 and max-1
  // i and j index trees; take values from 0 to n-1
  // k counts the number of distinct edges
  // k0 stores the corrent number of distinct edges before the next tree is checked
  // ng0 is the total of the number of edges in each tree
  // val stores integer values for input or output of subroutines
  // found_edge 1 indicates duplicate edge found, 0 otherwise
  // max is the size of the index set
  // n is the number of trees
  // a array storing indicator version of an edge; 1 by max array.
  // b array storing indicator version of edge; 1 by max array.
  // st[i] is the starting index for the i'th tree in t
  // sti[i] is the starting index for the i'th tree in ti
  int e,f,i,j,k,k0,ng0,val,found_edge;
  int max,n;
  max=*max_in;
  n=*n_in;
  int *a,*b,*st,*sti;
  ng0=*ngd;
  a=Calloc(max,int); b=Calloc(max,int);
  st=Calloc(n,int); sti=Calloc(n,int);
  k=0;
  st[0]=0;
  for (i=1;i<n;i++) st[i]=st[i-1]+nt[i-1];
  sti[0]=0;
  for (i=1;i<n;i++) sti[i]=sti[i-1]+ne[i-1];

  for (e=0;e<ne[0];e++)
  {
    for (f=0;f<ne[0];f++)
    {
      g[e*ng0+f]=1;
      g[f*ng0+e]=1;
    }
    //gt[e]=0;
    //gte[e]=e;
    //ti[e]=k;
    k++;
  }
  for (i=1;i<n;i++)
  {
    k0=k;
    // compare each edge of tree i to all previous edges
    for (e=0;e<ne[i];e++)
    {
      found_edge=0;
      for (j=0;j<k0;j++)
      {
        convert_edge(t+st[i],max,e,a,1,nt[i]);
        convert_edge(t+st[gt[j]],max,gte[j],b,-1,nt[gt[j]]);
        compare_edges(a,b,max,&val);
        if (val==1)
        {
           g[j*ng0+k]=1;
           g[k*ng0+j]=1;
        }
        if (val==2)
        {
          found_edge=1;
          break;
        }
      }
      if (found_edge==1)
      {
        ti[sti[i]+e]=j;
        for (f=0;f<j;f++)
        {
           g[k*ng0+f]=0;
           g[f*ng0+k]=0;
        }
      }
      else
      {
      //  gt[k]=i;
      //  gte[k]=e;
      //  ti[sti[i]+e]=k;
        g[ng0*k+k]=1;
        k++;
      }
      if (k==ng0) break; //found all distinct edges
    }
    for (e=k0;e<k;e++)
    {
      for (f=k0;f<k;f++)
        {
           g[e*ng0+f]=1;
           g[f*ng0+e]=1;
        }
    }
  }
  Rcout<<k<<"\n";
  *ng=k;
  Free(a);Free(b);Free(st); Free(sti);
 }
}

void compare_edges(int* a, int* b, int n, int *v)
{
  // output:
  // v=0 incompatible
  // v=1 compatible (but not identical)
  // v=2 identical
  int i,sp,sm,s,sa,sb;
  sp=0;sm=0;sa=0;sb=0;
  // make sure that leaf 0 is treated as root
  if (a[0]!=0)
  {
    for (i=0;i<n;i++)
    {
      if (a[i]==0) a[i]=1;
      else a[i]=0;
    }
  }
  if (b[0]!=0)
  {
    for (i=0;i<n;i++)
    {
      if (b[i]==0) b[i]=-1;
      else b[i]=0;
    }
  }
  for (i=0;i<n;i++)
  {
    s=a[i]+b[i];
    if (s==1) sp++;
    if (s==-1) sm++;
    sa+=a[i];
    sb-=b[i];
  }
  *v=0;
  if (sp==sa && sm==sb) *v=1;
  if (sp==0) *v=1;
  if (sm==0) *v=1;
  if (sp==0 && sm==0) *v=2;
  if ((sp-sm)==n) *v=2;
}

// void compare_edges(int* a, int* b, int n, int *v)
// {
//   int i,sp,sm,s,sa,sb;
//   sp=0;sm=0;sa=0;sb=0;
//   for (i=0;i<n;i++)
//   {
//     s=a[i]+b[i];
//     if (s==1) sp++;
//     if (s==-1) sm++;
//     sa+=a[i];
//     sb-=b[i];
//   }
//   *v=0;
//   if (sp==0) *v=1;
//   if (sm==0) *v=1;
//   if (sp==0&&sm==0) *v=2;
//   if (sp==sa && sm==sb) *v=2;
// }


extern "C"{
  void convert_edge_in(int *tree, int *n, int *e, int *a, int *val, int *m)
  {
    convert_edge(tree,*n,*e,a,*val,*m);
  }
}

void convert_edge(int *tree, int n, int e, int *a, int val, int m)
{
  int j,c,sum;
  j=0;
  for (j=0;j<n;j++) a[j]=0;

  c=0; j=0;
  while (c<(e+1))
  {
    if (tree[j]==-1) c++;
    j++;
  }
  sum=-1;
  while (sum<0)
  {
    if (tree[j]==-1) sum--;
    if (tree[j]==-2) sum++;
    if (tree[j]>-1)
    {
      a[tree[j]]=val;
    }
    j++;
  }
}
