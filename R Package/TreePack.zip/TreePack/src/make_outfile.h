// make_outfile.h
#ifndef MAKE_OUTFILE_H
#define MAKE_OUTFILE_H

#include <stdlib.h>

// time
#include <ctime>

// in out
#include <fstream>
#include <iomanip>
#include <iostream>

// strings
#include <sstream>
#include<string>
using namespace std;
string make_outfile(string root);
string make_outfile_id(string root,int id);
#endif
