#include "phylo_fm.h"
#include "phylo_tree_geo.h"


// ********************************************************************
//  Frechet Descent methods
// ********************************************************************
void initialize(int k, int* t, double* l, int n, int* trn, int* tr, double* trl, int* g, int ng)
{
  int i,j,h,trs;
  for (j=0;j<k;j++) l[j]=0.0;
  trs=0;
  for (i=0;i<n;i++)
  {
    for (j=0;j<k;j++)
    {
      for (h=0;h<trn[i];h++)
      {
          if(t[j]==tr[h+trs]) l[j]+=trl[h+trs];
      }
    }
    trs=trs+trn[i];
  }
  for (j=0;j<k;j++) l[j]/=l[j]/n;
}
void steepest(int k, int* t, double* l, int n, int* trn, int* tr, double* trl, int* g, int ng, int m, double cr, int N, double del)
{
  // input
  // k size of tree where FSS will be evaluated
  // t tree where FSS will be evaluated
  // l length of edges in tree where FSS will be evaluated
  // n number of trees
  // trn number of edges in each tree
  // tr trees (represented by indexes of link)
  // trl length of edges in trees
  // g link graph
  // m maximum size of tree
  // ng size of link graph
  // cr cooling rate for step 0.0<cr<1.0 -- smaller values cool faster -- recommend cr>0.5
  // N maximum number of steps
  // del stop loop when norm of gradient is below del

  // no step length optimization -- just cool steps at rate cr

  //=======================================================================================

  //local variables
  int i,sm;
  double e,c,cmx;
  int *A,*B;
  double *gr;
  // initialize and allocate memory for local variables
  sm=0;A=Calloc(k*n,int);
  for(i=0;i<n;i++) sm+=trn[i];
  cmx=1.0;
  e=0.0;
  B=Calloc(sm,int);
  gr=Calloc(k,double);

  // main loop:
  // outline for each iteration: (1) update geodesic supports, (2) compute gradient, (3) step
  i=0;
  c=1.0;
  // compute gradient and norm before loop starts
  make_geo_supports(k,t,l,n,trn,tr,trl,g,ng,A,B);
  grad_v2(k,l,A,n,trn,trl,B,gr);
  abs_inner_prod(k,gr,l,&e);
  double c0=c;
  while (e>del && i<N)
  {
    boundary_step_length(k,gr,l,&cmx);
    if (c>=cmx) c=cr*cmx;
    step(k,gr,l,-1.0*c);
    make_geo_supports(k,t,l,n,trn,tr,trl,g,ng,A,B);
    for (int j=0;j<k;j++) gr[j]=0.0;
    grad_v2(k,l,A,n,trn,trl,B,gr);
    abs_inner_prod(k,gr,l,&e);
    c=c0/i;
    i++;
  }
  // free local variables
  Free(A);Free(B);Free(gr);
}

void steepest_v(int k, int* t, double* l, double *gr, int n, int* trn, int* tr, double* trl, int* g, int ng, int m, double cr, int N, double del)
{
  // input
  // k size of tree where FSS will be evaluated
  // t tree where FSS will be evaluated
  // l length of edges in tree where FSS will be evaluated
  // n number of trees
  // trn number of edges in each tree
  // tr trees (represented by indexes of link)
  // trl length of edges in trees
  // g link graph
  // m maximum size of tree
  // ng size of link graph
  // cr cooling rate for step 0.0<cr<1.0 -- smaller values cool faster -- recommend cr>0.5
  // N maximum number of steps
  // del stop loop when norm of gradient is below del

  // no step length optimization -- just cool steps at rate cr

  //=======================================================================================

  //local variables
  int i,sm,j;
  double e,*c,*cmx_v;
  int *A,*B;
  //double *gr;
  // initialize and allocate memory for local variables
  sm=0;
  e=0.0;
  for(i=0;i<n;i++) sm+=trn[i];
  A=Calloc(k*n,int); //for (i=0;i<(k*n);i++) A[i]=0;
  B=Calloc(sm,int); //for (i=0;i<sm;i++) B[i]=0;
  c=Calloc(k,double);
  cmx_v=Calloc(k,double);
  //gr=Calloc(k,double);
  //for (i=0;i<k;i++) gr[i]=0.0;
  //for (i=0;i<k;i++) c[i]=0.0;

  // main loop:
  // outline for each iteration: (1) update geodesic supports, (2) compute gradient, (3) step
  i=0;
  for (j=0;j<k;j++) c[j]=1.0;
  // compute gradient and norm before loop starts
  make_geo_supports(k,t,l,n,trn,tr,trl,g,ng,A,B);
  //double d=0.0;
  //void geo_dist(int* k1, int* k2, int* a, int *b, double *l1, double *l2, double *d);
  grad_v2(k,l,A,n,trn,trl,B,gr);
  abs_inner_prod(k,gr,l,&e);
  //max_min_abs(k,gr,l,&e);
  double c0=1.0;
  while (e>del && i<N)
  {
    boundary_step_length_v(k,gr,l,cmx_v);
    for (j=0;j<k;j++) if (c[j]>=cmx_v[j]) c[j]=cr*cmx_v[j];
    step_v(k,gr,l,c,-1.0);
    make_geo_supports(k,t,l,n,trn,tr,trl,g,ng,A,B);
    for (j=0;j<k;j++) gr[j]=0.0;
    grad_v2(k,l,A,n,trn,trl,B,gr);
    abs_inner_prod(k,gr,l,&e);
    for (j=0;j<k;j++) c[j]=c0/(i+1.0);
    i++;
  }

  // free local variables
  Free(A);Free(B);
  //Free(gr);
}

void damped_steepest_v(int k, int* t, double* l, double *gr, int n, int* trn, int* tr, double* trl, int* g, int ng, int m, double cr, int N, double del, double eps0)
{
  // input
  // k size of tree where FSS will be evaluated
  // t tree where FSS will be evaluated
  // l length of edges in tree where FSS will be evaluated
  // n number of trees
  // trn number of edges in each tree
  // tr trees (represented by indexes of link)
  // trl length of edges in trees
  // g link graph
  // m maximum size of tree
  // ng size of link graph
  // cr cooling rate for step 0.0<cr<1.0 -- smaller values cool faster -- recommend cr>0.5
  // N maximum number of steps
  // del stop loop when norm of gradient is below del
  // eps0 edges with length less than eps0 are removed from the tree

  // no step length optimization -- just cool steps at rate cr

  //=======================================================================================

  //local variables
  int i,sm,j;
  double e,*c,*cmx_v;
  int *A,*B;
  int xk, *x, *xmap, xj;
  double *xl, *xgr;
  //double *gr;
  // initialize and allocate memory for local variables
  sm=0;
  e=0.0;
  for(i=0;i<n;i++) sm+=trn[i];
  A=Calloc(k*n,int); //for (i=0;i<(k*n);i++) A[i]=0;
  B=Calloc(sm,int); //for (i=0;i<sm;i++) B[i]=0;
  c=Calloc(k,double);
  cmx_v=Calloc(k,double);
  x=Calloc(k,int);
  xl=Calloc(k,double);
  xgr=Calloc(k,double);
  xmap=Calloc(k,int);
  //gr=Calloc(k,double);
  //for (i=0;i<k;i++) gr[i]=0.0;
  //for (i=0;i<k;i++) c[i]=0.0;

  for (i=0;i<k;i++)
  {
    xl[i]=l[i];
    x[i]=t[i];
    xmap[i]=i;
  }
  xk=k;


  // main loop:
  // outline for each iteration: (1) update geodesic supports, (2) compute gradient, (3) step
  i=0;
  //for (j=0;j<k;j++) c[j]=1.0;
  for (j=0;j<k;j++) c[j]=0.5;
  // compute gradient and norm before loop starts
  make_geo_supports(xk,x,xl,n,trn,tr,trl,g,ng,A,B);
  //double d=0.0;
  //void geo_dist(int* k1, int* k2, int* a, int *b, double *l1, double *l2, double *d);
  grad_v2(xk,xl,A,n,trn,trl,B,xgr);
  abs_inner_prod(xk,xgr,xgr,&e);
  e=pow(e,0.5)/xk;
  //double c0=1.0;
  while (e>del && i<N)
  {
    boundary_step_length_v(xk,xgr,xl,cmx_v);
    for (j=0;j<k;j++) if (c[j]>=cmx_v[j]) c[j]=cr*cmx_v[j];
    step_v(xk,xgr,xl,c,-1.0);
    make_geo_supports(xk,x,xl,n,trn,tr,trl,g,ng,A,B);
    //int sm2=0;
    for (j=0;j<k;j++) xgr[j]=0.0;
    grad_v2(xk,xl,A,n,trn,trl,B,xgr);
    abs_inner_prod(xk,xgr,xgr,&e);
    e=pow(e,0.5)/xk;
    // transfer information from x to t
    for (j=0;j<xk;j++)
    {
      xj=xmap[j];
      l[xj]=xl[j];
      gr[xj]=xgr[j];
    }
    // move info for active edges from t into x
    xk=0;
    for (j=0;j<k;j++)
    {
      if (l[j]>=eps0 | gr[j]<0)
      {
        xmap[xk]=j;
        xl[xk]=l[j];
        x[xk]=t[j];
        xgr[xk]=gr[j];
        xk++;
      }
    }
    i++;
  }

  // free local variables
  Free(A);Free(B);
  //Free(gr);
  Free(x); Free(xl);
  Free(xgr);Free(xmap);
}


void test_1simplex(int m, double *u, double *v, double *a)
{
  // m = length of u and v
  // u vector s.t. sum(u)=1 and u[i]>=0 for i=0,...,m-1
  // v vector
  *a=0.0;
  int i;
  for (i=0;i<m;i++) *a=*a+(abs(v[i])*(u[i])*(1-u[i]));
}
void max_min_abs( int m, double *u, double *v, double *a)
{
  *a=0.0;
  int i;
  double b;
  for (i=0;i<m;i++)
  {
    b=abs(u[i]);
    if (b<abs(1-u[i])) b=abs(1-u[i]);
    if (b>abs(v[i])) b=abs(v[i]);
    if (*a<b) *a=b;
  }
}
void abs_inner_prod( int m, double *u, double *v, double *a)
{
  *a=0.0;
  int i;
  for (i=0;i<m;i++) *a=*a+(abs(u[i])*abs(v[i]));
}
void test_grad( int m, double *l, double *grad, double eps, double a)
{
  a=0.0;
  int i;
  for (i=0;i<m;i++)
  {
    if (l[i]>eps)
    {
      a+=abs(grad[i]);
    }
  }
}
void norm(int m, double *v, double nrm)
{
  nrm=0.0;
  int i;
  for (i=0;i<m;i++) nrm+=(v[i]*v[i]);
}

// void newton(int k, int *t, double *l, int n, int* trn, int* tr, double* trl, int* g, int ng, int m, double cr, int N, double del)
// {
//
//   // outline:
//   // 1. update supports
//   // 2. newton direction:
//   //      i. copy hessian and gradient to arma::mat and arma::vec
//   //      ii. pass these to newton_dir, convert newton direction from arma::vec to double *
//   // 3. step: keep l>=0
//   // 4. cool step length
//
//
//   // input
//   // k size of tree where FSS will be evaluated
//   // t tree where FSS will be evaluated
//   // l length of edges in tree where FSS will be evaluated
//   // n number of trees
//   // trn number of edges in each tree
//   // tr trees (represented by indexes of link)
//   // trl length of edges in trees
//   // g link graph
//   // m maximum size of tree
//   // ng size of link graph
//   // cr cooling rate for step 0.0<cr<1.0 -- smaller values cool faster -- recommend cr>0.5
//   // N maximum number of steps
//   // del step loop when norm of gradient is below del
//
//   // no step length optimization -- just cool steps at rate cr
//
//
//   //local variables
//   int i,sm;
//   double e,c,cmx;
//   int *A,*B;
//   double *gr, *h;
//   // initialize and allocate memory for local variables
//   sm=0;A=Calloc(k*n,int);
//   for(i=0;i<n;i++) sm+=trn[i];
//   cmx=0.0;
//   e=0.0;
//   B=Calloc(sm,int);
//   gr=Calloc(k,double);
//   h=Calloc(k*k,double);
//
//   arma::vec gr_arma(m), newt_dir(m);
//   arma::mat h_arma(m,m);
//
//   // main loop:
//   // outline for each iteration: (1) update geodesic supports, (2) compute gradient, (3) step
//   i=0;
//   c=1.0;
//   // compute gradient and norm before loop starts
//   make_geo_supports(k,t,l,n,trn,tr,trl,g,ng,A,B);
//   grad(k,l,A,n,trn,trl,B,gr);
//   abs_inner_prod(k,gr,l,&e);
//   while (e>del && i<N)
//   {
//     outfilestream<<"Newton step "<<i<<endl;
//     boundary_step_length(k,gr,l,&cmx);
//     if (c>cmx) c=cr*cmx;
//     step(k,gr,l,c);
//     make_geo_supports(k,t,l,n,trn,tr,trl,g,ng,A,B);
//     //grad_Rarma(k,l,A,n,trn,trl,B,gr_arma);
//     //hess_Rarma(k,l,A,n,trn,trl,B,h_arma);
//     newton_dir(gr_arma,h_arma,newt_dir);
//     abs_inner_prod(k,gr,l,&e);
//     c=cr*c;
//     i++;
//   }
//
//   // free local variables
//   Free(A);Free(B);Free(gr);Free(h);
//
// }


// [[Rcpp::export]]
bool newton_dir(arma::vec gr, arma::mat hs, arma::vec newt_dir)
{
  // gr gradient vector -- m entries (double)
  // hs hessian -- m*m entries (double)
  bool succes=arma::solve(newt_dir,hs,gr);
  return succes;
}

//void optimize_step_length()

void step(int k, double *d, double *l, double c)
{
  // input:
  // k number of edges
  // d vector of rates of change for edge lengths
  // l vector of edge lengths
  // c step length

  int i;
  for (i=0;i<k;i++) l[i]+=(c*d[i]);
}

void step_v(int k, double *d, double *l, double *c, double a)
{
  // input:
  // k number of edges
  // d vector of rates of change for edge lengths
  // l vector of edge lengths
  // c step length

  int i;
  for (i=0;i<k;i++) l[i]+=(a*c[i]*d[i]);
}

void boundary_step_length(int m, double *d, double *l, double *c)
{
  // input:
  // m number of edges in tree
  // d direction vector
  // l vector of edge lengths (non-negative)
  // c step length when first edge hits zero

  // local variables:
  // i iterates from 0 to m-1
  // r ratio of l[i]/d[i]
  // ======================================================================================
  // setup for print output
  int print_out=0;
  string outfile=make_outfile("boundary_step_length_");
  ofstream outfilestream;
  if (print_out)
  {
    outfilestream.open(outfile.c_str());
    outfilestream<<"output from TreePack boundary_step_length"<<endl;
  }
  //=======================================================================================

  int i;
  double r;
  *c=std::numeric_limits<double>::max();
  for (i=0;i<m;i++)
  {
    if (d[i]>0)
    {
      r=l[i]/d[i];
      if(print_out==1) {outfilestream<<"r["<<i<<"]="<<r<<endl;}
      if (*c>r) *c=r;
    }
  }
}

void boundary_step_length_v(int m, double *d, double *l, double *c)
{
  // input:
  // m number of edges in tree
  // d direction vector
  // l vector of edge lengths (non-negative)
  // c step length when first edge hits zero

  // local variables:
  // i iterates from 0 to m-1
  // r ratio of l[i]/d[i]
  int i;
  for (i=0;i<m;i++) c[i]=std::numeric_limits<double>::max();
  for (i=0;i<m;i++)
  {
    if (d[i]>0)
    {
      c[i]=l[i]/d[i];
    }
  }
}

// ********************************************************************
//  recursive tangent space stationary points
// ********************************************************************
void RTSSP()
{
  // 1. data structure to store recursive data points -- tree: index,parent,attributes
  //      maximum size of recursion tree? There cannot be more stationary points than nodes
  //                     in the full graph. Two points within 180 cannot both be stationary
  //                      stationary points cannot have compatible edges
  //                      -> tangent spaces of local stationary points are disjoint
  // 2. represent tangent space as subset of compatiblity graph
  // 3. find stationary points in tanget space (recursion)
  //    each phase of the recursion will apply greedyCliques() to the tangent spaces
  //    of the local stationary points in the current frontier
  //    this will create nested sequences of optimality conditions
  //    to prove that these stationary points are global minimizers of the
  //    directional derivative

}

void greedyCliques()
{
  // 1. operates in tangent space to a point represented by subset of link graph
  // 2. starts at each node and looks at neighbors
  // 3. find local stationary points (with respect to lagrangian)
  // 4. look in interior of orthants which have local stationary points on faces to build next
  //   generation of local stationary points

  // 5. halt condition
  //   L1 lagrangian halt condition:
  //   when all local stationary points are at least 180 degrees apart halt
  //    these will be correspond to global stationary points
  //    but there may be multivariate descent directions in their tangent spaces
  //    we will need to check these recursively with RTSSP()

  //   L2 lagrangian halt condition: ?
}


// ********************************************************************
//  Lagrangian Minimization
// ********************************************************************
void minL1()
{

}

void minL2()
{

}

// ********************************************************************
//  Inductive Mean
// ********************************************************************
extern "C"
{
  void inductive_mn(int *i0_in, int *m_in, int *k_in, int* sequence, int *n_in, int *trn,
                    int* tr, double* trl, int *t0, double *l0, int* k0,int *ng_in, int *g,
                    int *kk, int* tt, double* ll, int *kk1, int *tt1, double *ll1,
                    int *lastk, int* kkk, int* kki, int* ttk, double * llk, int *mx)
  {
    //=======================================================================================
    // input
    // -----
    // i0_in initial number of inductive mean steps
    // m_in maximum number of edges in a tree
    // k_in number of iterations for inductive mean algorithm
    // sequence is list of indexes for inductive mean steps
    // n_in number of trees
    // trn array of edges in each tree stored in tr
    // tr array storing the trees as indexes of link graph g
    // trl array of vector of edge lengths
    // t0 initial tree
    // l0 initial edge lengths
    // k0 number of edges in initial tree
    // ng_in size of link graph
    // g link graph
    // kk, tt, ll size and storage for iterative tree
    // kk1, tt1, ll1 size and storage for iterative tree and final tree
    // lastk, kkk, ttk, llk number of trees to store, size and storage
    // mx maximum number of edges possible

    //=======================================================================================
    // variables
    // ---------
    // i two uses
    //    (1) counter for inductive means
    //    (2) loops through trn to compute trs
    // j used to move tt and ll (storage for the next inductive mean tree)
    //          to t0 and l0 (the current inductive mean tree),
    //          and reset tt and ll to 0 and 0.0 arrays
    //
    // k number of inductive mean steps
    // m maximum edges in a tree
    // n number of trees
    // ng number of edges in link graph
    // a storage for support
    // b storage for support
    // lambda step length -- lambda=1.0/(i+2.0)
    // ck counts positiion in array to store last k trees

    //=======================================================================================
    // declare variables
    int i,j,k,l,m,n,ng,i0,ck;
    //int kk;
    int *a,*b;
    //int *tt;
    int *trs;
    double lambda;
    //double *ll;

    // ======================================================================================
    // setup for print output
    int print_out=0;
    string outfile=make_outfile("inductive_mn_");
    ofstream outfilestream;
    if (print_out)
    {
      outfilestream.open(outfile.c_str());
      outfilestream<<"output from TreePack inductive_mn"<<endl;
    }
    //=======================================================================================
    // move input values from pointer to value
    m=*m_in;// move info from pointer to local variable for maximum tree size, m
    i0=*i0_in;
    k=*k_in;
    n=*n_in;
    ng=*ng_in;

    //=======================================================================================
    // allocate memory for variables
    trs=Calloc(n,int);
    a=Calloc(m,int);
    b=Calloc(m,int);
    //tt=Calloc(m,int);
    //ll=Calloc(m,double);

    //=======================================================================================
    // initialize value for trs
    trs[0]=0;
    for (i=1;i<n;i++) trs[i]=trn[i-1]+trs[i-1];



    //=======================================================================================
    // inductive mean main loop

    if (print_out)
    {
      outfilestream<<"max tree size mx="<<*mx<<endl;
      outfilestream<<"initial tree: \n";
      for (j=0;j<*k0;j++) outfilestream<<t0[j]<<" ";
      outfilestream<<"\n";
      for (j=0;j<*k0;j++) outfilestream<<l0[j]<<" ";
      outfilestream<<"\n";
    }
    ck=0;
    *kk1=*k0;
    for (j=0;j<*kk1;j++) tt1[j]=t0[j];
    for (j=0;j<*kk1;j++) ll1[j]=l0[j];
    for (i=0;i<k;i++)
    {
      if (print_out) outfilestream<<"==============================================================\n";
      if (print_out) outfilestream<<"inductive mean iteration "<<i+1<<", max iter "<<k+i0<<"\n";
      l=sequence[i];
      lambda=1.0/(i0+i+2.0);
      // compute geodesic support from tt1 to tree l
      phylo_tree_geo(kk1,&trn[l],tt1,&tr[trs[l]],ll1,&trl[trs[l]],g,ng,a,b);
      // step along geodesic from tt1 to tree l
      geo_step_outfile(kk1,&trn[l],tt1,&tr[trs[l]],ll1,&trl[trs[l]],a,b,&lambda,tt,ll,kk,outfilestream);
      if (print_out)
      {
        outfilestream<<"length of tree 1="<<*kk1<<endl;
        outfilestream<<"tree 1 and support:\n";
        for (j=0;j<*kk1;j++) outfilestream<<t0[j]<<" ";
        outfilestream<<"\n";
        for (j=0;j<*kk1;j++) outfilestream<<a[j]<<" ";
        outfilestream<<"\n";

        outfilestream<<"length of tree 2="<<trn[l]<<endl;
        outfilestream<<"tree 2 and support:\n";
        for (j=0;j<trn[l];j++) outfilestream<<tr[trs[l]+j]<<" ";
        outfilestream<<"\n";
        for (j=0;j<trn[l];j++) outfilestream<<b[j]<<" ";
        outfilestream<<"\n";
      }
      // move tt and ll to t0 and l0, then set tt and ll to 0 and 0.0
      if (print_out)
      {
        outfilestream<<"kk="<<*kk<<endl;
      }
      *kk1=*kk;
      if ( (k+i0-i)<=*lastk)
      {
        kkk[ck]=*kk;
        kki[ck]=i+1;
        for(j=0;j<*kk;j++)
        {
          ttk[ck*(*mx)+j]=tt[j];
          llk[ck*(*mx)+j]=ll[j];
        }
        ck++;
      }
      for(j=0;j<*kk;j++)
      {
        tt1[j]=tt[j];
        ll1[j]=ll[j];
        tt[j]=0;
        ll[j]=0.0;
      }
      *kk=0;
      //*k0=kk;
     // memcpy(t0,tt,sizeof tt);

      if (print_out)
      {
        outfilestream<<"length of tree "<<i+2<<"="<<*kk1<<endl;
        outfilestream<<"tree "<<i+2<<": \n";
        for (j=0;j<*kk1;j++) outfilestream<<tt1[j]<<" ";
        outfilestream<<"\n";
        for (j=0;j<*kk1;j++) outfilestream<<ll1[j]<<" ";
        outfilestream<<"\n";
      }
    }
    if (print_out==1)
    {
      outfilestream<<"final tree: \n";
      for (j=0;j<*kk1;j++) outfilestream<<tt1[j]<<" ";
      outfilestream<<"\n";
      for (j=0;j<*kk1;j++) outfilestream<<ll1[j]<<" ";
      outfilestream<<"\n";
    }
    //=======================================================================================
    // free memory for variables
    Free(trs);
    Free(a); Free(b);
    //Free(tt); Free(ll);
  }
}

// ********************************************************************
//  Frechet Sum of Squares
// ********************************************************************

extern "C"{
void FSS_c(int* k_in, int* t, double* l, int* n_in, int* trn, int* tr, double* trl, int* g, int* ng_in, int* m_in, double* ss)
{
  // input
  // k_in size of tree where FSS will be evaluated
  // t tree where FSS will be evaluated
  // l length of edges in tree where FSS will be evaluated
  // n_in number of trees
  // trn number of edges in each tree
  // tr trees (represented by indexes of link)
  // trl length of edges in trees
  // g link graph
  // m_in maximum size of tree
  // ng_in size of link graph
  //

  // output
  // ss frechet sum of squares

  // variables
  // n number of trees (local version of n_in)
  // i iterates through 0 to n-1
  // s local variable which stores current value for frechet sum of squares during loop
  // d squared distance between two trees
  // st iterates over starting indexes of trees in tr
  //

  // declare variables
  int n, i, st;
  double d,s;
  int *a,*b;


  // move data to local variables
  n=*n_in;

  // allocate memory
  a=Calloc(*m_in,int);
  b=Calloc(*m_in,int);


  // main loop: compute distance from t to the i'th tree of tr
  st=0;
  s=0.0;
  for (i=0;i<n;i++)
  {
    //void geo_dist_in(int *k1, int *k2, int *t1, int *t2, double *l1, double *l2, int *g, int *n, int *a, int *b, double *d)
    geo_dist_in(k_in,&trn[i],t,&tr[st],l,&trl[st],g,ng_in,a,b,&d);
    s+=(d/n);
    st+=trn[i];
  }
  *ss=s;
  //Rcout<<setprecision (12)<< s <<endl;
  Free(a); Free(b);
}
}


// ********************************************************************
//  Frechet Differentials
// ********************************************************************
void make_geo_supports(int k, int *t, double *l, int n, int* trn, int* tr, double* trl, int *g, int ng, int* A, int* B)
{
  // output variables
  // A is array of length k*n which will store supports for geodesics from t to trees in tr
  // B is array of length sum(trn) which will store supports for geodesics from t to trees in tr

  // local variables
  // i iterates from 0 to n-1
  // st iterates over starting index of trees in tr
  int i, st;

  // main loop: make geodesic support between t and tree i
  st=0;
  for (i=0;i<n;i++)
  {
    //phylo_tree_geo(int *k1_in, int *k2_in, int *t1, int *t2, double *l1, double *l2, int *g, int n, int *a, int *b)
    phylo_tree_geo(&k,&trn[i],t,&tr[st],l,&trl[st],g,ng,&A[i*k],&B[st]);
    st+=trn[i];
  }
}

void grad(int k,double *l,int* A,int n,int* trn,double *trl,int* B,double *gr)
{
  // input variables
  // --- let t denote the tree where the gradient is evaluated
  // k number of edges in t
  // l lengths of edges in t
  // A vector of supports for geodesics from t to each tree in the forest
  // n number of trees in the forest
  // trn number of edges in each tree of the forest
  // trl lengths of edges in each tree of the forest
  // B vector of supports for geodesics from t to each tree in the forest
  //
  // output
  // gr is gradient at t (array of length at least k)


  // local variables
  // i iterates from 0 to n-1
  // j iterates from 0 to k-1
  // trs start position of trees in tr, and supports in B
  // tgr array which stores the gradient for one tree

  int i,j, trs;
  double *tgr;

  // allocate memory
  tgr=Calloc(k,double);

  // main loop: accumulate the contribution to the gradient from tree i
  trs=0;
  for (i=0;i<n;i++)
  {
    tree_grad(k,l,&A[i*k],trn[i],&trl[trs],&B[trs],tgr);
    for (j=0;j<k;j++)
    {
      gr[j]+=tgr[j];
    }
    trs+=trn[i];
  }
  for (j=0;j<k;j++) gr[j]/=n;
  Free(tgr);
}

void grad_Rarma(int k,double *l,int* A,int n,int* trn,double *trl,int* B, arma::vec gr)
{
  // input variables
  // --- let t denote the tree where the gradient is evaluated
  // k number of edges in t
  // l lengths of edges in t
  // A vector of supports for geodesics from t to each tree in the forest
  // n number of trees in the forest
  // trn number of edges in each tree of the forest
  // trl lengths of edges in each tree of the forest
  // B vector of supports for geodesics from t to each tree in the forest
  //
  // output
  // gr is gradient at t (array of length at least k)


  // local variables
  // i iterates from 0 to n-1
  // j iterates from 0 to k-1
  // trs start position of trees in tr, and supports in B
  // tgr array which stores the gradient for one tree

  int i,j, trs;
  double *tgr;

  // allocate memory
  tgr=Calloc(k,double);

  // main loop: accumulate the contribution to the gradient from tree i
  trs=0;
  for (i=0;i<n;i++)
  {
    tree_grad(k,l,&A[i*k],trn[i],&trl[trs],&B[trs],tgr);
    for (j=0;j<k;j++)
    {
      gr[j]+=tgr[j];
    }
    trs+=trn[i];
  }
  for (j=0;j<k;j++) gr[j]/=n;
  Free(tgr);
}

void grad_v2(int k,double *l,int* A,int n,int* trn,double *trl,int* B,double *gr)
{
  // input variables
  // --- let t denote the tree where the gradient is evaluated
  // k number of edges in t
  // l lengths of edges in t
  // A vector of supports for geodesics from t to each tree in the forest
  // n number of trees in the forest
  // trn number of edges in each tree of the forest
  // trl lengths of edges in each tree of the forest
  // B vector of supports for geodesics from t to each tree in the forest
  //
  // output
  // gr is gradient at t (array of length at least k)

  // local variables
  // i iterates from 0 to n-1
  // j iterates from 0 to k-1
  // trs start position of trees in tr, and supports in B
  // tgr array which stores the gradient for one tree

  // ======================================================================================
  // setup for print output
  int print_out=0;
  string outfile=make_outfile("grad_v2_");
  ofstream outfilestream;
  if (print_out)
  {
    outfilestream.open(outfile.c_str());
    outfilestream<<"output from TreePack grad_v2"<<endl;
  }
  //=======================================================================================


  int i,j, trs,m, j3;
  double *tgr;
  double *an, *bn;

  m=0;
  for (i=0;i<n;i++)
  {
    if (m<trn[i]) m=trn[i];
  }
  // allocate memory
  an=Calloc(k,double);
  bn=Calloc(m,double);
  int *t_comp, *t_inc;
  t_comp=Calloc(k,int);
  t_inc=Calloc(k,int);

  tgr=Calloc(k,double);

  // main loop: accumulate the contribution to the gradient from tree i
  trs=0;
  for (i=0;i<n;i++)
  {

    // compute the norms of each support sequence
    for (j=0;j<k;j++) an[j]=0.0;
    for (j=0;j<trn[i];j++) bn[j]=0.0;
    support_norms(k,trn[i],l,&trl[trs],&A[i*k],&B[trs],an,bn);
    // loop over edges
    for (j=0;j<k;j++)
    {
      j3=A[i*k+j];
      if (j3>=0)
      {
        //tgr[j]=l[j]*(1.0+pow(bn[j3],0.5)/pow(an[j3],0.5) );
        tgr[j]=l[j]+pow(bn[j3],0.5)*(l[j]/pow(an[j3],0.5) );
        t_inc[j]++;
      }
      else t_comp[j]++;
      if (A[i*k+j]==-1)
      {
        tgr[j]=l[j];
      }
      if (j3<-1)
      { // edge is present in tree
        tgr[j]=l[j]-trl[trs+abs( j3+2 )];
      }
    }
    for (j=0;j<k;j++)
    {
      gr[j]+=tgr[j];
    }
    trs+=trn[i];
  }
  for (j=0;j<k;j++) gr[j]/=n;
  if(print_out==1){
    outfilestream<<"t_inc: ";
    for (j=0;j<k;j++) outfilestream<<t_inc[j]<<" ";
    outfilestream<<"t_comp: ";
    for (j=0;j<k;j++) outfilestream<<t_comp[j]<<" ";
    outfilestream<<endl;
  }

  Free(tgr);
  Free(an); Free(bn);
  Free(t_inc); Free(t_comp);
}


void tree_grad(int k, double *l, int* a, int k1, double* l1, int* b, double* gr)
{
  // local variables
  // j iterates from 0 to k-1
  // an, bn vector of norms of supports
  int j;
  double *an, *bn;

  // allocate memory
  an=Calloc(k,double);
  bn=Calloc(k1,double);

  // compute the norms of each support sequence
  support_norms(k,k1,l,l1,a,b,an,bn);

  // loop over edges
  for (j=0;j<k;j++)
  {
    if (a[j]>=0)
    {
      gr[j]=l[j]*(1.0+pow(bn[a[j]],0.5)/pow(an[a[j]],0.5) );
    }
    if (a[j]==-1)
    {
      gr[j]=l[j];
    }
    if (a[j]<-1)
    { // edge is present in tree
      gr[j]=l[j]-l1[abs( a[j]+2 )];
    }
  }

  // free memory
  Free(an); Free(bn);
}

void hess(int k, double* l, int *A, int n, int *trn, double* trl, int* B, double* h)
{
  // local variables
  // i iterates from 0 to n-1
  // j, j1 iterate from 0 to k-1
  // trs iterates over start indexes of trees in trl and B
  // tree_h hessian for each tree
  int i, j, j1, trs;
  double* tree_h;

  // allocate memory
  tree_h=Calloc(k*k,double);

  trs=0;
  for(i=0;i<n;i++)
  {
    tree_hess(k,l,&A[i*k],trn[i],&trl[trs],&B[trs],tree_h);
    for (j=0;j<k;j++)
    {
      for (j1=0;j1<k;j1++) h[j*k+j1]+=tree_h[j*k+j1];
    }
    trs+=trn[i];
  }

  //free memory
  Free(tree_h);
}

void hess_Rarma(int k, double* l, int *A, int n, int *trn, double* trl, int* B, arma::mat h)
{
  // local variables
  // i iterates from 0 to n-1
  // j, j1 iterate from 0 to k-1
  // trs iterates over start indexes of trees in trl and B
  // tree_h hessian for each tree
  int i, j, j1, trs;
  double* tree_h;

  // allocate memory
  tree_h=Calloc(k*k,double);

  trs=0;
  for(i=0;i<n;i++)
  {
    tree_hess(k,l,&A[i*k],trn[i],&trl[trs],&B[trs],tree_h);
    for (j=0;j<k;j++)
    {
      for (j1=0;j1<k;j1++) h(j,j1)+=tree_h[j*k+j1];
    }
    trs+=trn[i];
  }

  //free memory
  Free(tree_h);
}

void tree_hess(int k, double* l, int* a, int k1, double* l1, int* b, double* h)
{
  // local variables
  int j,j1,m;
  double *an, *bn;

  // allocate memory
  an=Calloc(k,double);
  bn=Calloc(k1,double);

  // compute the norms of each support sequence
  support_norms(k,k1,l,l1,a,b,an,bn);
  for (j=0;j<k;j++) an[j]=pow(an[j],0.5);
  for (j=0;j<k1;j++) bn[j]=pow(bn[j],0.5);

  // main loop: compute hessian matrix
  for (j=0;j<k;j++)
  {
    for (j1=0;j1<k;j1++)
    {
      if (a[j]==a[j1])
      {
        m=a[j];
        if (a[j]>=0)
        {
          if (j==j1)
          {
            h[j*k+j1]=1+bn[m]/an[m]-l[j]*l[j]*bn[m]/pow(an[m],3.0);
          }
          else
          {
            h[j*k+j1]=-1*l[j]*l1[j1]*bn[m]/pow(an[m],3.0);
          }
        }
        else
        {
          h[j*k+j1]=1.0;
        }
      }
      else
      {
        h[j*k+j1]=0.0;
      }
    }
  }
  // free memory
  Free(an); Free(bn);
}

// ********************************************************************
//  Lagrangian Differentials
// ********************************************************************
void gradL1()
{

}

void hessL1()
{

}

void gradL2()
{

}

void hessL2()
{

}


// ********************************************************************
//  Directional Derivative and Differentials
// ********************************************************************

void make_geo_supports_normal(int k, int *t, double *l, int n, int* trn, int* tr, double* trl,
                              int *g, int ng,
                              int *active, int nactive, int level,int* kt, int* tra,
                              int *a1, int *b1, int *i1, int *i2, int* g0, int *g1, // storage for input to phylo_tree_geo_no_alloc
                              int *a, int *b, int *t1, int *t2, double *l1, double *l2, int *tt2, // storage for relevant edges
                              int* A, int* B, int* rB)
{
  // intput variables:
  // k = length of tree t
  // t = tree represented as indexes of compatibility graph g
  // l = length of edges in tree
  // n = number of trees in forest
  // trn = number of edges in each tree
  // tr = forest, where tr[start_i] to tr[end_i] represents tree i
  //       start_0=0 and end_0=trn[0]
  //       start_i= trn[0]+..+trn[i-1] and end_i = start_i+trn[i] for i>0
  // trl = lengths of edges in trees
  // g = link at the origin
  // ng = number of nodes in g
  // active= indicates which edges in tree, t are active in current level
  // nactive = number of active edges
  // level = current level in nested orthant optimization
  // kt = indicates level of edges in t
  // tra = indicates level where edge first becomes incompatible

  // input which is storage for output:
  // A = storage for supports, indexing t, for geodesics from tree, t to forest, tr
  // B = storage for supports, indexing t, for geodesics from tree, t to forest, tr

  // output variables
  // A is array of length k*n which will store supports for geodesics from t to trees in tr
  // B is array of length sum(trn) which will store supports for geodesics from t to trees in tr

  // local variables
  // i iterates from 0 to n-1
  // st iterates over starting index of trees in tr
  int i, st;
  int j,j0,j1;
  int k1, k2;
  int *t2_map;
  int t_max=0;
  for (i=0;i<n;i++) if (t_max<trn[i]) t_max=trn[i];
  t2_map=Calloc(t_max,int);
  //int tr_tot;
  //tr_tot=0; for (i=0;i<n;i++) tr_tot+=trn[i];
  // main loop: make geodesic support between t and tree i
  st=0;
  for (i=0;i<n;i++)
  {
    // 1. relevant edges: find edges in tree i which are incompatible with edge in this level,
    //                    but not previous level or equal to one of the edges in this level
    // 2. store subtrees of relevant edges in t1, t2, l1, l2
    // 2b. move info from last time support was calculated from A and B to a and b.
    // 3. compute support for relevant edges, storing results in a and b
    //    phylo_tree_geo(int *k1_in, int *k2_in, int *t1, int *t2, double *l1, double *l2, int *g, int n, int *a, int *b)
    //    phylo_tree_geo(&k,&trn[i],t,&tr[st],l,&trl[st],g,ng,&A[i*k],&B[st]);
    // 4. map support for relevant edges to A and B
    // 5.reset t1, t2, l1, l2, a and b

    //Rcout<<"tr[st:(trn[i]+st)]: ";
    //for (j1=st;j1<(st+trn[i]);j1++) Rcout<<tr[j1]<<" ";
    //Rcout<<endl;

    // 1-2. identify relevant edges and store subtrees of relevant edges
    k1=nactive;k2=0;
    for (j1=st;j1<(st+trn[i]);j1++) rB[j1]=0;
    for (j1=st;j1<(st+trn[i]);j1++)
    {
      if (tra[j1]==level)
      { // tr[j1] is relevant because it is incompatible at this level and not a previous level
        t2[k2]=tr[j1]; l2[k2]=trl[j1]; b[k2]=B[j1]; tt2[k2]=j1;
        t2_map[k2]=j1-st;
        k2++;
        rB[j1]=1;
      }
    }
    for (j=0;j<nactive;j++)
    {
      j0=active[j];
      t1[j]=t[j0]; l1[j]=l[j0]; a[j]=A[i*k+j0];
      for (j1=st;j1<(st+trn[i]);j1++)
      {
        if (tr[j1]==t[j0])
        {// tr[j1] is relevant becuase it is present in the active set
          t2[k2]=tr[j1]; l2[k2]=trl[j1]; b[k2]=B[j1]; tt2[k2]=j1;
          t2_map[k2]=j1-st;
          k2++;
          rB[j1]=1;
        }
      }
    }
    // 3. compute support for relevant edges, storing results in a and b
    //phylo_tree_geo_no_alloc(&k1,&k2,t1,t2,l1,l2,g,ng,a,b,g0,g1,i1,i2,a1,b1);
    //Rcout<<"k2="<<k2<<endl;
    phylo_tree_geo(&k1,&k2,t1,t2,l1,l2,g,ng,a,b);
    // 4.map support for relevant edges to A and B
    for (j=0;j<nactive;j++)
    {
      j0=active[j];
      if (a[j]<-1) A[j0+k*i]=-1*t2_map[abs(a[j]+2)]-2;
      else A[j0+k*i]=a[j];
    }
    for (j=0;j<k2;j++)
    {
      if (b[j]<-1)B[tt2[j]]=-1*active[abs(b[j]+2)]-2;
      else  B[tt2[j]]=b[j];
    }
    // move to next tree
    st+=trn[i];
  }
  Free(t2_map);
}

void DD(int k, double *p, int *A, int n, int* trn, double *trl, int *B, int m, double *der)
{
  // compute the directional derivative along a change vector p
  // -- explanation
  //    points x and y in the same vistal cell, s.t. x is a contraction of y
  //    p is the change vector y-x

  // input variables:
  // k size of p
  // p change vector along which to compute the directional derivative
  // A supports for geodesics from y to trees - A[0],..,A[k-1], for tree 0, A[i*k] to A[(i+1)*k-1] for tree i
  // n number of trees
  // trn size of trees -- size of trn is n
  // trl edge lengths of tree -- size is sum(trn)
  // B supports for geodseics from y to trees - B[0] to B[trn[0]-1] for tree 0, B[trn[0]] to B[trn[0]+trn[1]] for tree 1, ...
  // m maximum of trn

  // output variable:
  // der directional derivative along vector p



}
void gr_normalDD(int k, double *p, int *A, int n, int* trn, double *trl, int *B, int m, double* gr, int *rB)
{
  // compute the gradient of the directional derivative along a normal vector p
  // -- explanation
  //    points x and y in the same vistal cell, s.t. x is a contraction of y
  //    p is the component of the change vector y-x which is orthogonal to the orthant containing x
  // note: if the minimal orthant containing x is the same as the minimal orthant containing y
  //        then p=0

  // input variables:
  // k size of p
  // p change vector along which to compute the directional derivative
  // A supports for geodesics from y to trees - A[0],..,A[k-1], for tree 0, A[i*k] to A[(i+1)*k-1] for tree i
  // n number of trees
  // trn size of trees -- size is n
  // trl edge lengths of tree -- size is sum(trn)
  // B supports for geodseics from y to trees - B[0] to B[trn[0]-1] for tree 0, B[trn[0]] to B[trn[0]+trn[1]] for tree 1, ...
  // m maximum of trn

  // output variable:
  // gr gradient of the directional derivative along a normal vector p

  // local variables:
  // i index for trees, iterates from 0 to n-1
  // j index for p, iteraties from 0 to k-1
  // j2
  // nactive
  // active
  // an, bn
  // ======================================================================================
  // setup for print output
  int print_out=0;
  string outfile=make_outfile("gr_normalDD_");
  ofstream outfilestream;
  if (print_out)
  {
    outfilestream.open(outfile.c_str());
    outfilestream<<"output from TreePack gr_normalDD"<<endl;
  }
  //=======================================================================================
  if (print_out==1) outfilestream<<"declare local variables"<<endl;// declare local variables

  int i, j, j1, j2, nactive, tri, j3;
  int *active;
  int *t_comp, *t_inc;
  double *an, *bn;
  double *bl;

  if (print_out==1) outfilestream<<"allocate memory for local variables"<<endl;
  // allocate memory for local variables
  active=Calloc(k,int);
  an=Calloc(k,double);
  bn=Calloc(m,double);
  bl=Calloc(m,double);

  t_comp=Calloc(k,int);
  t_inc=Calloc(k,int);

  // set gr to 0.0
  if (print_out==1) outfilestream<<"initialize gr"<<endl;
  for (j=0;j<k;j++) gr[j]=0.0;

  // main procedure
  if (print_out==1) outfilestream<<"begin main procedure"<<endl;
  nactive=0;
  if (print_out==1) outfilestream<<"loop over edges"<<endl;
  for (j=0;j<k;j++)
  { // loop over edges
    if (p[j]>0) // only edges which have positive values in the normal component of the change vector
      // contribute to gradient of the directional derivative along a normal vector p
    {
      active[nactive]=j;
      nactive++;
    }
  }
  tri=0;
  if (print_out==1) outfilestream<<"loop over trees"<<endl;
  for (i=0;i<n;i++)
  { // loop over trees

    if (print_out==1) outfilestream<<"working on tree "<<i+1<<" out of "<<n<<endl;
    for (j=0;j<k;j++) an[j]=0.0;
    for (j=0;j<trn[i];j++) bn[j]=0.0;
    if (print_out==1) outfilestream<<"  call support norms"<<endl;
    if (print_out==1) outfilestream<<"k="<<k<<" trn[i]="<<trn[i]<<" m="<<m<<endl;
    if (print_out==1)
    {
      outfilestream<<"tri="<<tri<<endl;

      outfilestream<<"A: ";
      for (j=0;j<k;j++) outfilestream<<A[i*k+j]<<" ";
      outfilestream<<endl;

      outfilestream<<"B: ";
      for (j=0;j<trn[i];j++) outfilestream<<B[tri+j]<<" ";
      outfilestream<<endl;
    }
    for (j=0;j<m;j++) bl[j]=0.0;
    for (j=0;j<trn[i];j++)
    {
      j1=tri+j;
      if (print_out==1)
      {
        outfilestream<<"j1="<<j1<<endl;
        outfilestream<<"rB[j1]="<<rB[j1]<<endl;
        outfilestream<<"trl[j1]="<<trl[j1]<<endl;
      }
      if(rB[j1]==1) bl[j]=trl[j1];
    }
    support_norms(k,trn[i],p,bl,&A[i*k],&B[tri],an,bn);
    if (print_out==1) outfilestream<<"  done with support norms"<<endl;
    for (j=0;j<k;j++) an[j]=pow(an[j],0.5);
    for (j=0;j<trn[i];j++) bn[j]=pow(bn[j],0.5);
    if (print_out==1)
    {
      outfilestream<<"an: ";
      for (j=0;j<k;j++) outfilestream<<an[j]<<" ";
      outfilestream<<endl;
      outfilestream<<"bn: ";
      for (j=0;j<trn[i];j++) outfilestream<<bn[j]<<" ";
      outfilestream<<endl;
    }
    if (print_out==1) outfilestream<<"  aggregate contribution of edges"<<endl;
    for (j2=0;j2<nactive;j2++)
    {
      j=active[j2];
      j3=A[k*i+j];
      if (print_out==1)
      {
        outfilestream<<"j3="<<j3<<endl;
      }
      if (j3<-1)
      { // edge j is present in tree i
          //
          gr[j]-=trl[tri+abs(j3+2)];
          if (print_out==1)
          {
            outfilestream<<"tri+abs(j3+2)="<<tri+abs(j3+2)<<" trl[tri+abs(j3+2)]="<<trl[tri+abs(j3+2)]<<endl;
          }
      }
      else
      { // edge j is not compatible with tree i
        if (j3>=0)
        {
          gr[j]+=p[j]*bn[j3]/an[j3];
        }
      }
      if (print_out==1)
      {
        outfilestream<<"gr["<<j<<"]"<<gr[j]<<endl;
      }
      if (j3>=0) t_inc[j]++;
      else t_comp[j]++;
    }
    if (print_out==1) outfilestream<<"  done with aggregate contribution of incompatible edges"<<endl;
    tri+=trn[i];
  }
  if (print_out==1) outfilestream<<"done loop through trees"<<endl;
  for (j=0;j<k;j++) gr[j]/=n;

  if (print_out){ outfilestream<<"t_inc: ";
  for (j=0;j<k;j++) outfilestream<<t_inc[j]<<" ";
  outfilestream<<"t_comp: ";
  for (j=0;j<k;j++) outfilestream<<t_comp[j]<<" ";
  outfilestream<<endl;
  }
  // Free memory for local variables
  Free(active); Free(an); Free(bn); Free(bl);
  Free(t_comp); Free(t_inc);
}

void project_gr_to_simplex(int k, double *v, int nactive, int *active, double *pr)
{
  // k size of vectors v, active and pr
  // v vector to project
  // active indicates which coordinates are active in the simplex
  // pr storage for projection

  // projection onto simplex is the complement of the projection onto the normal vector of the simplex
  // 1. compute inner product of v and normal vector - which is just the average of v in the active variables
  // 2. scale by the norm of v
  // 3. use the result to scale the normal vector -- the scaled normal vector is the projection of v onto the normal vector
  // 4. subtract the projection onto the normal vector from v

  // declare local variables
  int j;
  double sm,sm2;
  // set pr to zero
  for (j=0;j<k;j++) pr[j]=0.0;
  // use pr to store the normal vector
  for (j=0;j<nactive;j++) pr[active[j]]=1.0;
  // compute the inner product of the normal vector and v -- which is just the sum of v in the active variables
  // and compute the inner product of v with itself
  sm=0.0;sm2=0.0;
  for (j=0;j<nactive;j++)
  {
    sm+=v[active[j]];
    sm2+=pr[active[j]]*pr[active[j]];
  }
  // divide the inner product of v and the normal with the squared norm of the normal
  sm=sm/sm2;
  // scale the normal vector by sm
  for (j=0;j<nactive;j++) pr[active[j]]*=sm;
  // subtract from v the projection of v onto the normal vector
  for (j=0;j<nactive;j++) pr[active[j]]=v[active[j]]-pr[active[j]];
}

void enter_values(double *v, int nactive, int *active, double *p)
{
  // declare local variables
  int j;
  for (j=0;j<nactive;j++) p[active[j]]=v[active[j]];
}

void diff_vector(double *v, double *u, int nactive, int *active, double *x)
{
  int j;
  for (j=0;j<nactive;j++){
    x[active[j]]=v[active[j]]-u[active[j]];
  }
}

void project_to_sphere(double *v, int nactive, int *active, double *p)
{
  // k size of vectors v, active and pr
  // v vector to project
  // active indicates which coordinates are active in the simplex
  // p storage for projection

  // declare local variables
  int j;
  double sm2;
  sm2=0.0;
  for (j=0;j<nactive;j++)
  {
    sm2+=v[active[j]]*v[active[j]];
  }
  sm2=sqrt(sm2);
  for (j=0;j<nactive;j++) p[active[j]]=v[active[j]]/sm2;
}

void scale_vector(double *v, int nactive, int *active, double c)
{
   int j;
  for (j=0;j<nactive;j++)
  {
    v[active[j]]*=c;
  }
}

// ===========================================
// min_normalDD without memory allocation

// // allocate memory for variables and compute m and sm:
// A=Calloc(nx*n,int);
// m=0; sm=0;
// for(i=0;i<n;i++)
// {
//   sm+=trn[i];
//   if (m<trn[i]) m=trn[i];
// }
// B=Calloc(sm,int);
// gr=Calloc(nx,double);
// p=Calloc(nx,double);
// pr=Calloc(nx,double);
// active=Calloc(nx,int);
// // free memory for variables:
// Free(A);Free(B);Free(gr); Free(pr); Free(p); Free(active);

void min_normalDD(int ng, int* g, int n, int *trn, int *tr, double *trl,
                  int nx, int *x, double *xl,
                  double eps, double del, int N, double cr,
                  int m, int *sm,
                  int *A, int *B, double *gr, double *p, double *pr,
                  int *active, int nactive, int *kx, int level, int *tra,
                  int *a1, int *b1, int *i1, int *i2, int* g0, int *g1, // storage for input to phylo_tree_geo_no_alloc
                  int *a, int *b, int *t1, int *t2, double *l1, double *l2, int *tt2,int id,  // storage for relevant edges
                  int norm)
{
  // In the input, edges in x are partitioned in to active and non-active
  // the active edges are optimized by this function, and the non-active edges are static
  //  -- active edges make up the normal space
  //  -- non-active edges make up the tangent space
  // this function
  // finds approximate minimizer of the directional derivative
  // along a direction in the normal space

  // input:
  // ng size of link graph g
  // g link graph
  // n number of trees
  // trn size of trees
  // tr indexes of link graph nodes defining tree topologies
  // trl length of edges in trees
  // nx number of edges in x -- point in search orthant
  // x indexes of link graph nodes defining tree topology
  // xl storage for output -- length of edges in x at equilibrium point
  // eps -- edges smaller than this are conisidered zero
  // del -- if norm of gradient is smaller than this halt
  // N -- maximum number of iterations
  // cr -- cooling rate
  // sm sum of trn -- total of size of trees
  // m maximum treesize in trn
  // A support pairs for x in geodesics from x to trees
  //       A[0],...,A[nx-1] gives the support pair indexes of edges of x in geodesic to tree 0
  //       A[nx],...,A[2*nx-1] gives the support pair indexes of edges of x in geodesic to tree 1
  // B support pairs for trees in geodesics from x to trees
  //      B[0],....,B[trn[0]-1] gives the support pair indexes of edges in tree 0
  //      B[trn[0]],....,B[trn[0]+trn[1]-1] gives the support pair indexes of edges in tree 1
  // gr storage for gradient vector
  // p difference vector (optimize this)
  // pr projection of gradient onto unit simplex
  // active which edges are active in x
  // nactive how many edges are active in x
  // kx level of edges in x
  // level current level
  // tra level where edge in tree in tr first becomes incompatible

  // output:
  // xl length of edges in x -- search point
  // ASSUMPTION: xl is initialized to a point with positive edges lengths for non-active edges

  // local variables:
  // i iterates through trees 0,...,n-1
  // j iterates through edges in x, takes values 0,...,nx-1
  // e stores the norm of the component of the gradient in the unit simplex
  // cmx step length to hit boundary of orthant
  // c controls maximum step proportion
  // ======================================================================================
  // setup for print output
  int print_out=0;
  string outfile=make_outfile_id("min_normalDD_",id);
  ofstream outfilestream;
  if (print_out==1)
  {
    outfilestream.open(outfile.c_str());
    outfilestream<<"output from TreePack min_normalDD"<<endl;
    outfilestream<<"using norm="<<norm<<endl;
  }
  //=======================================================================================
  // declare local variables
  int i,j;
  double c,cmx,e;
  int *rB;
  rB=Calloc(sm[n-1],int);
  if (print_out==1) outfilestream<<"sm[n-1]="<<sm[n-1]<<" and n="<<n<<endl;
  // intialize xl and p
  double rt=0.0;
  int use_rand=0;
  if (use_rand==1)
  {for (j=0;j<nactive;j++)
  {
    p[active[j]]=rand();
    rt+=p[active[j]];
  }
  for (j=0;j<nactive;j++)
  {
    p[active[j]]/=rt;
    xl[active[j]]=p[active[j]];
  }}
  else
  {  for (j=0;j<nactive;j++)
    {
      if (norm==2)
      {
        p[active[j]]=(double)1.0/sqrt(nactive);
        xl[active[j]]=(double)1.0/sqrt(nactive);
      }
      else
      {
        p[active[j]]=(double)1.0/nactive;
        xl[active[j]]=(double)1.0/nactive;
      }
    }
  }
  // main loop:
  // outline for each iteration: (1) update geodesic supports, (2) compute gradient,
  //                             (3) project gradient onto simplex
  //                             (4) step
  i=0; c=1.0;
  //double c0=c;
  // compute gradient, projection onto simplex and norm before loop starts
  //make_geo_supports(nx,x,xl,n,trn,tr,trl,g,ng,A,B);

  if (print_out==1)outfilestream<<"make geodesic supports"<<endl;
  make_geo_supports_normal(nx,x,xl,n,trn,tr,trl,g,ng,active,nactive,level,kx,tra,a1,b1,i1,i2,g0,g1,a,b,t1,t2,l1,l2,tt2,A,B,rB);

  if (print_out==1)outfilestream<<"call gr_normalDD"<<endl;
  gr_normalDD(nx,p,A,n,trn,trl,B,m,gr,rB);
  if (norm==2)
  {
    // make sure step doesn't leave orthant
    boundary_step_length(nx,gr,p,&cmx);
    if (print_out==1)outfilestream<<"cmx="<<cmx<<endl;
    //if (cmx<1.0) scale_vector(gr,nactive,active,cmx);
    step(nx,gr,p,-1.0*cmx*cr);
    project_to_sphere(p,nactive,active,p);
    diff_vector(xl,p,nactive,active,pr);
    enter_values(p,nactive,active,xl);
  }
  else project_gr_to_simplex(nx,gr,nactive,active,pr);
  double sm3=0.0;
  if (print_out==1)
  {for (j=0;j<nactive;j++) sm3+=pr[active[j]];
   outfilestream<<"sum of pr="<<sm3<<endl;
   sm3=0;
   for (j=0;j<nactive;j++) sm3+=p[active[j]];
   outfilestream<<"sum of p="<<sm3<<endl;
  }
  //abs_inner_prod(nx,pr,p,&e);
  //test_1simplex(nx,p,pr,&e);
  max_min_abs(nx,p,pr,&e);
  int k=nx;
  if (print_out==1){ for (int j=0;j<k;j++)
  {
    outfilestream<<"gr["<<j<<"]="<<gr[j];
    if (j<(k-1)) outfilestream<<",";
    else outfilestream<<endl;}
  }
  for (int j=0;j<k;j++)
  {
    if (print_out==1){outfilestream<<"pr["<<j<<"]="<<pr[j];
      if (j<(k-1)) outfilestream<<",";
      else outfilestream<<endl;}
  }
  if (print_out==1){ for (int j=0;j<k;j++)
  {
    outfilestream<<"p["<<j<<"]="<<p[j];
    if (j<(k-1)) outfilestream<<",";
    else outfilestream<<endl;}
  }

  if (print_out==1) outfilestream<<"e ="<<e<<endl;
  while ( (e>del) & (i<N))
  {
    if (print_out==1) outfilestream<<"min_normalDD step "<<i<<endl;
    if (print_out==1) outfilestream<<"e ="<<e<<endl;
    if (norm==2)
    {
    }
    else {
     boundary_step_length(nx,pr,p,&cmx);
      if (c>=cmx) c=cr*cmx;
      if (print_out==1) outfilestream<<"cmx ="<<cmx<<endl;
      if (print_out==1) outfilestream<<"c ="<<c<<endl;
      step(nx,pr,p,-1.0*c); // adjust change vector p
      step(nx,pr,xl,-1.0*c); // adjust tree x
    }
    //make_geo_supports(nx,x,xl,n,trn,tr,trl,g,ng,A,B);
    make_geo_supports_normal(nx,x,xl,n,trn,tr,trl,g,ng,active,nactive,level,kx,tra,a1,b1,i1,i2,g0,g1,a,b,t1,t2,l1,l2,tt2,A,B,rB);
    gr_normalDD(nx,p,A,n,trn,trl,B,m,gr,rB);
    if (print_out==1){ for (int j=0;j<k;j++)
    {
    outfilestream<<"gr["<<j<<"]="<<gr[j];
      if (j<(k-1)) outfilestream<<",";
      else outfilestream<<endl;}
    }

    if (norm==2)
    {
      // make sure step doesn't leave orthant
      boundary_step_length(nx,gr,p,&cmx);
      if (print_out==1)outfilestream<<"cmx="<<cmx<<endl;

      //if (cmx<1.0) scale_vector(gr,nactive,active,cmx);
      step(nx,gr,p,-1.0*cmx*cr);
      project_to_sphere(p,nactive,active,p);
      diff_vector(xl,p,nactive,active,pr);
      enter_values(p,nactive,active,xl);
    }
    else project_gr_to_simplex(nx,gr,nactive,active,pr);
    if (print_out==1)
    {sm3=0;
      for (j=0;j<nactive;j++) sm3+=pr[active[j]];
      outfilestream<<"sum of pr="<<sm3<<endl;
      sm3=0;
      for (j=0;j<nactive;j++) sm3+=p[active[j]];
      outfilestream<<"sum of p="<<sm3<<endl;
    }
    for (int j=0;j<k;j++)
    {
      if (print_out==1){outfilestream<<"pr["<<j<<"]="<<pr[j];
      if (j<(k-1)) outfilestream<<",";
      else outfilestream<<endl;}
    }
    if (print_out==1){ for (int j=0;j<k;j++)
    {
      outfilestream<<"p["<<j<<"]="<<p[j];
      if (j<(k-1)) outfilestream<<",";
      else outfilestream<<endl;}
    }
    //abs_inner_prod(nx,pr,p,&e);
    //test_1simplex(nx,p,pr,&e);
    max_min_abs(nx,p,pr,&e);
    //c=c0/i;
    i++;
  }
  Free(rB);
}

// ********************************************************************
//  Verify Nested Optimality Conditions
// ********************************************************************
void round_edges_to_zero(int k, double *l, double eps, int* nactive, int *active)
{
  // ======================================================================================
  // setup for print output
  int print_out=0;
  string outfile=make_outfile("round_edges_to_zero_");
  ofstream outfilestream;
  if (print_out)
  {
    outfilestream.open(outfile.c_str());
    outfilestream<<"output from TreePack round_edges_to_zero"<<endl;
  }
  //=======================================================================================
  if (print_out){outfilestream<<"round edges to zero:"<<endl;
  outfilestream<<"k="<<k<<endl;}
  int i,nnactive=0;
  *nactive=0;
  for (i=0;i<k;i++)
  {
    if (print_out){ outfilestream<<"edge "<<i<<" l="<<l[i]<<" eps="<<eps;}
    if (l[i]<eps)
    {
      if (print_out){ outfilestream<<"l[i]<eps";}
      active[*nactive]=i;
      *nactive=*nactive+1;
    }
    else
    {
      if (print_out){ outfilestream<<"l[i]>=eps";
      outfilestream<<"k-nnactive-1="<<k-nnactive-1<<endl;}
      active[k-nnactive-1]=i;
      nnactive++;
    }
    if (print_out){outfilestream<<endl;
    outfilestream<<"nactive="<<*nactive<<endl;}
  }
  if (print_out)outfilestream<<"nactive="<<*nactive<<endl;
}

void round_edges_with_pos_grad_to_zero(int k, double *l, double *gr, double eps, int* nactive, int *active)
{
  // ======================================================================================
  // setup for print output
  int print_out=0;
  string outfile=make_outfile("round_edges_to_zero_");
  ofstream outfilestream;
  if (print_out)
  {
    outfilestream.open(outfile.c_str());
    outfilestream<<"output from TreePack round_edges_to_zero"<<endl;
  }
  //=======================================================================================
  if (print_out){outfilestream<<"round edges to zero:"<<endl;
    outfilestream<<"k="<<k<<endl;}
  int i,nnactive=0;
  *nactive=0;
  for (i=0;i<k;i++)
  {
    if (print_out){ outfilestream<<"edge "<<i<<" l="<<l[i]<<" eps="<<eps;}
    if (l[i]<eps & gr[i]>0)
    {
      if (print_out){ outfilestream<<"l[i]<eps & gr[i]>0)";}
      active[*nactive]=i;
      *nactive=*nactive+1;
    }
    else
    {
      if (print_out){ outfilestream<<"l[i]>=eps |  & gr[i]<=0)";
        outfilestream<<"k-nnactive-1="<<k-nnactive-1<<endl;}
      active[k-nnactive-1]=i;
      nnactive++;
    }
    if (print_out){outfilestream<<endl;
      outfilestream<<"nactive="<<*nactive<<endl;}
  }
  if (print_out)outfilestream<<"nactive="<<*nactive<<endl;
}

int combine_levels(int i, int nx, int* kx, int *k, double *eps, double *alpha, double cr,
                   int *active, int nactive, double *p,double dd, double *xl,
                   int* tra,int n, int* trn)
{
  if (i<1) return -1;
  // combines level i and level i-1
  int j,tr_tot;
  double np2;
  // compute optimal step length from level i-1 along
  // direction vector at level i
  // compute optimal step length alpha
  np2=0; for (j=0;j<nactive;j++) np2+=(p[active[j]]*p[active[j]]);
  //(*alpha)=dd/np2;
  (*alpha)=-1*dd;
  // step along p
  Rcout<<(*alpha)<<endl;
  for (j=0;j<nactive;j++) xl[active[j]]=p[active[j]]*(*alpha);
  Rcout<<"xl: ";
  for (j=0;j<nactive;j++) Rcout<<xl[active[j]]<<" ";
  Rcout<<endl;

  Rcout<<"p*alpha: ";
  for (j=0;j<nactive;j++) Rcout<<p[active[j]]*(*alpha)<<" ";
  Rcout<<endl;
  for (j=0;j<nactive;j++) Rcout<<p[active[j]]*(*alpha)<<" ";
  //use alpha and cr to calculate eps[i-1]
  eps[i-1]=cr*(*alpha);
  for (j=(*k)-1;j>i;j--) eps[j-1]=eps[j];
  // update tra
  tr_tot=0; for (j=0;j<n;j++) tr_tot+=trn[j];
  for (j=0;j<n;j++) if (tra[j]>=i) tra[j]--;
  // update level indexes
  for (j=0;j<nx;j++) if (kx[j]>=i) kx[j]--;
  (*k)--;
  return 0;
}


void new_level(int i, int *k, int nx, int *x, int* kx, int nactive, int *active, double *eps,
               int* tra,int* g, int ng, int n, int* trn, int* tr, int *lev_i)
{
  // ======================================================================================
  // setup for print output
  int print_out=0;
  string outfile=make_outfile("new_level_");
  ofstream outfilestream;
  if (print_out)
  {
    outfilestream.open(outfile.c_str());
    outfilestream<<"output from TreePack new_level"<<endl;
  }
  //=======================================================================================

  // creates a new level above i
  // levels above i are moved up then
  // the componeent in level i is split by moving active edges into level i+1
  if (print_out){outfilestream<<"update kx and eps"<<endl;}
  int j,j0,j1,n_lev_i,tr_tot;
  for (j=0;j<nx;j++) if (kx[j]>i) kx[j]++;
  for (j=0;j<nactive;j++) kx[active[j]]++;
  for (j=(*k+1);j>i;j--) eps[j]=eps[j-1];
  (*k)++;
  // **********************************
  // update tra
  // **********************************
  if (print_out){outfilestream<<"update tra"<<endl;}
  // find edges in level i
  n_lev_i=0;
  for (j=0;j<nx;j++)
  {
    if (kx[j]==i)
    {
      lev_i[n_lev_i]=j;
      n_lev_i++;
    }
  }
  //
  tr_tot=0; for (j=0;j<n;j++) tr_tot+=trn[j];
  for (j=0;j<tr_tot;j++)
  {
    if (tra[j]>i) tra[j]++;
    else
    {
      if (tra[j]==i)
      {
        // loop through edges in level i, if all are compatible then tra[j]=i+1, otherwise set tra[j]=i
        tra[j]=i+1;
        for (j0=0;j0<n_lev_i;j0++)
        {
          j1=lev_i[j0];
          if (g[x[j1]*ng+tr[j]]==0)
          {
            tra[j]=i;
            break;
          }
        }
      }
    }
  }
  // *************************************
  // end update tra
  // *************************************
}


void normalDD(int k, double *p, int *A, int n, int* trn, double *trl, int *B, int m, double* dd, int nactive, int *active, int level, int *tra)
{
  // compute directional derivative along a normal vector p
  // -- explanation
  //    points x and y in the same vistal cell, s.t. x is a contraction of y
  //    p is the component of the change vector y-x which is orthogonal to the orthant containing x
  // note: if the minimal orthant containing x is the same as the minimal orthant containing y
  //        then p=0

  // input variables:
  // k size of p
  // p change vector along which the directional derivative will be evaluated
  // A supports for geodesics from y to trees - A[0],..,A[k-1], for tree 0, A[i*k] to A[(i+1)*k-1] for tree i
  // n number of trees
  // trn size of trees -- size is n
  // trl edge lengths of tree -- size is sum(trn)
  // B supports for geodseics from y to trees - B[0] to B[trn[0]-1] for tree 0, B[trn[0]] to B[trn[0]+trn[1]] for tree 1, ...
  // m maximum of trn

  // output variable:
  // dd directional derivative along a normal vector p

  // local variables:
  // i index for trees, iterates from 0 to n-1
  // j index for p, iteraties from 0 to k-1
  // j2
  // nactive
  // active
  // an, bn


  //=======================================================================================
  // declare local variables
  int i, j, j2, tri, j3;
  double *an, *bn;
  int nactiveB, *activeB;
  // allocate memory for local variables
  activeB=Calloc(m,int);
  an=Calloc(k,double);
  bn=Calloc(m,double);
  int *t_comp, *t_inc;
  t_comp=Calloc(k,int);
  t_inc=Calloc(k,int);
  // set dd to 0.0
  *dd=0.0;

  // main procedure
  tri=0;
  int max_support;
  for (i=0;i<n;i++)
  { // loop over trees
    max_support=-1;
    for (j=0;j<k;j++) an[j]=0.0;
    for (j=0;j<trn[i];j++) bn[j]=0.0;
    nactiveB=0;
    for (j=0;j<trn[i];j++)
    {
      if (tra[j+tri]==level)
      {
        activeB[nactiveB]=j;
        nactiveB++;
      }
    }
    support_norms_restricted(k,trn[i],p,&trl[tri],&A[i*k],&B[tri],an,bn,active,activeB,nactive,nactiveB);
    for (j=0;j<k;j++) an[j]=pow(an[j],0.5);
    for (j=0;j<trn[i];j++) bn[j]=pow(bn[j],0.5);
    for (j2=0;j2<nactive;j2++)
    {
      j=active[j2];
      j3=A[k*i+j];
      if (j3<-1)
      { // edge j is present in tree i
        //
        //gr[j]-=trl[abs(j3+2)];
        (*dd)-=trl[tri+abs(j3+2)]*p[j];
      }
      else
      { // edge j is not compatible with tree i
        if (j3>=0)
        {
          //gr[j]+=p[j]*bn[j3]/an[j3];
          if (max_support<j3) max_support=j3;
        }
      }
      if (j3>=0) t_inc[j]++;
      else t_comp[j]++;
    }
    for (j=0;j<=max_support;j++)
    {
      (*dd)+=an[j]*bn[j];
    }
    tri+=trn[i];
  }
  (*dd)/=n;
  // Free memory for local variables
  Free(activeB); Free(an); Free(bn);
  Free(t_comp); Free(t_inc);
}

// int compute_normalDD_tree(int nx, double* lx, int nt, double *lt ,int *a, int *b, int nactive, int *active, int *nna, int *nnb, double *tdd)
// {
//   // 1. loop through support to identify maximum support pair index
//   //    with an empty support
//   // 2. loop through support to accumulate contributions from supports and incompatible edges
//
//   int i,j,spmx;
//   spmx=nx;
//   for (i=nactive;i<nx;i++) // active[i] i>nactive are indexes of non-active edges
//   {
//     j=active[i];
//     if (spmx>a[j]) spmx=a[j];
//   }
//   if (spmx==0) // there are no support pairs which only contain active edges
//   {
//     *tdd=0; // set dd to 0
//     return 0; // return
//   }
//   // compute contribution from each support pair
//   for (i=0;i<spmx;i++){nna[i]=0.0;nnb[i]=0.0;} // initialize storage for norms of each support pair
//   // loop through edges
//   //  -- incompatible edges-- add their contribution to their support pair
//   //  -- compatible edges -- add contribution directly to tdd
//   (*tdd)=0.0;
//   for (i=0;i<nactive;i++)
//   {
//     j=active[i];
//     if (a[j]<spmx) // check if support contains only active edges or compatible
//     {
//       if (a[j]>=0) nna[a[j]]+=(lx[j]*lx[j]);
//       else
//       { // check if edge is present in tree
//         if (a[j]<-1) (*tdd)-=(lx[j]*lt[abs(a[j]+2)]);
//       }
//     }
//   }
//   for (i=0;i<nt;i++)
//   {
//     if (b[i]>=0&&b[i]<spmx)
//     {
//       nnb[b[i]]+=(lt[j]*lt[j]);
//     }
//   }
//   // add norms of support pairs
//   for (i=0;i<spmx;i++) (*tdd)+=(sqrt(nna[i])*sqrt(nnb[i]));
//   return 0;
// }
// void compute_normalDD(int nx,int *ox,int n,int *trn,double* trl,int m,int sm,
//                       int *A, int *B, double *y, int nactive, int* active,double* dd)
// {
//   // input variables:
//   // ox vector of indexes defining the orthant which will be the domain of the optimization
//   // nx size of ox, the size used, which must be less than or equal to the size allocated for ox, xl and x0
//   // n number of trees
//   // trn number of edges in each tree
//   // tr trees (represented by indexes of link)
//   // trl length of edges in trees
//   // m maximum size of tree
//   // sm cumulative sum of number of edges in trees trn
//   // A support pairs for geodesics from trees in tr and trl to variable point of maximum size m
//   //   stores support pairs for trees in tr and trl
//   // B support pairs for geodesics from trees in tr and trl to variable point of maximum size m
//   //   stores support pairs of variable point
//   // y point at which supports are computed
//   // nactive number of active edges in change vector
//   // active indexes of active edges in change vector
//
//   // IMPORTANT ASSUMPTIONS:
//   // 1.    the change vector p[j]=y[active[j]]
//   //     since y-y0 is normal to the orthant containing y0
//   // 2. the supports are valid
//
//
//   // 1. identify support pairs which only contain active edges; these will be at the beginning of the support sequence
//   // 2. identify compatible edges which are active
//
//   // incompatible edges
//
//   // compatible edges
//
// }

void init_tra(int *x, int nx, int n, int* trn, int *tr, int *g, int ng, int* tra)
{
  int i,j,k,st;
  // if edge in tr is compatible in x set tra to -1
  // if edge in tr is not compatible in x set tra to 0
  st=0;
  for (i=0;i<n;i++)
  {
    for (j=st;j<(st+trn[i]);j++)
    {
      tra[j]=-1;
      for (k=0;k<nx;k++)
      {
        if (g[x[k]*ng+tr[j]]==0)
        {
          tra[j]=0;
          break;
        }
      }
    }
    st+=trn[i];
  }
}

int compute_normal_vector(int nactive,int *active,int nx,double *xl,double *p)
{
  int i;
  for (i=0;i<nx;i++) p[i]=0.0;
  for (i=0;i<nactive;i++) p[active[i]]=xl[active[i]];
  return 0;
}



int orthantOpt(int ng, int* g, int nx, int *ox, double *xl, int n, int* trn,
                  int* tr, double* trl, int *tra,
                  int m, double eps0,  double del,
                  int *k, int* kx, double *x0,
                  int *sm, int* A, int* B, int *active, double *p, double *gr, double *pr, double *eps,
                  int *a1, int *b1, int *i1, int *i2, int* g0, int *g1, // storage for input to phylo_tree_geo_no_alloc
                  int *a, int *b, int *t1, int *t2, double *l1, double *l2, int *tt2, int *lev_i, // storage for relevant edges
                  int norm, int *tkn, int *tk, int* gt, int* gte)
{
  // Implementation of algorithm in Relative Optimality Conditions for Treespace Frechet means Section 5.2

  // input description:
  // link graph
  // orthant defined by clique in link graph
  // trees defined by (1) topology and (2) edge lengths
  //        topology is given as a vector indexing nodes in the link graph
  //        edges lengths are given by a vector of non-negative real numbers
  //
  // output description:
  // optimal edge lengths
  // decomposition of edges given by (1) the number of nested sets, k, and (2) an index vector
  //              indicating the level in the nested decomposition
  //
  // input variables:
  // g link graph
  // ng size of link graph
  // ox vector of indexes defining the orthant which will be the domain of the optimization
  // nx size of ox, the size used, which must be less than or equal to the size allocated for ox, xl and x0
  // n number of trees
  // trn number of edges in each tree
  // tr trees (represented by indexes of link)
  // tra indicates level where edge in trees in tr first become incompatible
  // trl length of edges in trees
  // m maximum size of tree
  // eps0 threshold to round edge length to zero during descent
  // del halt descent when norm of gradient is less than del
  // sm cumulative sum of number of edges in trees trn
  // A storage for support pairs for geodesics from trees in tr and trl to variable point of maximum size m
  //   stores support pairs for trees in tr and trl
  // B storage for support pairs for geodesics from trees in tr and trl to variable point of maximum size m
  //   stores support pairs of variable point
  // active storage for active edges in search point - active edges are points which can change at current level i
  // p storage for change vector at level i
  // gr storage for gradient of FSS or gradient of directional derivative of FSS
  // pr storage projection of gradient of dd onto unit simplex
  // eps storage for epsilon-zero at level i - adapts after nested optimization

  // output variables:
  // k number of levels in nested optimality conditions
  // kx index indicating level of each edge in ox
  // xl length of edges in optimal point
  //  *** NOTE *** IMPORTANT ASSUMPTION -- xl is initialized
  // can use initialize(nx, ox, xl, n, trn, tr, trl, g, ng);
  // x0 length of edges for minimizing directions

  // outline of algorithm:
  // 1. initialize k,kx and x0
  // 2. run descent until edge lengths stabilize or decrease towards zero
  // 3. once edges get sufficiently close to zero round to zero
  //    and create nested optimization -- search
  //    for minimizing directional derivative and continue with step 2
  // 4. if minimum directional derivative is negative then increase edge lengths
  //     from lower dimensional point along minimizing direction
  //     until gradient becomes zero
  //


  // local variables
  // i,j,j0 iterators
  // i keeps track of the current level
  // j iterates through edges in x
  // active[j] is 1 if variable j in search tree is in current level
  // nactive is number of variables active in current level
  // alpha storage for optimal step length

  //=======================================================================================

  // declare local variables
  int i,j;
  //int j0;
  //int c;
  int nactive;
  double dd,alpha;
  int N=20; double cr=0.6;
  int N0=100;
  //int kk;

  // initialize variables
  i=0;(*k)=0;eps[0]=eps0;
  for (j=0;j<nx;j++)
  {
     kx[j]=0;
     x0[j]=0.0;
     gr[j]=0.0;
     pr[j]=0.0;
     p[j]=0.0;
  }
  // initialize tra
  init_tra(ox,nx,n,trn,tr,g,ng,tra);
  // run approximate minimization on xl, if necessary round some edges to zero
  damped_steepest_v(nx, ox, xl, gr, n, trn, tr, trl, g, ng, m, cr, N0, del, eps0);
  nactive=0;
  round_edges_to_zero(nx,xl,eps0,&nactive,active);
  i=0;
  // if some edges are rounded to zero then enter recursive loop
   if (nactive>0)
   {
    // prepare for main loop
    new_level(i,k,nx,ox,kx,nactive,active,eps,tra,g,ng,n,trn,tr,lev_i); i++;
    int counter=0;
    int NN=20;
    for (j=0;j<nx;j++) gr[j]=0.0;
    while (i>=1 && i<NN)
    {
      counter++;
      min_normalDD(ng,g,n,trn,tr,trl,nx,ox,xl,eps[i],del,N,cr,m,sm,A,B,gr,p,pr,active,nactive,kx,i,tra,a1,b1,i1,i2,g0,g1,a,b,t1,t2,l1,l2,tt2,counter,norm);
      compute_normal_vector(nactive,active,nx,xl,p);
      normalDD(nx,p,A,n,trn,trl,B,m,&dd,nactive,active,i,tra);
      round_edges_to_zero(nx,xl,eps[i],&nactive,active);
      if (nactive>0) // some zero length edges
      {
        new_level(i,k,nx,ox,kx,nactive,active,eps,tra,g,ng,n,trn,tr,lev_i);
        i++;
      }
      else // no zero length edges
      {
        // compute normal DD
        if (dd<0) {
          combine_levels(i,nx,kx,k,eps,&alpha,cr,active,nactive,p,dd,xl,tra,n,trn);
          }
        i--;
      }
      // switch edges in current level to active
      nactive=0;
      for (j=0;j<nx;++j)
      {
        if (kx[j]==i)
        {
          active[nactive++]=j;
        }
      }
    }
  }
  return(0);
}



extern "C"{
void  orthantOpt_in(int* ng, int* g, int *nx, int *ox, double *xl, int *n, int* trn,
                int* tr, double* trl, int *tra,
                int *m, double *eps0,  double *del,
                int *k, int* kx, double *x0,
                int *sm, int* A, int* B, int *active, double *p, double *gr, double *pr, double *eps,
                int *a1, int *b1, int *i1, int *i2, int* g0, int *g1, // storage for input to phylo_tree_geo_no_alloc
                int *a, int *b, int *t1, int *t2, double *l1, double *l2, int *tt2, int *lev_i, // storage for relevant edges
                int *norm, int *tkn, int *tk,int* gt, int* gte)
  {
    orthantOpt(*ng,g,*nx,ox,xl,*n,trn,
               tr,trl,tra,
               *m,*eps0,*del,
               k,kx,x0,
               sm,A,B,active,p,gr,pr,eps,
               a1,b1,i1,i2,g0,g1,
               a,b,t1,t2,l1,l2,tt2,lev_i,*norm,
               tkn,tk,gt,gte);
  Rcout<<"OrthantOpt complete!"<<endl;
  }
}
