// maxflow.c

#include "maxflow.h"

// implement "hot start"
//void min_weight_cover_HS(int n1, int n2, int *g, int *gg1, int *gn1, int *gg2, int *gn2, double *u1, double *u2, double *x, double *x1, double* x2, int *c1, int *c2, int *nc1, int *nc2)

extern "C"{
  void min_weight_cover_in(int *n1_in, int *n2_in, int *g, int *gg1, int *gn1, int *gg2, int *gn2, double *u1, double *u2, double *x, double *x1, double* x2, int *c1, int *c2, int *nc1, int *nc2)
  {
    min_weight_cover(n1_in,n2_in,g, gg1, gn1, gg2, gn2,u1, u2, x, x1, x2,c1, c2, nc1, nc2);
  }
}

void min_weight_cover(int *n1_in, int *n2_in, int *g, int *gg1, int *gn1, int *gg2, int *gn2, double *u1, double *u2, double *x, double *x1, double* x2, int *c1, int *c2, int *nc1, int *nc2)
{

    // *******************************************************************************
    // Input descriptions
    // *******************************************************************************
    // g is an n1 x n2 array
    //
    //        g represents a bipartite graph:
    //        the graph has two partitions P1 and P2 with n1 and n2 elements, respectively
    //        let i index an element of P1, and j index an element of P2
    //        entry g[i*n2+j] is 1 if there is a connection between i and j,
    //                           0 otherwise
    //  gg1 is an n1 x n2 array
    //       gg1[0 to gn1[1]-1 ] contains list of elements from P2 connected to the first element in P1
    //       gg1[n2 to n2+gn1[2]-1 ] contains list of elements from P2 connected to the first element in P1
    //       gg1[2*n2 to 2*n2+gn1[3]-1 ] contains list of elements from P2 connected to the first element in P1
    //  and so on
    //  gg2 and gn2 are defined likewise to gg1 and gn1 except first gn2[1] are elements of P1 connected to the first element of P2 and so on

    //  u1 is the weight of elements in P1
    //  u2 is the weight of elements in P2
    //
    //  x  will store the flow in g i.e. x[i*n2+j] is the flow from i to j
    //  x1 stores flow from source to nodes in p1
    //  x2 stores flow from nodes in p2 to sink
    //
    //
    //  c1 is an array of length n1 -- list of elements from P1 in the min. weight cover
    //  nc1 is the number of elements from P1 in the minimum weight cover
    //  c2 is an array of length n2 -- list of elements from P2 in the min. weight cover
    //  nc2 is the number of elements from P2 in the minimum weight cover
    //
    // *******************************************************************************


    // *********************
    // initialize variables
    int n, n1, n2, i, j;
    double c;
    int *p, *d1, *d2;
    // *********************
    // set values
    n1=*n1_in;
    n2=*n2_in;
    // *********************
    // allocate memory
    p=Calloc(n1+n2+2,int);
    d1=Calloc(n1,int);
    d2=Calloc(n2,int);

    // ======================================================================================
    // setup for print output
    int print_out=0;
    string outfile=make_outfile("min_weight_cover_");
    ofstream outfilestream;
    if (print_out)
    {
      outfilestream.open(outfile.c_str());
      outfilestream<<"output from TreePack min_weight_cover"<<endl;
    }
    //=======================================================================================

    if (print_out)
    {
      outfilestream<<"n1="<<n1<<" n2="<<n2<<endl;
      outfilestream<<"gg1:"<<endl;
      for (i=0;i<n1;i++)
      {
        for (j=0;j<gn1[i];j++)
        {
          outfilestream<<gg1[n2*i+j]<<" ";
        }
        outfilestream<<endl;
      }
      outfilestream<<"gg2:"<<endl;
      for (i=0;i<n2;i++)
      {
        for (j=0;j<gn2[i];j++)
        {
          outfilestream<<gg2[n1*i+j]<<" ";
        }
        outfilestream<<endl;
      }
      outfilestream<<"full gg1:"<<endl;
      for (i=0;i<n1;i++)
      {
        for (j=0;j<n2;j++)
        {
          outfilestream<<gg1[n2*i+j]<<" ";
        }
        outfilestream<<endl;
      }
      outfilestream<<"full gg2:"<<endl;
      for (i=0;i<n2;i++)
      {
        for (j=0;j<n1;j++)
        {
          outfilestream<<gg2[n1*i+j]<<" ";
        }
        outfilestream<<endl;
      }
    }
    // *********************
    // solve maximum flow

    for (i=0;i<n1;i++) x1[i]=0.0;
    for (j=0;j<n2;j++) x2[j]=0.0;
    for (i=0;i<n1;i++)
    {
      for (j=0;j<n2;j++) x[i*n2+j]=0.0;
    }
    double c_tot=0.0;
    aug_flow_MWC(n1,n2,g,gg1,gn1,gg2,gn2,u1,u2,x,x1,x2,d1,d2,p,&n,&c);
    c_tot+=c;
    while (c>0.0)
    {
      //Rcout<<c<<endl;
      aug_flow_MWC(n1,n2,g,gg1,gn1,gg2,gn2,u1,u2,x,x1,x2,d1,d2,p,&n,&c);
      c_tot+=c;
      if (c_tot>=1.0) break;
    }
    //Rcout<<c<<endl;
    //Rcout<<"c_tot="<<c_tot<<endl;
    // ********************
    // find min weight cover
    find_MWC(n1,n2,g,gg1,gn1,gg2,gn2,u1,u2,x,x1,x2,d1,d2,c1,c2,nc1,nc2);
    Free(d1); Free(d2); Free(p);
    if (print_out)
    {
      outfilestream<<"min_weight_cover complete"<<endl;
    }
}

void find_MWC(int n1, int n2, int *g, int *gg1, int *gn1, int *gg2, int *gn2, double *u1, double *u2, double *x, double *x1, double *x2, int *d1, int *d2, int *c1, int *c2, int *nc1, int *nc2)
{
    // 1. apply breadth first search
    // 2. check conditions to put node in cover
    //      i. can't reach an element in P1 then it goes in cover
    //      ii. can reach an element in P2 then it goes in cover
    int i,j,k,j1,m,m0,v,nc11,nc22;
    int *list;
    list=Calloc(n1+n2,int);

    // ======================================================================================
    // setup for print output
    int print_out=0;
    string outfile=make_outfile("find_MWC_");
    ofstream outfilestream;
    if (print_out)
    {
      outfilestream.open(outfile.c_str());
      outfilestream<<"output from TreePack find_MWC"<<endl;
    }
    //=======================================================================================


    // initialize d1 and d2 using -1 to mean not yet reached
    for (i=0;i<n1;i++)
    {
      d1[i]=-1;
      c1[i]=-1;
    }
    for (j=0;j<n2;j++)
    {
      d2[j]=-1;
      c2[j]=-1;
    }

    // start at the source and make connections to elements in P1
    m=0;
    for (i=0;i<n1;i++)
    {
        if ( (u1[i]-x1[i])>0.0)
        {
            list[m]=i;
            m++;
            d1[i]=1;
        }
    }

    // continue breadth first search
    m0=0;
    if (print_out)
    {
      outfilestream<<"continue bfs"<<endl;
    }
    if (print_out)
    {
      outfilestream<<"m0="<<m0<<" out of "<<m<<endl;
    }
    while (m>m0) // while the last element in the list has not been reached
    {
        k=list[m0];
        if (print_out)
        {
          outfilestream<<"k="<<k<<endl;
          outfilestream<<"m0="<<m0<<" out of "<<m<<endl;
        }
        // k<n1 -> k indexes element of P1
        if (k<n1)
        {
            i=k;
            // loop over neighbor of i in P2
            for (v=0;v<gn1[i];v++)
            {
                j=gg1[i*n2+v];
                j1=j+n1;
                // check if j has been reached already
                if (d2[j]==-1)
                {
                    // add j to list
                    d2[j]=d1[i]+1;
                    list[m]=j1;
                    m++;
                }
            }
        }
        else
        {
            // k indexes an element of P2
            j=k-n1;
            // check the neighbors of j in P1
            for (v=0;v<gn2[j];v++)
            {
                i=gg2[j*n1+v];
                // check if i hasn't been reachd and if there is a flow from i to j
                if (x[i*n2+j]>0.0 && d1[i]==-1)
                {
                    // add i to list
                    d1[i]=d2[j]+1;
                    list[m]=i;
                    m++;
                }
            }
        }
        // move to the next element in list
        m0++;
    }




    // Rprintf("d1: ");
    //   for (i=0;i<n1;i++) Rprintf("%d ",d1[i]);
    // Rprintf("\n");
    // Rprintf("d2: ");
    //   for (i=0;i<n2;i++) Rprintf("%d ",d2[i]);
    // Rprintf("\n");

    if (print_out)
    {
      outfilestream<<"done with bfs begin collect cover"<<endl;
    }
    // collect cover
    nc11=0; nc22=0;
    for (i=0;i<n1;i++)
    {
        // check if i is not reached
        if (d1[i]==-1)
        {
            c1[nc11]=i;
            nc11++;
        }
    }
    for (j=0;j<n2;j++)
    {
        // check if j has been reached
        if (d2[j]>-1)
        {
            c2[nc22]=j;
            nc22++;
        }
    }
    if (print_out)
    {
      outfilestream<<"done with collect cover"<<endl;
    }
    *nc1=nc11;
    *nc2=nc22;
    Free(list);
    if (print_out)
    {
      outfilestream<<"find_MWC complete"<<endl;
    }
}

void aug_flow_MWC(int n1, int n2, int *g, int *gg1, int *gn1, int *gg2, int *gn2, double *u1, double *u2, double *x, double *x1, double *x2, int *d1, int *d2, int *p, int *n, double *c)
{
    *c=0.0;
    *n=0;
    find_aug_path_MWC(n1,n2,g,gg1,gn1,gg2,gn2,u1,u2,x,x1,x2,d1,d2,p,n,c);
    //Rcout<<"p=";
    //for (int i=0;i<*n;i++) Rcout<<p[i]<<" ";
    //Rcout<<endl;
    push_flow_MWC(n1,n2,g,u1,u2,x,x1,x2,p,*n,*c);
}

void find_aug_path_MWC(int n1, int n2, int *g, int *gg1, int *gn1, int *gg2, int *gn2, double *u1, double *u2, double *x, double *x1, double *x2, int *d1, int *d2, int *p, int *n, double *c)
{
    // *******************************************************************************
    // Input descriptions
    // *******************************************************************************
    // g is an n1 x n2 array
    //
    //        g represents a bipartite graph:
    //        the graph has two partitions P1 and P2 with n1 and n2 elements, respectively
    //        let i index an element of P1, and j index an element of P2
    //        entry g[i*n2+j] is 1 if there is a connection between i and j,
    //                           0 otherwise
    //  gg1 is an n1 x n2 array
    //       gg1[0 to gn1[1]-1 ] contains list of elements from P2 connected to the first element in P1
    //       gg1[n2 to n2+gn1[2]-1 ] contains list of elements from P2 connected to the first element in P1
    //       gg1[2*n2 to 2*n2+gn1[3]-1 ] contains list of elements from P2 connected to the first element in P1
    //  and so on
    //  gg2 and gn2 are defined likewise to gg1 and gn1 except first gn2[1] are elements of P1 connected to the first element of P2 and so on

    //  u1 is the weight of elements in P1
    //  u2 is the weight of elements in P2
    //
    //  x  will store the flow in g i.e. x[i*n2+j] is the flow from i to j
    //  x1 stores flow from source to nodes in p1
    //  x2 stores flow from nodes in p2 to sink
    //
    //  p stores the augmenting path - n1+n2 array
    //  n number of nodes in augmenting path
    //  c capacity of augmenting path
    //  d1 stores distance from source, in residual graph, for elements in P1
    //  d2 stores distance from source, in residual graph, for elements in P2
    //
    //
    // *******************************************************************************

    // ********************************
    // initialize variables

    // single values:
    // i indexes elements of P1
    // j indexes elements of P2
    // k indexes elements in the range 1 to n1+n2
    // j1 indexes elements in the range n1 to n1+n2
    // m is the current number of elements in list
    // m0 is the index of the next element in list
    // v helps index gg1 and gg2
    // ps is last index to sink
    // ds is distance from source to ps
    // n0 stores the length of the path
    // c0 stores the capacity of the path
    //
    // arrays:
    // list n1+n2 length array containing a list of nodes to visit
    // pr n1+n2 length array storing the tree from breadth first search via parent indexes
    //          pr[1 to n1-1] are parents for elements of P1
    //          pr[n1 to n1+n2] are parents for elements of P2
    // ********************************

    int i,j,k,j1,m,m0,v,ps,ds,n0;
    int *list, *pr;
    double c0;
    list=Calloc(n1+n2,int);
    pr=Calloc(n1+n2,int);

    *n=0;
    *c=0.0;

    // start at the source and make connections to elements in P1
    //Rcout<<"n1="<<n1<<" n2="<<n2<<endl;
    //Rcout<<"gg1:"<<endl;
    for (i=0;i<n1;i++)
    {
      for (j=0;j<gn1[i];j++)
      {
        //Rcout<<gg1[n2*i+j]<<" ";
      }
     // Rcout<<endl;
    }
    //Rcout<<"gg2:"<<endl;
    for (i=0;i<n2;i++)
    {
      for (j=0;j<gn2[i];j++)
      {
        //Rcout<<gg2[n1*i+j]<<" ";
      }
      //Rcout<<endl;
    }
    //Rcout<<"full gg1:"<<endl;
    for (i=0;i<n1;i++)
    {
      for (j=0;j<n2;j++)
      {
        //Rcout<<gg1[n2*i+j]<<" ";
      }
      //Rcout<<endl;
    }
    //Rcout<<"full gg2:"<<endl;
    for (i=0;i<n2;i++)
    {
      for (j=0;j<n1;j++)
      {
        //Rcout<<gg2[n1*i+j]<<" ";
      }
      //Rcout<<endl;
    }
    for (i=0;i<(n1+n2);i++) pr[i]=-2;
    m=0;
    for (i=0;i<n1;i++)
    {
        if ( (u1[i]-x1[i])>0.0)
        {
            list[m]=i;
            m++;
            d1[i]=1;
            pr[i]=-1;
        }
    }

    // continue breadth first search
    m0=0;
    ps=-1;
    while (m>m0) // while the last element in the list has not been reached
    {
        k=list[m0];
        // k<n1 -> k indexes element of P1
        if (k<n1)
        {
            i=k;
            // loop over neighbor of i in P2
            for (v=0;v<gn1[i];v++)
            {
                j=gg1[i*n2+v];
                j1=j+n1;
                // check if j has been reached already
                if (pr[j1]==-2)
                {
                    // j has not been reached
                    // give j a parent
                    // add j to list
                    pr[j1]=i;
                    d2[j]=d1[i]+1;
                    list[m]=j1;
                    m++;
                }
            }
        }
        else
        {
            // k indexes an element of P2
            j=k-n1;
            // check if there is connection in residual network from j to sink
            if ( (u2[j]-x2[j]) >0.0)
            {
                // found a path in the residual network to the sink
                ps=k;
                ds=d2[j];
                break;
            }
            // check the neighbors of j in P1
            for (v=0;v<gn2[j];v++)
            {
                i=gg2[j*n1+v];
                // check if i hasn't been reach and if there is a flow from i to j
                if (x[i*n2+j]>0.0 && pr[i]==-2)
                {
                    // make j (indexed by k) the parent of i
                    // add i to list
                    pr[i]=k;
                    d1[i]=d2[j]+1;
                    list[m]=i;
                    m++;
                }
            }
        }
        // move to the next element in list
        m0++;
    }
    //Rcout<<"pr=";
    //for (i=0;i<(n1+n2);i++) Rcout<<pr[i]<<" ";
    //Rcout<<endl;
    // check if there is an augmenting path
    if (ps>-1)
    {
        // get path
        c0=u2[ps-n1]-x2[ps-n1]; // initialize the path capacity to the residual capacity from ps to the sink
        //Rcout<<"ps-n1="<<ps-n1<<" u2[ps-n1]-x2[ps-n1]="<<u2[ps-n1]-x2[ps-n1]<<endl;
        //Rcout<<"ds-1="<<ds-1<<endl;
        //Rcout<<"ps="<<ps<<endl;
        p[ds-1]=ps;// put ps at the end of the path
        n0=1;
        k=pr[ps]; // move to the parent of ps
        while (k>-1)
        {
            // Rcout<<"ds-n0-1="<<ds-n0-1<<endl;
            // Rcout<<"k="<<k<<endl;
            p[ds-n0-1]=k; // add k to the path
            n0++;
            // check the residual capacity from the parent of k to k
            // check if k is in P1
            if (k<n1)
            {
                // check if the parent of k is the source
                if (pr[k]==-1)
                {
                    // parent of k is the source
                    // check the residual capacity from the source to k
                    if (c0>(u1[k]-x1[k]) ) c0= (u1[k]-x1[k]);
                    //Rcout<<"k="<<k<<" u1[k]-x1[k]="<<u1[k]-x1[k]<<endl;
                }
                else
                {
                    // parent of k is not the source
                    i=k;
                    j=pr[k]-n1;
                    // check the residual capacity from j to i
                    // this is equal to the flow from j to i
                    if (c0> x[i*n2+j]) c0=x[i*n2+j];
                    // Rcout<<"x[i*n2+j]="<<x[i*n2+j]<<endl;
                }
            }
            // if k is in P2 then parent of k is in P1. in this case the residual capacity is infinity
            k=pr[k]; // move to the parent of k
        }
        *c=c0;
        *n=n0;
        // Rcout<<"n0="<<n0<<" ds="<<ds<<endl;
    }
    Free(list); Free(pr);
}

void push_flow_MWC(int n1, int n2, int *g, double *u1, double *u2, double *x, double *x1, double* x2, int* p, int n, double c)
{
    if (n>0)
    {
        int i, j, k;
        // augment flow from source to first node in path
        // Rcout<<"u1[p[0]]="<<u1[p[0]]<<endl;
        // Rcout<<"x1[p[0]]="<<x1[p[0]]<<endl;
        x1[p[0]]+=c;
        // Rcout<<"x1[p[0]]+=c ->"<<x1[p[0]]<<endl;
        // augment flow from last node in path to sink
        // Rcout<<"u2[p[n-1]-n1]="<<u2[p[n-1]-n1]<<endl;
        // Rcout<<"x2[p[n-1]-n1]="<<x2[p[n-1]-n1]<<endl;
        x2[p[n-1]-n1]+=c;
        // Rcout<<"x2[p[n-1]-n1]+=c ->"<<x2[p[n-1]-n1]<<endl;
        // augment flow from nodes in P1 to nodes in P2
        for (k=1;k<n;k+=2)
        {
            i=p[k-1];
            j=p[k]-n1;
            // Rcout<<"j="<<j<<" i="<<i<<endl;
            // Rcout<<"x[i*n2+j]="<<x[i*n2+j]<<endl;
            x[i*n2+j]+=c;
            // Rcout<<"x[i*n2+j]+=c ->"<<x[i*n2+j]<<endl;
        }
        // reduce flow from nodes in P2 to nodes in P1
        for (k=2;k<n;k+=2)
        {
            j=p[k-1]-n1;
            i=p[k];
            x[i*n2+j]-=c;
        }
    }
}


void find_aug_path_MWC_old(int n1, int n2, int *g, int *gg1, int *gn1, int *gg2, int *gn2, double *u1, double *u2, double *x, double *x1, double *x2, int *d1, int *d2, int *p, int *n, double *c)
{
  // *******************************************************************************
  // Input descriptions
  // *******************************************************************************
  // g is an n1 x n2 array
  //
  //        g represents a bipartite graph:
  //        the graph has two partitions P1 and P2 with n1 and n2 elements, respectively
  //        let i index an element of P1, and j index an element of P2
  //        entry g[i*n2+j] is 1 if there is a connection between i and j,
  //                           0 otherwise
  //  gg1 is an n1 x n2 array
  //       gg1[0 to gn1[1]-1 ] contains list of elements from P2 connected to the first element in P1
  //       gg1[n2 to n2+gn1[2]-1 ] contains list of elements from P2 connected to the first element in P1
  //       gg1[2*n2 to 2*n2+gn1[3]-1 ] contains list of elements from P2 connected to the first element in P1
  //  and so on
  //  gg2 and gn2 are defined likewise to gg1 and gn1 except first gn2[1] are elements of P1 connected to the first element of P2 and so on

  //  u1 is the weight of elements in P1
  //  u2 is the weight of elements in P2
  //
  //  x  will store the flow in g i.e. x[i*n2+j] is the flow from i to j
  //  x1 stores flow from source to nodes in p1
  //  x2 stores flow from nodes in p2 to sink
  //
  //  p stores the augmenting path - n1+n2 array
  //  n number of nodes in augmenting path
  //  c capacity of augmenting path
  //  d1 stores distance from source, in residual graph, for elements in P1
  //  d2 stores distance from source, in residual graph, for elements in P2
  //
  //
  // *******************************************************************************

  // ********************************
  // initialize variables

  // single values:
  // i indexes elements of P1
  // j indexes elements of P2
  // k indexes elements in the range 1 to n1+n2
  // j1 indexes elements in the range n1 to n1+n2
  // m is the current number of elements in list
  // m0 is the index of the next element in list
  // v helps index gg1 and gg2
  // ps is last index to sink
  // ds is distance from source to ps
  // n0 stores the length of the path
  // c0 stores the capacity of the path
  //
  // arrays:
  // list n1+n2 length array containing a list of nodes to visit
  // pr n1+n2 length array storing the tree from breadth first search via parent indexes
  //          pr[1 to n1-1] are parents for elements of P1
  //          pr[n1 to n1+n2] are parents for elements of P2
  // ********************************

  int i,j,k,j1,m,m0,v,ps,ds,n0;
  int *list, *pr;
  double c0;
  list=Calloc(n1+n2,int);
  pr=Calloc(n1+n2,int);

  *n=0;
  *c=0.0;

  // start at the source and make connections to elements in P1
  for (i=0;i<(n1+n2);i++) pr[i]=-2;
  m=0;
  for (i=0;i<n1;i++)
  {
    if ( (u1[i]-x1[i])>0.0)
    {
      list[m]=i;
      m++;
      d1[i]=1;
      pr[i]=-1;
    }
  }

  // continue breadth first search
  m0=0;
  ps=-1;
  while (m>m0) // while the last element in the list has not been reached
  {
    k=list[m0];
    // k<n1 -> k indexes element of P1
    if (k<n1)
    {
      i=k;
      // loop over neighbor of i in P2
      for (v=0;v<gn1[i];v++)
      {
        j=gg1[i*n2+v];
        j1=j+n1;
        // check if j has been reached already
        if (pr[j1]==-2)
        {
          // j has not been reached
          // given j a parent
          // add j to list
          pr[j1]=i;
          d2[j]=d1[i]+1;
          list[m]=j1;
          m++;
        }
      }
    }
    else
    {
      // k indexes an element of P2
      j=k-n1;
      // check if there is connection in residual network from j to sink
      if ( (u2[j]-x2[j]) >0.0)
      {
        // found a path in the residual network to the sink
        ps=k;
        ds=d2[j];
        break;
      }
      // check the neighbors of j in P1
      for (v=0;v<gn2[j];v++)
      {
        i=gg2[j*n1+v];
        // check if i hasn't been reach and if there is a flow from i to j
        if (x[i*n2+j]>0.0 && pr[i]==-2)
        {
          // make j (indexed by k) the parent of i
          // add i to list
          pr[i]=k;
          d1[i]=d2[j]+1;
          list[m]=i;
          m++;
        }
      }
    }
    // move to the next element in list
    m0++;
  }
  // check if there is an augmenting path
  if (ps>-1)
  {
    // get path
    c0=u2[ps-n1]-x2[ps-n1]; // initialize the path capacity to the residual capacity from ps to the sink
    p[ds-1]=ps;// put ps at the end of the path
    n0=1;
    k=pr[ps]; // move to the parent of ps
    while (k>-1)
    {
      p[ds-n0-1]=k; // add k to the path
      n0++;
      // check the residual capacity from the parent of k to k
      // check if k is in P1
      if (k<n1)
      {
        // check if the parent of k is the source
        if (pr[k]==-1)
        {
          // parent of k is the source
          // check the residual capacity from the source to k
          if (c0>(u1[k]-x1[k]) ) c0= (u1[k]-x1[k]);
        }
        else
        {
          // parent of k is not the source
          i=k;
          j=pr[k]-n1;
          // check the residual capacity from j to i
          // this is equal to the flow from j to i
          if (c0> x[i*n1+j]) c0=x[i*n1+j];
        }
      }
      // if k is in P2 then parent of k is in P1. in this case the residual capacity is infinity
      k=pr[k]; // move to the parent of k
    }
    *c=c0;
    *n=n0;
  }
  Free(list); Free(pr);
}

void push_flow_MWC_old(int n1, int n2, int *g, double *u1, double *u2, double *x, double *x1, double* x2, int* p, int n, double c)
{
  if (n>0)
  {
    int i, j, k;
    // augment flow from source to first node in path
    // Rcout<<"u1[p[0]]="<<u1[p[0]]<<endl;
    // Rcout<<"x1[p[0]]="<<x1[p[0]]<<endl;
    x1[p[0]]+=c;
    // Rcout<<"x1[p[0]]+=c ->"<<x1[p[0]]<<endl;
    // augment flow from last node in path to sink
    // Rcout<<"u2[p[n-1]-n1]="<<u2[p[n-1]-n1]<<endl;
    // Rcout<<"x2[p[n-1]-n1]="<<x2[p[n-1]-n1]<<endl;
    x2[p[n-1]-n1]+=c;
    // Rcout<<"x2[p[n-1]-n1]+=c ->"<<x2[p[n-1]-n1]<<endl;
    // augment flow from nodes in P1 to nodes in P2
    for (k=1;k<n;k+=2)
    {
      i=p[k-1];
      j=p[k]-n1;
      // Rcout<<"j="<<j<<" i="<<i<<endl;
      // Rcout<<"x[i*n2+j]="<<x[i*n2+j]<<endl;
      x[i*n2+j]+=c;
      // Rcout<<"x[i*n2+j]+=c ->"<<x[i*n2+j]<<endl;
    }
    // reduce flow from nodes in P2 to nodes in P1
    for (k=2;k<n;k+=2)
    {
      j=p[k-1]-n1;
      i=p[k];
      x[i*n2+j]-=c;
    }
  }
}
