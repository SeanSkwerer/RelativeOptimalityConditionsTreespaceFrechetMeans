// phylo_tree_geo.c
#include "phylo_tree_geo.h"

extern "C"{
  void geo_step(int *k1_in, int *k2_in, int *t1, int *t2, double *l1, double *l2, int *a, int *b, double *lambda, int *t, double *l, int *k)
  {
    int k1=*k1_in;
    int k2=*k2_in;
    int leg;
    int j;
    double *an, *bn;
    an=Calloc(k1,double);
    bn=Calloc(k2,double);
    support_norms(k1,k2,l1,l2,a,b,an,bn);
    for (j=0;j<k1;j++) an[j]=sqrt(an[j]);
    for (j=0;j<k2;j++) bn[j]=sqrt(bn[j]);
    find_leg(k1,k2,an,bn,*lambda,&leg);

    geo_step_comp(*lambda,k1,k2,t1,t2,l1,l2,a,b,an,bn,t,l,k,0);
    geo_step_incomp(*lambda,k1,k2,t1,t2,l1,l2,a,b,an,bn,leg,t,l,k,*k);
    Free(an); Free(bn);
  }
}

void geo_step_outfile(int *k1_in, int *k2_in, int *t1, int *t2, double *l1, double *l2, int *a, int *b, double *lambda, int *t, double *l, int *k, ofstream &outfilestream)
{
  int k1=*k1_in;
  int k2=*k2_in;
  int leg;
  int j;
  double *an, *bn;
  an=Calloc(k1,double);
  bn=Calloc(k2,double);
  support_norms(k1,k2,l1,l2,a,b,an,bn);
  for (j=0;j<k1;j++) an[j]=sqrt(an[j]);
  for (j=0;j<k2;j++) bn[j]=sqrt(bn[j]);
  find_leg(k1,k2,an,bn,*lambda,&leg);
  outfilestream<<"before geo_step_comp"<<endl;
  geo_step_comp(*lambda,k1,k2,t1,t2,l1,l2,a,b,an,bn,t,l,k,0);
  outfilestream<<"before geo_step_incomp"<<endl;
  geo_step_incomp(*lambda,k1,k2,t1,t2,l1,l2,a,b,an,bn,leg,t,l,k,*k);
  outfilestream<<"after geo_step_comp"<<endl;
  Free(an); Free(bn);
}


void geo_step_incomp(double lambda,int k1, int k2, int *t1, int *t2, double *l1, double *l2, int *a, int *b, double *an, double *bn, int leg, int *t, double *l, int *k, int k_start)
{
  int i,j;
  int n=k_start;
  for (i=0;i<k1;i++)
  {
      if (a[i]>=0 && a[i]>=leg)
      {
        j=a[i];
        t[n]=t1[i];
        l[n]=l1[i]*( (1.0-lambda)*an[j]-lambda*bn[j] )/an[j];
        n++;
      }
  }
  for (i=0;i<k2;i++)
  {
     if (b[i]>=0 && b[i]<leg)
     {
       j=b[i];
       t[n]=t2[i];
       l[n]=l2[i]*( lambda*bn[j]-(1.0-lambda)*an[j] )/bn[j];
       n++;
     }
  }
  *k=n;
}

void geo_step_comp(double lambda,int k1, int k2, int *t1, int *t2, double *l1, double *l2, int *a, int *b, double *an, double *bn, int *t, double *l, int *k, int k_start)
{
    int i,j,n;
    n=k_start;
    for (i=0;i<k1;i++)
    {
        if (a[i]<0)
        {
            if (a[i]==-1)
            {
              //d0+=(l1[i]*l1[i]);
              t[n]=t1[i];
              l[n]=(1.0-lambda)*l1[i];
              n++;
            }
            else
            {
                j=abs(a[i]+2);
                //d0+=(l1[i]-l2[j])*(l1[i]-l2[j]);
                t[n]=t1[i];
                l[n]=(1.0-lambda)*l1[i]+lambda*l2[j];
                n++;
            }
        }
    }
    for (j=0;j<k2;j++)
    {
        if (b[j]==-1)
        {
          //d0+=(l2[j]*l2[j]);
          t[n]=t2[j];
          l[n]=lambda*l2[j];
          n++;
        }
    }
    *k=n;
}

void find_leg(int k1, int k2, double *an, double *bn, double lambda, int *leg)
{
  int k;
  double rho;
  k=0;
  rho=lambda/(1.0-lambda);
  while (bn[k]>0.0 && k<k1 && k<k2)
  {
    if (rho<=(an[k]/bn[k] ))
    {
      break;
    }
    k++;
  }
  *leg=k;
}

//support_norms(k,trn[i],p,&trl[tri],&A[i*k],&B[tri],an,bn);
void support_norms(int k1, int k2, double *l1, double *l2, int *a, int *b, double *an, double *bn)
{
  int i;
    for (i=0;i<k1;i++)
    {
        if (a[i]>=0) an[ a[i] ]+= (l1[i]*l1[i]);
    }
    for (i=0;i<k2;i++)
    {
       if (b[i]>=0) bn[ b[i] ]+= (l2[i]*l2[i]);
    }
}

void support_norms_restricted(int k1, int k2, double *l1, double *l2, int *a, int *b, double *an, double *bn, int *activeA, int *activeB, int nactiveA, int nactiveB)
{
  int i,i0;
  for (i0=0;i0<nactiveA;i0++)
  {
    i=activeA[i0];
    if (a[i]>=0) an[ a[i] ]+= (l1[i]*l1[i]);
  }
  for (i0=0;i0<nactiveB;i0++)
  {
    i=activeB[i0];
    if (b[i]>=0) bn[ b[i] ]+= (l2[i]*l2[i]);
  }
}

extern "C"{
  void geo_dist_in(int *k1, int *k2, int *t1, int *t2, double *l1, double *l2, int *g, int *n, int *a, int *b, double *d)
  {
    phylo_tree_geo(k1,k2,t1,t2,l1,l2,g,*n,a,b);
    geo_dist(k1,k2,a,b,l1,l2,d);
  }
}


void geo_dist(int* k1, int* k2, int* a, int *b, double *l1, double *l2, double *d)
{
    // computes **squared** distance
    double d0, d1;
    d0=0.0;d1=0.0;
    geo_dist_comp(*k1,*k2,a,b,l1,l2,&d0);
    geo_dist_incomp(*k1,*k2,a,b,l1,l2,&d1);
    *d=d0+d1;
}

void geo_dist_comp(int k1, int k2, int *a, int *b, double *l1, double *l2, double *d)
{
    int i,j;
    double d0;
    d0=0.0;
    for (i=0;i<k1;i++)
    {
        if (a[i]<0)
        {
            if (a[i]==-1) d0+=(l1[i]*l1[i]);
            else
            {
                j=abs(a[i]+2);
                d0+=(l1[i]-l2[j])*(l1[i]-l2[j]);
            }
        }
    }
    for (j=0;j<k2;j++)
    {
        if (b[j]==-1) d0+=(l2[j]*l2[j]);
    }
    *d=d0;
}

void geo_dist_incomp(int k1, int k2, int *a, int *b, double *l1, double *l2, double *d)
{
    int i;
    double d0, *va, *vb;
    va=Calloc(k1,double);
    vb=Calloc(k2,double);
    // collect norms for each support pair
    for (i=0;i<k1;i++)
    {
        if (a[i]>=0) va[ a[i] ]+= (l1[i]*l1[i]);
    }
    for (i=0;i<k1;i++)
    {
        if (va[i]==0.0) break;
        va[i]= pow(va[i],0.5);
    }
    for (i=0;i<k2;i++)
    {
       if (b[i]>=0) vb[ b[i] ]+= (l2[i]*l2[i]);
    }
    for (i=0;i<k2;i++)
    {
        if (vb[i]==0.0) break;
        vb[i]= pow(vb[i],0.5);
    }
    // aggregate values of support pairs
    d0=0.0;
    for (i=0;i<k1;i++)
    {
        if (va[i]==0.0) break;
        d0+=pow(va[i]+vb[i],2.0);
    }
    *d=d0;
    Free(va); Free(vb);
}

void phylo_tree_geo(int *k1_in, int *k2_in, int *t1, int *t2, double *l1, double *l2, int *g, int n, int *a, int *b)
{
    // **************************************************************
    // input descriptions
    // **************************************************************
    // k1 is the number of edges in tree 1
    // k2 is the number of edges in tree 2
    // t1 is the array of edge indexes for tree 1
    // t2 is the array of edge indexes for tree 2
    // l1 is the array of edge lengths in tree 1
    // l2 is the array of edges lengths in tree 2
    // n is the number of edges included in the link graph
    // *g is n x n element array, representing the link graph
    //      g[i*n+j] is 1 if i and j are compatible and 0 otherwise
    // **************************************************************
    int k1,k2;
    k1=*k1_in; k2=*k2_in;

    // **********************************************
    // local variables
    // **********************************************
    // i, j iterators for tree 1 and tree 2
    // m1, m2 counters for incompatible edges in tree 1 and tree 2
    // nc counter for # of edges a specific edge is incompatible with -- used to check if an edge is compatible in a tree
    // n1,n2 counters for compatible edges in tree 1 and tree 2
    // g0 incompatibility graph for tree 1 and tree 2
    // g1 subgraph for incompatible edges only
    // i1,i2 storage for indexes of compatible and incompatible edges in tree 1 and tree 2
    //       i1[i] for 0<i<m1 lists indexes of incompatible edges in tree 1
    //       i2[k1-j] for 1<j<n1 lists indexes of compatible edges in tree 1
    // u, v index holders used when iterating through i1 and i2
    // a1, b1
    int i,j,m1,m2,nc,n1,n2,u,v;
    int *g0,*g1,*i1,*i2, *a1,*b1;
    double *ll1,*ll2;
    // **********************************************
    // allocate memory
    // **********************************************
    g0=Calloc(k1*k2,int); g1=Calloc(k1*k2,int);
    i1=Calloc(k1,int); i2=Calloc(k2,int);
    a1=Calloc(k2,int); b1=Calloc(k2,int);
    ll1=Calloc(k1,double);
    ll2=Calloc(k2,double);
    // ***************************************************************

    // **********************************************
    // make incompatibility graph from link
    // **********************************************
    make_incomp_graph(k1,k2,t1,t2,g,n,g0);
    // Rcout<<"t1:";
    // for (i=0;i<k1;i++) Rcout<<t1[i]<<" ";
    // Rcout<<endl;
    // Rcout<<"t2:";
    // for (i=0;i<k2;i++) Rcout<<t2[i]<<" ";
    // Rcout<<endl;

    // Rprintf("g0:");
    // for (i=0;i<k1;i++)
    // {
    //  for (j=0;j<k2;j++)
    //  {
    //    Rprintf("%d ",g0[i*k2+j]);
    //  }
    //  Rprintf("\n");
    // }
    // Rprintf("g:");
    // for (i=0;i<n;i++)
    // {
    //   for (j=0;j<n;j++)
    //   {
    //     Rprintf("%d ",g[i*n+j]);
    //   }
    //   Rprintf("\n");
    // }
    // **********************************************
    // collect compatible and incompatible edges
    // **********************************************
    m1=0; m2=0; n1=0; n2=0;
    for (i=0;i<k1;i++)
    {
      nc=0;
      for (j=0;j<k2;j++)
      {
        nc+=g0[i*k2+j];
      }
      if (nc==0)
      {
        // i is compatible with every element of t2
        n1++;
        i1[k1-n1]=i;
      }
      else
      {
        // i is incompatible with at least one element of t2
        i1[m1]=i;
        m1++;
      }
    }
    for (j=0;j<k2;j++)
    {
      nc=0;
      for (i=0;i<k1;i++)
      {
        nc=nc+g0[i*k2+j];
      }
      if (nc==0)
      {
        // j is compatible with every element of t1
        n2++;
        i2[k2-n2]=j;
      }
      else
      {
        // j is incompatible with at least one element of t2
        i2[m2]=j;
        m2++;
      }
    }
    // ************************************************************
    // get incompatibility sub-matrix for incompatible edges
    // ************************************************************
    for (i=0;i<m1;i++)
    {
      u=i1[i];
      for (j=0;j<m2;j++)
      {
        v=i2[j];
        g1[i*m2+j]=g0[u*k2+v];
      }
    }
    // **********************************************************************************
    // move info from l1 and l2 into ll1 and ll2 for sub-matrix of incompatible edges
    // **********************************************************************************
    for (i=0;i<m1;i++)
    {
      u=i1[i];
      ll1[i]=l1[u];
    }
    for (j=0;j<m2;j++)
    {
      v=i2[j];
      ll2[j]=l2[v];
    }
    // ************************************************************
    // find support pairs for incompatible edges
    // ************************************************************
    phylo_tree_g(m1,m2,ll1,ll2,g1,a1,b1);


    // ************************************************************************************
    // make combined support for common and non-common edges
    // ************************************************************************************
    // definitions for a and b
    // ***********************
    // if a[i]>=0 then a[i] indicates the leg of the geodesic for edge i
    // if a[i]==-1 then a[i] indicates edge i is compatible but not present in tree 2
    // if a[i]<-1 then |a[i]+2| is the index of the matching edge in tree 2
    // if b[i]>=0 then b[i] indicate the leg of the geodesic for edge i
    // if b[i]==-1 then b[i] indicates edge i is compatible but not present in tree 1
    // if b[i]<-1 then |b[i]+2| is the index of the matching edge in tree 1
    // ************************************************************************************

    // map from a1 to a and b1 to b
    for (i=0;i<m1;i++) a[i1[i]]=a1[i];
    for (j=0;j<m2;j++) b[i2[j]]=b1[j];

    // ************************************************************************************
    // identify partners for compatible edges
    // ************************************************************************************
    for (j=m2;j<k2;j++)
    {
      v=i2[j];
      b[v]=-1;
    }
    for (i=m1;i<k1;i++)
    {
      u=i1[i];
      a[u]=-1;
      for (j=m2;j<k2;j++)
      {
        v=i2[j];
        if (t1[u]==t2[v])
        {
          a[u]=-2-v;
          b[v]=-2-u;
          break;
        }
      }
    }

    // ************************************************************************************
    // free memory
    // ************************************************************************************
    Free(g0); Free(g1);
    Free(i1); Free(i2);
    Free(a1); Free(b1);
    Free(ll1); Free(ll2);
    //Rcout<<"done with phylo_tree_geo"<<endl;
}

void phylo_tree_geo_warm_start(int *k1_in, int *k2_in, int *t1, int *t2, double *l1, double *l2, int *g, int n, int *a, int *b,
                               int *g0, int *g1, int *i1, int *i2, int *a1, int *b1, double *ll1, double *ll2)
{
  // **************************************************************
  // input descriptions
  // **************************************************************
  // k1 is the number of edges in tree 1
  // k2 is the number of edges in tree 2
  // t1 is the array of edge indexes for tree 1
  // t2 is the array of edge indexes for tree 2
  // l1 is the array of edge lengths in tree 1
  // l2 is the array of edges lengths in tree 2
  // n is the number of edges included in the link graph
  // *g is n x n element array, representing the link graph
  //      g[i*n+j] is 1 if i and j are compatible and 0 otherwise
  // a and b were computed for t1 and t2 and then l1 and l2 changed, and possibly t1 and t2 are changed
  // a and b adhere to
  //    if a[i]>=0 then  edge i incompatible with t2
  //    if a[i]==-1 then edge i is compatible but not present in tree 2
  //    if a[i]<-1 then |a[i]+2| is the index of the matching edge in tree 2
  //    if b[i]>=0 then edge i is not compatible in t1
  //    if b[i]==-1 then b[i] indicates edge i is compatible but not present in tree 1
  //    if b[i]<-1 then |b[i]+2| is the index of the matching edge in tree 1
  // ************************************************************************************

  // **************************************************************


  int k1,k2;
  k1=*k1_in; k2=*k2_in;

  // **********************************************
  // local variables
  // **********************************************
  // i, j iterators for tree 1 and tree 2
  // m1, m2 counters for incompatible edges in tree 1 and tree 2
  // nc counter for # of edges a specific edge is incompatible with -- used to check if an edge is compatible in a tree
  // n1,n2 counters for compatible edges in tree 1 and tree 2
  // g0 incompatibility graph for tree 1 and tree 2
  // g1 subgraph for incompatible edges only
  // i1,i2 storage for indexes of compatible and incompatible edges in tree 1 and tree 2
  //       i1[i] for 0<i<m1 lists indexes of incompatible edges in tree 1
  //       i2[k1-j] for 1<j<n1 lists indexes of compatible edges in tree 1
  // u, v index holders used when iterating through i1 and i2
  // a1, b1
  int i,j,m1,m2,nc,n1,n2,u,v;
  // **********************************************
  // make incompatibility graph from link
  // **********************************************
  make_incomp_graph(k1,k2,t1,t2,g,n,g0);
  // Rprintf("g0:");
  // for (i=0;i<k1;i++)
  // {
  //  for (j=0;j<k2;j++)
  //  {
  //    Rprintf("%d ",g0[i*k2+j]);
  //  }
  //  Rprintf("\n");
  // }

  // **********************************************
  // collect compatible and incompatible edges
  // **********************************************
  m1=0; m2=0; n1=0; n2=0;
  for (i=0;i<k1;i++)
  {
    if (a[i]<0)
    {
      // i is compatible with every element of t2
      n1++;
      i1[k1-n1]=i;
    }
    else
    {
      // i is incompatible with at least one element of t2
      i1[m1]=i;
      a1[m1]=a[i];
      m1++;
    }
  }
  for (j=0;j<k2;j++)
  {
    if (b[j]<0)
    {
      // j is compatible with every element of t1
      n2++;
      i2[k2-n2]=j;
    }
    else
    {
      // j is incompatible with at least one element of t2
      i2[m2]=j;
      b1[m2]=b[j];
      m2++;
    }
  }
  // ************************************************************
  // get incompatibility sub-matrix for incompatible edges
  // ************************************************************
  for (i=0;i<m1;i++)
  {
    u=i1[i];
    for (j=0;j<m2;j++)
    {
      v=i2[j];
      g1[i*m2+j]=g0[u*k2+v];
    }
  }
  // **********************************************************************************
  // move info from l1 and l2 into ll1 and ll2 for sub-matrix of incompatible edges
  // **********************************************************************************
  for (i=0;i<m1;i++)
  {
    u=i1[i];
    ll1[i]=l1[u];
  }
  for (j=0;j<m2;j++)
  {
    v=i2[j];
    ll2[j]=l2[v];
  }
  // ************************************************************
  // find support pairs for incompatible edges
  // ************************************************************
  phylo_tree_g_warm_start(m1,m2,ll1,ll2,g1,a1,b1);


  // ************************************************************************************
  // make combined support for common and non-common edges
  // ************************************************************************************
  // definitions for a and b
  // ***********************
  // if a[i]>=0 then a[i] indicates the leg of the geodesic for edge i
  // if a[i]==-1 then a[i] indicates edge i is compatible but not present in tree 2
  // if a[i]<-1 then |a[i]+2| is the index of the matching edge in tree 2
  // if b[i]>=0 then b[i] indicate the leg of the geodesic for edge i
  // if b[i]==-1 then b[i] indicates edge i is compatible but not present in tree 1
  // if b[i]<-1 then |b[i]+2| is the index of the matching edge in tree 1
  // ************************************************************************************

  // map from a1 to a and b1 to b
  for (i=0;i<m1;i++) a[i1[i]]=a1[i];
  for (j=0;j<m2;j++) b[i2[j]]=b1[j];

  // ************************************************************************************
  // identify partners for compatible edges
  // ************************************************************************************
  for (j=m2;j<k2;j++)
  {
    v=i2[j];
    b[v]=-1;
  }
  for (i=m1;i<k1;i++)
  {
    u=i1[i];
    a[u]=-1;
    for (j=m2;j<k2;j++)
    {
      v=i2[j];
      if (t1[u]==t2[v])
      {
        a[u]=-2-v;
        b[v]=-2-u;
        break;
      }
    }
  }
}


void phylo_tree_geo_no_alloc(int *k1_in, int *k2_in, int *t1, int *t2, double *l1, double *l2, int *g, int n, int *a, int *b,
                             int *g0, int *g1, int *i1, int *i2, int *a1, int *b1, double *ll1, double *ll2)
{
  // **************************************************************
  // input descriptions
  // **************************************************************
  // k1 is the number of edges in tree 1
  // k2 is the number of edges in tree 2
  // t1 is the array of edge indexes for tree 1
  // t2 is the array of edge indexes for tree 2
  // l1 is the array of edge lengths in tree 1
  // l2 is the array of edges lengths in tree 2
  // n is the number of edges included in the link graph
  // *g is n x n element array, representing the link graph
  //      g[i*n+j] is 1 if i and j are compatible and 0 otherwise
  // **************************************************************
  int k1,k2;
  k1=*k1_in; k2=*k2_in;

  // **********************************************
  // local variables
  // **********************************************
  // i, j iterators for tree 1 and tree 2
  // m1, m2 counters for incompatible edges in tree 1 and tree 2
  // nc counter for # of edges a specific edge is incompatible with -- used to check if an edge is compatible in a tree
  // n1,n2 counters for compatible edges in tree 1 and tree 2
  // g0 incompatibility graph for tree 1 and tree 2
  // g1 subgraph for incompatible edges only
  // i1,i2 storage for indexes of compatible and incompatible edges in tree 1 and tree 2
  //       i1[i] for 0<i<m1 lists indexes of incompatible edges in tree 1
  //       i2[k1-j] for 1<j<n1 lists indexes of compatible edges in tree 1
  // u, v index holders used when iterating through i1 and i2
  // a1, b1
  int i,j,m1,m2,nc,n1,n2,u,v;
  // **********************************************
  // make incompatibility graph from link
  // **********************************************
  make_incomp_graph(k1,k2,t1,t2,g,n,g0);
  // Rprintf("g0:");
  // for (i=0;i<k1;i++)
  // {
  //  for (j=0;j<k2;j++)
  //  {
  //    Rprintf("%d ",g0[i*k2+j]);
  //  }
  //  Rprintf("\n");
  // }

  // **********************************************
  // collect compatible and incompatible edges
  // **********************************************
  m1=0; m2=0; n1=0; n2=0;
  for (i=0;i<k1;i++)
  {
    nc=0;
    for (j=0;j<k2;j++)
    {
      nc=nc+g0[i*k2+j];
    }
    if (nc==0)
    {
      // i is compatible with every element of t2
      n1++;
      i1[k1-n1]=i;
    }
    else
    {
      // i is incompatible with at least one element of t2
      i1[m1]=i;
      m1++;
    }
  }
  for (j=0;j<k2;j++)
  {
    nc=0;
    for (i=0;i<k1;i++)
    {
      nc=nc+g0[i*k2+j];
    }
    if (nc==0)
    {
      // j is compatible with every element of t1
      n2++;
      i2[k2-n2]=j;
    }
    else
    {
      // j is incompatible with at least one element of t2
      i2[m2]=j;
      m2++;
    }
  }
  // ************************************************************
  // get incompatibility sub-matrix for incompatible edges
  // ************************************************************
  for (i=0;i<m1;i++)
  {
    u=i1[i];
    for (j=0;j<m2;j++)
    {
      v=i2[j];
      g1[i*m2+j]=g0[u*k2+v];
    }
  }
  // **********************************************************************************
  // move info from l1 and l2 into ll1 and ll2 for sub-matrix of incompatible edges
  // **********************************************************************************
  for (i=0;i<m1;i++)
  {
    u=i1[i];
    ll1[i]=l1[u];
  }
  for (j=0;j<m2;j++)
  {
    v=i2[j];
    ll2[j]=l2[v];
  }
  // ************************************************************
  // find support pairs for incompatible edges
  // ************************************************************
  phylo_tree_g(m1,m2,ll1,ll2,g1,a1,b1);


  // ************************************************************************************
  // make combined support for common and non-common edges
  // ************************************************************************************
  // definitions for a and b
  // ***********************
  // if a[i]>=0 then a[i] indicates the leg of the geodesic for edge i
  // if a[i]==-1 then a[i] indicates edge i is compatible but not present in tree 2
  // if a[i]<-1 then |a[i]+2| is the index of the matching edge in tree 2
  // if b[i]>=0 then b[i] indicate the leg of the geodesic for edge i
  // if b[i]==-1 then b[i] indicates edge i is compatible but not present in tree 1
  // if b[i]<-1 then |b[i]+2| is the index of the matching edge in tree 1
  // ************************************************************************************

  // map from a1 to a and b1 to b
  for (i=0;i<m1;i++) a[i1[i]]=a1[i];
  for (j=0;j<m2;j++) b[i2[j]]=b1[j];

  // ************************************************************************************
  // identify partners for compatible edges
  // ************************************************************************************
  for (j=m2;j<k2;j++)
  {
    v=i2[j];
    b[v]=-1;
  }
  for (i=m1;i<k1;i++)
  {
    u=i1[i];
    a[u]=-1;
    for (j=m2;j<k2;j++)
    {
      v=i2[j];
      if (t1[u]==t2[v])
      {
        a[u]=-2-v;
        b[v]=-2-u;
        break;
      }
    }
  }
}



void make_incomp_graph(int k1, int k2, int* t1, int* t2, int *g, int n, int* g0)
{
    int i,j,u,v;
        // collect the incompatibility graph for tree 1 and tree 2
    for (i=0;i<k1;i++)
    {
        for (j=0;j<k2;j++)
        {
            u=t1[i]; v=t2[j];
            if (g[u*n+v]==0) g0[i*k2+j]=1;
            else g0[i*k2+j]=0;
        }
    }
}

void phylo_tree_g_warm_start(int k1, int k2, double *l1, double *l2, int *g0, int *a, int *b)
{
    // **************************************************************
    // input descriptions
    // **************************************************************
    //
    // ***assumes compatible edges are not included***
    //
    // k1 is the number of edges in tree 1
    // k2 is the number of edges in tree 2
    // l1 is the array of edge lengths in tree 1
    // l2 is the array of edges lengths in tree 2
    // g0 is k1 x k2 array representing incompatibility graph for edges in tree 1 v. tree 2
    //
    // a and b were computed for t1 and t2 and then l1 and l2 changed, and possibly t1 and t2 changed
    // ************************************************************************************
    int i,j,u,v,k,n1, n2, nlist,nc1,nc2;
    int *g, *list, *gg1, *gg2, *gn1, *gn2, *s1, *s2, *C2, *D2, *c1, *c2;
    double w1,w2;
    double *u1, *u2, *x, *x1, *x2;

    g=Calloc(k1*k2,int);
    list=Calloc(k1+k2,int);
    gg1=Calloc(k1*k2,int); gg2=Calloc(k1*k2,int); gn1=Calloc(k1,int); gn2=Calloc(k2,int);
    s1=Calloc(k1,int); s2=Calloc(k2,int);
    C2=Calloc(k1,int); D2=Calloc(k2,int);
    c1=Calloc(k1,int); c2=Calloc(k2,int);

    u1=Calloc(k1,double); u2=Calloc(k2,double);
    x1=Calloc(k1,double); x2=Calloc(k2,double);
    x=Calloc(k1*k2,double);

    //nlist=1;
    //list[0]=0;
    //for (i=0;i<k1;i++) a[i]=0;
    //for (i=0;i<k2;i++) b[i]=0;
    //$here
    // 1. check that inequality is satisfied
    // 2. if not then combine
    // 3. if inequality is satisfied check cover is minimal
    // 4. if not then combine


    while (nlist>0)
    {
      nlist--;
      k=list[nlist];
      n1=0;
      n2=0;
      for (i=0;i<k1;i++)
      {
        if (a[i]==k)
        {
          s1[n1]=i;
          n1++;
        }
      }
      for (j=0;j<k2;j++)
      {
        if (b[j]==k)
        {
          s2[n2]=j;
          n2++;
        }
      }
      for (i=0;i<n1;i++) x1[i]=0.0;
      for (j=0;j<n2;j++) x2[j]=0.0;
      for (i=0;i<n1;i++)
      {
        u=s1[i];
        for (j=0;j<n2;j++)
        {
          v=s2[j];
          g[i*n2+j]=g0[u*k2+v];
          if (g0[u*k2+v]==1)
          {
            gg1[i*n2+gn1[i]]=j;
            gn1[i]++;
            gg2[j*n1+gn2[j]]=i;
            gn2[j]++;
          }
          x[i*n2+j]=0.0;
        }
      }
      w1=0.0; w2=0.0;
      for (i=0;i<n1;i++)
      {
        u=s1[i];
        u1[i]=l1[u]*l1[u];
        w1+=u1[i];
      }
      for (i=0;i<n1;i++) u1[i]/=w1;
      for (j=0;j<n2;j++)
      {
        v=s2[j];
        u2[j]=l2[v]*l2[v];
        w2+=u2[j];
      }
      for (j=0;j<n2;j++) u2[j]/=w2;
      min_weight_cover(&n1,&n2,g,gg1,gn1,gg2,gn2,u1,u2,x,x1,x2,c1,c2,&nc1,&nc2);
      //Rprintf("nc1=%d nc2=%d \n",nc1,nc2);
      if (nc1>0 && nc2>0)
      {
        // check inequality
        w1=0.0; w2=0.0;
        for (i=0;i<nc1;i++) w1+=u1[c1[i]];
        for (j=0;j<nc2;j++) w2+=u2[c2[j]];
        if ((w1+w2)<1.0)
        {
          // make space for new support
          for (i=0;i<k1;i++) if (a[i]>k) a[i]++;
          for (j=0;j<k2;j++) if (b[j]>k) b[j]++;
          // split support
          // split into C1, C2, D1 and D2
          for (i=0;i<n1;i++) C2[i]=1;
          for (j=0;j<n2;j++) D2[i]=0;
          for (i=0;i<nc1;i++) C2[c1[i]]=0; // in the vertex cover from tree 1 -> put in C1
          for (j=0;j<nc2;j++) D2[c2[j]]=1; // in the vertex cover from tree 2 -> put in D2
          for (i=0;i<n1;i++) if (C2[i]==1) a[s1[i]]++; // augment support pair index for C2
          for (j=0;j<n2;j++) if (D2[j]==1) b[s2[j]]++; // augment support pair index for D2
          list[nlist]=k;
          list[nlist+1]=k+1;
          nlist+=2;
        }
      }
    }
    Free(g); Free(list); Free(gg1); Free(gg2); Free(gn1); Free(gn2);
    Free(D2); Free(C2); Free(c1); Free(c2); Free(s1); Free(s2);
    Free(x1); Free(x2); Free(x); Free(u1); Free(u2);
}

void phylo_tree_g(int k1, int k2, double *l1, double *l2, int *g0, int *a, int *b)
{
  // **************************************************************
  // input descriptions
  // **************************************************************
  //
  // ***assumes compatible edges are not included***
  //
  // k1 is the number of edges in tree 1
  // k2 is the number of edges in tree 2
  // l1 is the array of edge lengths in tree 1
  // l2 is the array of edges lengths in tree 2
  // g0 is k1 x k2 array representing incompatibility graph for edges in tree 1 v. tree 2
  //
  int i,j,u,v,k,n1, n2, nlist,nc1,nc2;
  int *g, *list, *gg1, *gg2, *gn1, *gn2, *s1, *s2, *C2, *D2, *c1, *c2;
  double w1,w2;
  double *u1, *u2, *x, *x1, *x2;

  g=Calloc(k1*k2,int);
  list=Calloc(k1+k2,int);
  gg1=Calloc(k1*k2,int); gg2=Calloc(k1*k2,int); gn1=Calloc(k1,int); gn2=Calloc(k2,int);
  s1=Calloc(k1,int); s2=Calloc(k2,int);
  C2=Calloc(k1,int); D2=Calloc(k2,int);
  c1=Calloc(k1,int); c2=Calloc(k2,int);

  u1=Calloc(k1,double); u2=Calloc(k2,double);
  x1=Calloc(k1,double); x2=Calloc(k2,double);
  x=Calloc(k1*k2,double);

  // ======================================================================================
  // setup for print output
  int print_out=0;
  string outfile=make_outfile("phylo_tree_g_");
  ofstream outfilestream;
  if (print_out)
  {
    outfilestream.open(outfile.c_str());
    outfilestream<<"output from TreePack phylo_tree_g"<<endl;
  }
  //=======================================================================================


  nlist=1;
  list[0]=0;
  for (i=0;i<k1;i++) a[i]=0;
  for (i=0;i<k2;i++) b[i]=0;
  while (nlist>0)
  {
    nlist--;
    k=list[nlist];
    n1=0;
    n2=0;
    for (i=0;i<k1;i++)
    {
      if (a[i]==k)
      {
        s1[n1]=i;
        n1++;
      }
    }
    for (j=0;j<k2;j++)
    {
      if (b[j]==k)
      {
        s2[n2]=j;
        n2++;
      }
    }
    for (i=0;i<n1;i++) x1[i]=0.0;
    for (j=0;j<n2;j++) x2[j]=0.0;
    for (i=0;i<k1;i++) gn1[i]=0;
    for (i=0;i<k2;i++) gn2[i]=0;
    for (i=0;i<n1;i++)
    {
      u=s1[i];
      for (j=0;j<n2;j++)
      {
        v=s2[j];
        g[i*n2+j]=g0[u*k2+v];
        if (g0[u*k2+v]==1)
        {
          gg1[i*n2+gn1[i]]=j;
          gn1[i]++;
          gg2[j*n1+gn2[j]]=i;
          gn2[j]++;
        }
        x[i*n2+j]=0.0;
      }
    }
    if (print_out)
    {
      outfilestream<<"n1="<<n1<<" n2="<<n2<<endl;
      outfilestream<<"gg1:"<<endl;
      for (i=0;i<n1;i++)
      {
        for (j=0;j<gn1[i];j++)
        {
          outfilestream<<gg1[n2*i+j]<<" ";
        }
        outfilestream<<endl;
      }
      outfilestream<<"gg2:"<<endl;
      for (i=0;i<n2;i++)
      {
        for (j=0;j<gn2[i];j++)
        {
          outfilestream<<gg2[n1*i+j]<<" ";
        }
        outfilestream<<endl;
      }
      outfilestream<<"full gg1:"<<endl;
      for (i=0;i<n1;i++)
      {
        for (j=0;j<n2;j++)
        {
          outfilestream<<gg1[n2*i+j]<<" ";
        }
        outfilestream<<endl;
      }
      outfilestream<<"full gg2:"<<endl;
      for (i=0;i<n2;i++)
      {
        for (j=0;j<n1;j++)
        {
          outfilestream<<gg2[n1*i+j]<<" ";
        }
        outfilestream<<endl;
      }
    }
    w1=0.0; w2=0.0;
    for (i=0;i<n1;i++)
    {
      u=s1[i];
      u1[i]=l1[u]*l1[u];
      w1+=u1[i];
    }
    for (i=0;i<n1;i++) u1[i]/=w1;
    for (j=0;j<n2;j++)
    {
      v=s2[j];
      u2[j]=l2[v]*l2[v];
      w2+=u2[j];
    }
    for (j=0;j<n2;j++) u2[j]/=w2;
    min_weight_cover(&n1,&n2,g,gg1,gn1,gg2,gn2,u1,u2,x,x1,x2,c1,c2,&nc1,&nc2);
    if (print_out)
    {
      outfilestream<<"done with min_weight_cover back in phylo_tree_g"<<endl;
    }
    //Rprintf("nc1=%d nc2=%d \n",nc1,nc2);
    if (print_out)
    {
      outfilestream<<"nc1="<<nc1<<" nc2="<<nc2<<endl;
    }
    if (nc1>0 && nc2>0)
    {
      if (print_out)
      {
        outfilestream<<"k1="<<k1<<" k2="<<k2<<endl;
        outfilestream<<"c1 ";
        for (i=0;i<nc1;i++) outfilestream<<c1[i]<<" ";
        outfilestream<<endl;
        outfilestream<<"c2 ";
        for (i=0;i<nc2;i++) outfilestream<<c2[i]<<" ";
        outfilestream<<endl;
      }

      // check inequality
      w1=0.0; w2=0.0;
      for (i=0;i<nc1;i++) w1+=u1[c1[i]];
      for (j=0;j<nc2;j++) w2+=u2[c2[j]];
      if (print_out)
      {
        outfilestream<<"w1+w2="<<w1+w2<<endl;
      }
      if ((w1+w2)<1.0)
      {
        // make space for new support
        for (i=0;i<k1;i++) if (a[i]>k) a[i]++;
        for (j=0;j<k2;j++) if (b[j]>k) b[j]++;
        // split support
        // split into C1, C2, D1 and D2
        for (i=0;i<n1;i++) C2[i]=1;
        for (j=0;j<n2;j++) D2[j]=0;
        for (i=0;i<nc1;i++) C2[c1[i]]=0; // in the vertex cover from tree 1 -> put in C1
        for (j=0;j<nc2;j++)
        {
          if (print_out)
          {
            outfilestream<<"c2[j]="<<c2[j]<<" and k2="<<k2<<endl;
          }
          D2[c2[j]]=1; // in the vertex cover from tree 2 -> put in D2
        }
        for (i=0;i<n1;i++) if (C2[i]==1) a[s1[i]]++; // augment support pair index for C2
        for (j=0;j<n2;j++) if (D2[j]==1) b[s2[j]]++; // augment support pair index for D2
        list[nlist]=k;
        list[nlist+1]=k+1;
        nlist+=2;
      }
    }
    if (print_out)
    {
      outfilestream<<"nlist="<<nlist<<endl;
    }
  }
  if (print_out)
  {
    outfilestream<<"free memory"<<endl;
  }

  Free(g); Free(list); Free(gg1); Free(gg2); Free(gn1); Free(gn2);
  if (print_out)
  {
    outfilestream<<"done with Free(g); Free(list); Free(gg1); Free(gg2); Free(gn1); Free(gn2);"<<endl;
  }
  Free(c1); Free(c2);
  if (print_out)
  {
    outfilestream<<"done with Free(c1); Free(c2); "<<endl;
  }

  Free(s1); Free(s2);
  if (print_out)
  {
    outfilestream<<"done with Free(s1); Free(s2);"<<endl;
  }
  Free(x1); Free(x2); Free(x); Free(u1); Free(u2);
  if (print_out)
  {
    outfilestream<<"done with Free(x1); Free(x2); Free(x); Free(u1); Free(u2);"<<endl;
  }
  Free(C2);
  if (print_out)
  {
    outfilestream<<"done with Free(C2);"<<endl;
  }
  outfilestream<<"(pointer) D2="<<D2<<endl;
  outfilestream<<"D2=";
  for (i=0;i<k2;i++)
  {
    outfilestream<<D2[i]<<" ";
  }
  outfilestream<<endl;
  Free(D2);
  if (print_out)
  {
    outfilestream<<"done with Free(D2);"<<endl;
  }
  if (print_out)
  {
    outfilestream<<"done with phylo_tree_g"<<endl;
  }
}

void phylo_tree_geo_hot_start()
{

}

void nested_complex_geo()
{
  // 1. compute geodesic
  // 2. remove edge from complex -> remove adjacent faces
  // 3.
  //
}
