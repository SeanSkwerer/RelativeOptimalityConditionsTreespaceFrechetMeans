// make_outfile.cpp

#include "make_outfile.h"
string make_outfile(string root)
{
  // current date/time based on current system
  time_t now = time(0);

  tm *ltm = localtime(&now);

  string outfile;
  ostringstream combine;
  combine<<root;
  combine<<ltm->tm_year<<".";
  combine<<ltm->tm_mon<<".";
  combine<<ltm->tm_mday<<"."<<ltm->tm_hour<<".";
  combine<<ltm->tm_min<<"."<<ltm->tm_sec;
  combine<<".out";
  outfile=combine.str();
  return outfile;
}

string make_outfile_id(string root,int id)
{
  // current date/time based on current system
  time_t now = time(0);

  tm *ltm = localtime(&now);

  string outfile;
  ostringstream combine;
  combine<<root;
  combine<<"_"<<id<<"_";
  combine<<ltm->tm_year<<".";
  combine<<ltm->tm_mon<<".";
  combine<<ltm->tm_mday<<"."<<ltm->tm_hour<<".";
  combine<<ltm->tm_min<<"."<<ltm->tm_sec;
  combine<<".out";
  outfile=combine.str();
  return outfile;
}
