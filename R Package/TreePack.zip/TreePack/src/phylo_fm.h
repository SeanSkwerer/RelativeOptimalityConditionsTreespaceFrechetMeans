// phylo_fm.h
#ifndef PHYLO_FM_H
#define PHYLO_FM_H

#include <string>
#include <R.h>
#include <RcppArmadillo.h>
// [[Rcpp::depends(RcppArmadillo)]]

using namespace Rcpp;

#include "phylo_tree_geo.h"
#include "make_outfile.h"
#include "make_link.h"


void abs_inner_prod(int m, double *u, double *v, double *a);
void test_1simplex(int m, double *u, double *v, double *a);
void max_min_abs( int m, double *u, double *v, double *a);

void boundary_step_length(int m, double *d, double *l, double* c);
void boundary_step_length_simplex(int nactive, int* active, double *d, double *l, double *c);
void scale_vector_entries(int nactive, int* active, double *v, double *c);
void scale_vector(double *v, int nactive, int *active, double c);
void project_to_sphere(double *v, int nactive, int *active, double *p);
void enter_values(double *v, int nactive, int *active, double *p);
void diff_vector(double *v, double *u, int nactive, int *active, double* x);

void FSS(int* k_in, int* t, double* l, int* n_in, int* trn, int* tr, double* trl, int* g, int* ng_in, int* m_in, double* ss);
void grad(int k,double *l,int* A,int n,int* trn,double *trl,int* B,double *gr);
void grad_v2(int k,double *l,int* A,int n,int* trn,double *trl,int* B,double *gr);
void grad_hess(int k,double *l,int* A,int n,int* trn,double *trl,int* B,arma::vec gr);

void hess(int k, double* l, int *A, int n, int *trn, double* trl, int* B, double* h);
void hess_arma(int k, double* l, int *A, int n, int *trn, double* trl, int* B, arma::mat);
void inductive_mean(int *i0_in, int *m_in, int *k_in, int* sequence, int *n_in, int *trn, int* tr, double* trl, int *t0, double *l0, int* k0,int *ng_in, int *g);
void make_geo_supports(int k, int *t, double *l, int n, int* trn, int* tr, double* trl, int *g, int ng, int* A, int* B);
void norm(int m, double *v, double nrm);

void newton(int k, int *t, double *l, int n, int* trn, int* tr, double* trl, int* g, int ng, int m, double cr, int N, double del);
bool newton_dir(arma::vec gr, arma::mat hs, arma::vec newt_dir);
void step(int k, double *d, double *l, double c);
void step_v(int k, double *d, double *l, double *c, double a);
void boundary_step_length_v(int m, double *d, double *l, double *c);
void tree_grad(int k, double *l, int* a, int k1, double* l1, int* b, double* gr);
void tree_hess(int k, double* l, int* a, int k1, double* l1, int* b, double* h);

void steepest(int k, int* t, double* l, int n, int* trn, int* tr, double* trl, int* g, int ng, int m, double cr, int N, double del);
void steepest_v(int k, int* t, double* l, double *gr, int n, int* trn, int* tr, double* trl, int* g, int ng, int m, double cr, int N, double del);
void damped_steepest_v(int k, int* t, double* l, double *gr, int n, int* trn, int* tr, double* trl, int* g, int ng, int m, double cr, int N, double del, double eps0);

void normalDD(int k, double *p, int *A, int n, int* trn, double *trl, int *B, int m, double* dd, ofstream& outfilestream, int nactive, int *active, int level, int *tra);

void round_edges_with_pos_grad_to_zero(int k, double *l, double *gr, double eps, int* nactive, int *active);

#endif
