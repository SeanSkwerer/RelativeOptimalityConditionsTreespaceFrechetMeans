#' @export
"convert_edge"<-function(t,e)
{
  n<-sum(t>-1)
  a<-matrix(0,1,n)
  out<-.C("convert_edge_in",t=as.integer(t),n=as.integer(n),e=as.integer(e),a=as.integer(a),val=as.integer(1),m=as.integer(length(t)))
  return(out)
}
#void convert_edge(int *tree, int n, int e, int *a, int val)

