#' @useDynLib TreePack
#' @export
"geo_dist"<-function(t1,t2,l1,l2,g=NULL)
{

  # #################################################
  # check input
  # #################################################
  if (!is.numeric(t1) || !is.numeric(t2))
  {
    stop("t1 and t2 must be integer")
  }
  if (!is.numeric(l1) || !is.numeric(l2))
  {
    stop("l1 and l2 must be numeric")
  }

  if (is.null(g))
  {
    m1<-sum(t1==-1)
    m2<-sum(t2==-1)
    if (m1!=length(l1))
    {
      stop("sum(t1==-1) must equal length(l1)")
    }
    if (m2!=length(l2))
    {
      stop("sum(t2==-1) must equal length(l2)")
    }



    # #################################################
    # make link graph
    # #################################################
    n<-2
    nt<-c(length(t1),length(t2))
    max<-sum(t1>-1)
    m1<-sum(t1==-1)
    m2<-sum(t2==-1)
    ne<-c(m1,m2)
    ngd<-sum(ne)
    gd<-rep(0,ngd*ngd)
    ngdi<-rep(0,ngd)
    g<-rep(0,ngd*ngd)
    gt<-rep(0,ngd)
    gte<-rep(0,ngd)
    ti<-rep(0,ngd)
    t<-as.integer(c(t1,t2))
    mi_out<-.C("make_link",n=as.integer(n),nt=as.integer(nt),t=as.integer(t),ne=as.integer(ne),
               max=as.integer(max),ngd=as.integer(ngd),gd=as.integer(gd),ngdi=as.integer(ngdi),g=as.integer(g),ng=integer(1),
               gt=as.integer(gt),gte=as.integer(gte),ti=as.integer(ti))

    ng<-mi_out$ng
    g<-matrix(mi_out$g,ngd,ngd)
    g<-g[1:ng,1:ng]


    t1<-as.integer(mi_out$ti[1:ne[1]])
    t2<-as.integer(mi_out$ti[(ne[1]+1):ngd])
  }
  else
  {
    m1<-length(t1)
    m2<-length(t2)
    if (m1!=length(l1))
    {
      stop("length(t1) must equal length(l1)")
    }
    if (m2!=length(l2))
    {
      stop("length(t2) must equal length(l2)")
    }
    if (dim(g)[1]!=dim(g)[2])
    {
      stop("dimensions of link graph g must match!")
    }
    ng<-dim(g)[1]
    ne<-c(m1,m2)

  }


  # #################################################
  # compute distance
  # #################################################
  a<-rep(0,ne[1])
  b<-rep(0,ne[2])
  d_out<-.C("geo_dist_in",k1=as.integer(m1),k2=as.integer(m2),t1=as.integer(t1),t2=as.integer(t2),
            l1=as.double(l1),l2=as.double(l2),g=as.integer(g),n=as.integer(ng),a=as.integer(a),b=as.integer(b),d=double(1))


  # #################################################
  # organize output
  # #################################################
  #out$d<-d_out$d
  #out$a<-a
  #out$a<-b
  #out$g<-g
  #return(mi_out)
  return(d_out)
}
