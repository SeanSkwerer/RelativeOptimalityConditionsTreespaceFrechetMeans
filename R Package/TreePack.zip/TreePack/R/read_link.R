#' @export
read_link<-function(filestr)
{
  err_out_matrix<-matrix(-1,1,1)
  #0. check input
  #1. read data
  #2. return data
  if (!is.character(filestr))
  {
    print("intput must be a character string")
    return(err_out_matrix)
  }
  con <- file(filestr)
  open(con);
  current.line <- 1
  line <- readLines(con, n = 1, warn = FALSE)
  current.line <- current.line + 1
  ng=as.numeric(unlist(strsplit(line, split="\\s+")))
  if (length(ng)>1)
  {
    print("first line of file must contain only the size of the link graph")
    return(err_out_matrix)
  }
  g<-matrix(0,ng,ng)
  while (length(line <- readLines(con, n = 1, warn = FALSE)) > 0) {
    p <- as.numeric(unlist(strsplit(line, split="\\s+")))
    if (length(p)!=2||p[1]<1||p[1]>ng||p[2]<1||p[2]>ng)
    {
      print("each line beyond the first must contain only one pair of indexes between 1 and n, indicating a connection in the link graph")
      return(err_out_matrix)
    }
    g[p[1],p[2]]=1
    g[p[2],p[1]]=1
    current.line <- current.line + 1
  }
  for (i in 1:ng)
  {
    g[i,i]=1
  }
  return(g)
}

#' @export
read_link_trees_index<-function(filestr_link,filestr_trees)
{
  out<-c()
  forest<-read_forest(filestr_trees)
  out$ne=lengths(forest$t)
  out$ti<-c()
  out$trl<-c()
  sm=c(0,cumsum(out$ne))+1
  for (i in 1:forest$n)
  {
    out$ti[sm[i]:(sm[i+1]-1)]<-forest$t[[i]]-1
    out$trl[sm[i]:(sm[i+1]-1)]<-forest$l[[i]]
  }
  #out$trl=forest$l
  #out$ti=forest$t
  out$g<-read_link(filestr_link)
  out$ng=dim(out$g)[1]
  out$n=forest$n
  out$mx=out$ng
  return(out)
}
