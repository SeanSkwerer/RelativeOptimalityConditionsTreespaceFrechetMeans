print_forest_fancy<-function()
{

}


#' @export
print_link_fancy<-function(lnk,file_name)
{
  # lnk is output from make_link_graph


  #  - leaf edges will not be included in any printed information
  # 1. print list of edge labels with associated splits
  # 2. print trees as matrix of splits with edge labels
  # 3. print compatilibity graph

  # index of tree containing edge is given in gt
  # index of edge in tree is given in gte
  # how to get split for edge?
  #     "convert_edge"<-function(t,e)

  # Output options
  # How to print to arbitrary output stream?



  # example for how to get a split
  t0 = lnk$t[1:lnk$nt[1]]
  e0 = convert_edge(t0,2)$a

  # print the split for each edge in each tree
  ce=1
  ts=cumsum(c(1,lnk$nt))
  for (i in 1:lnk$n)
  {
    print(paste("Tree",i))
    for (j in 1:lnk$ne[i])
    {
      print(paste(lnk$ti[ce]+1,":"))
      ix = lnk$ti[ce]+1
      print(convert_edge(lnk$t[(ts[lnk$gt[ix]+1]):ts[lnk$gt[ix]+2]-1],lnk$gte[ix])$a)
      ce = ce+1
    }
  }


  # print the distinct splits in the forest
  for (i in 1:lnk$ngd)
  {
    print(i)
    print(convert_edge(  lnk$t[  ts[lnk$gt[i]+1]:(ts[lnk$gt[i]+2]-1)  ],lnk$gte[i])$a)
  }
  # print the link graph
  ci0=1
  ci=ci0+lnk$ng
  for (i in 0:lnk$ng)
  {
    if (i>0)
    {
      print(paste(lnk$g[ci0:(ci-1)]))
      ci0=ci
      ci=ci+lnk$ng
    } else {
     print(paste(1:lnk$ngd))
    }
  }

}


print_geodesic_fancy<-function(t1,t2)
{

}

print_frechet_function_fancy<-function()
{

}

print_gradient_function_fancy<-function()
{

}

print_directional_deriv_function_fancy<-function()
{

}


