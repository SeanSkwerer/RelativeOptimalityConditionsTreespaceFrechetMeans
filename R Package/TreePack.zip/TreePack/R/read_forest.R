
#' @export
read_forest<-function(filestr)
{
  out<-read_tree(filestr)
  forest<-c()
  #forest$err<-(-1)
  forest$n<-length(out)/2
  if (forest$n!=round(forest$n))
  {
    #forest$err<-"file contents is not valid. the number of lines is not even."
    stop("file contents is not valid. the number of lines is not even.")
  }
  forest$t<-c()
  forest$l<-c()
  for (i in 1:forest$n)
  {
    forest$t[[i]]<-out[[2*i-1]]
    forest$l[[i]]<-out[[2*i]]
  }
  return(forest)
}
