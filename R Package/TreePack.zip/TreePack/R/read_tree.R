#' @export
read_tree<-function(filestr)
{
  results.list <- list();
  #0. check input
  #1. read data
  #2. return data
  if (!is.character(filestr))
  {
    print("intput must be a character string")
    return(results.list)
  }
  con <- file(filestr)
  open(con);
  current.line <- 1
  while (length(line <- readLines(con, n = 1, warn = FALSE)) > 0) {
    results.list[[current.line]] <- as.numeric(unlist(strsplit(line, split="\\s+")))
    current.line <- current.line + 1
  }
  close(con)
  return(results.list)
}
