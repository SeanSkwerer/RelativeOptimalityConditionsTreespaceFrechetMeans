# define forest object
# fields:
# n
# t
# l
# m

e_count<-function(x){sum(x==-1)}

#' @export
check_input<-function(forest,k,step_sequence)
{
  # #################################################
  # check input
  # #################################################
  if (! is.element("n", names(forest)))
  {
    stop("forest is missing attribute n!")
  }
  else
  {
    if (!is.numeric(forest$n))
    {
      stop("forest$n is not numeric!")
    }
    if (forest$n%%1!=0)
    {
      stop("forest$n is not a whole number!")
    }
    if (forest$n!=length(forest$t))
    {
      stop("forest$n is not equal to the number of trees in this forest!")
    }
    if (forest$n==0)
    {
      stop("forest is empty so there are no computations to do :(")
    }
    if (length(step_sequence)!=k)
    {
      stop("length(step_sequence)!=k")
    }
  }

}

#' \code{make_link_graph}
#' Uses trees represented in Newick Format to create a link graph
#' and represent trees as combinations of vertices of the link.
#' @param forest data structure for a forest
#' @return Link graph which represents region of treespace occupied b
#'          trees in this forest.
#'          Trees are represented as a sequence of integers
#'          that index vertices of the link graph.
#' @export
#' @useDynLib TreePack
make_link_graph<-function(forest)
{
  # #################################################
  # make link graph
  # #################################################
  tm0 = proc.time()
  mx<-sum(forest$t[[1]]>-1)*2-3
  n<-forest$n
  nt = unlist(lapply(forest$t,length))
  ne = unlist(lapply(forest$t,e_count))

  # count unique edges
  ngd0<-sum(ne)
  t<-as.integer(unlist(forest$t))
  l_list = unlist(forest$l)
  t_set_up = proc.time()-tm0
  print(paste('time for set up',t_set_up[1]))

  tm0 = proc.time()
  distinct_edges_out<-.C("distinct_edges",n=as.integer(n),nt=as.integer(nt),t=as.integer(t),ne=as.integer(ne),
                         mx=as.integer(mx),ng=integer(1),
                         gt=as.integer(rep(0,ngd0)),gte=as.integer(rep(0,ngd0)),ti=as.integer(rep(0,ngd0)))
  t_distinct_edges = proc.time()-tm0
  print(paste('time for distinct edges',t_distinct_edges[1]))

  ngd<-distinct_edges_out$ng
  gd<-rep(0,ngd*ngd)
  ngdi<-rep(0,ngd)
  g<-rep(0,ngd*ngd)
  #gt<-rep(0,ngd)
  #gte<-rep(0,ngd)
  #ti<-rep(0,ngd0)
  #void make_link(int *n_in, int* nt, int* t, int *ne,
  #               int *max_in, int *ngd, int *gd, int *ngdi, int* g, int *ng,
  #               int *gt, int *gte, int* ti)
  tm0 = proc.time()
  make_link_out<-.C("make_link",n=as.integer(n),nt=as.integer(nt),t=as.integer(t),ne=as.integer(ne),
                    mx=as.integer(mx),ngd=as.integer(ngd),gd=as.integer(gd),ngdi=as.integer(ngdi),g=as.integer(g),ng=integer(1),
                    gt=distinct_edges_out$gt,gte=distinct_edges_out$gte,ti=distinct_edges_out$ti)
  t_make_link = proc.time()-tm0
  print(paste('time for link core',t_make_link[1]))

  make_link_out$trl<-l_list
  make_link_out$distinct_edges_out<-distinct_edges_out
  return(make_link_out)
}

make_link_graph_old<-function(forest)
{
  # #################################################
  # make link graph
  # #################################################
  mx<-sum(forest$t[[1]]>-1)*2-3
  n<-forest$n
  nt<-c()
  for (i in 1:n)
  {
    nt<-c(nt,length(forest$t[[i]]))
  }
  ne<-c()
  for (i in 1:n)
  {
    ne<-c(ne,sum(forest$t[[i]]==-1))
  }
  # count unique edges
  #  void distinct_edges(int *n_in, int* nt, int* t, int *ne,
  #                       int *max_in, int *ng,
  #                       int *gt, int *gte, int* ti)
  ngd0<-sum(ne)
  t_list<-c()
  l_list<-c()
  tm0 = proc.time()
  for (i in 1:n)
  {
    t_list<-c(t_list,forest$t[[i]])
    l_list<-c(l_list,forest$l[[i]])
  }
  t<-as.integer(t_list)
  t_convert_forest_list = proc.time()-tm0
  print(paste('convert forest to list',t_convert_forest_list[2]))

  tm0 = proc.time()
  distinct_edges_out<-.C("distinct_edges",n=as.integer(n),nt=as.integer(nt),t=as.integer(t),ne=as.integer(ne),
                         mx=as.integer(mx),ng=integer(1),
                         gt=as.integer(rep(0,ngd0)),gte=as.integer(rep(0,ngd0)),ti=as.integer(rep(0,ngd0)))
  t_distinct_edges = proc.time()-tm0
  print(paste('time for distinct edges',t_distinct_edges[2]))

  ngd<-distinct_edges_out$ng
  gd<-rep(0,ngd*ngd)
  ngdi<-rep(0,ngd)
  g<-rep(0,ngd*ngd)
  #gt<-rep(0,ngd)
  #gte<-rep(0,ngd)
  #ti<-rep(0,ngd0)
  #void make_link(int *n_in, int* nt, int* t, int *ne,
  #               int *max_in, int *ngd, int *gd, int *ngdi, int* g, int *ng,
  #               int *gt, int *gte, int* ti)
  tm0 = proc.time()
  make_link_out<-.C("make_link",n=as.integer(n),nt=as.integer(nt),t=as.integer(t),ne=as.integer(ne),
                    mx=as.integer(mx),ngd=as.integer(ngd),gd=as.integer(gd),ngdi=as.integer(ngdi),g=as.integer(g),ng=integer(1),
                    gt=distinct_edges_out$gt,gte=distinct_edges_out$gte,ti=distinct_edges_out$ti)
  t_make_link = proc.time()-tm0
  print(paste('time for link core',t_make_link[2]))

  make_link_out$trl<-l_list
  make_link_out$distinct_edges_out<-distinct_edges_out
  return(make_link_out)
}

#' \code{inductive_mean}
#' A simple iterative algorithm for approximating the Fr'echet mean.
#'
#' @param forest is a set of trees in Newick Format
#' @param k number of iterations
#' @param step_sequence of integers from 1 to forest$n indicating which tree
#'        to use at each iteration
#'
#' @return inductive mean tree
#' @export
#' @useDynLib TreePack
inductive_mean<-function(forest,k,step_sequence=rep(1:forest$n,ceiling(k/forest$n))[1:k],keep.last.k=1,make_link_out=NA,
                         start = NA,t0=NA,l0=NA,i0=0)
{
  check_input(forest,k,step_sequence)
  nst<-c()
  #start<-step_sequence[1]
  v<-c()
  tt<-c()
  trl<-c()
  mx<-c()
  #print(t0)
  #print(l0)

  inductive_mean_out<-c()
  if (any(is.na(make_link_out)) ){make_link_out<-make_link_graph(forest)}

  nst<-c(1,cumsum(make_link_out$ne)+1)

  k_start=0
  if (is.na(t0) || is.na(l0))
  {
    if (is.na(start))
    {
      k_start=1
      start<-step_sequence[1]
    }
    v<-(nst[start]:(nst[start+1]-1) )
    t0<-make_link_out$ti[v]
    l0<-forest$l[[start]]
  }
  k0=length(t0)



      # copy t0, l0 from ti based on first index in step_sequence, and assign length of t0 to k0.
      tt<-sum(make_link_out$ne)
      trl<-vector(mode="double",length = tt)
      tt<-0
      for (i in 1:forest$n)
      {
        trl[(tt+1):(tt+make_link_out$ne[i])]<-forest$l[[i]]
        tt<-tt+make_link_out$ne[i]
      }
      mx<-sum(forest$t[[1]]>-1)*2-3
      g<-matrix(make_link_out$g,make_link_out$ngd,make_link_out$ngd)[1:make_link_out$ng,1:make_link_out$ng]
      # #################################################
      # call inductive mean c function
      # #################################################
      inductive_mean_out<-.C("inductive_mn",i0=as.integer(i0),m=as.integer(max(make_link_out$ne)),k=as.integer(k),
                             seq=as.integer(step_sequence[k_start:length(step_sequence)]-1),
                             n=as.integer(forest$n),ne=as.integer(make_link_out$ne),ti=as.integer(make_link_out$ti),trl=as.double(trl),
                             t0=as.integer(t0),l0=as.double(l0),k0=as.integer(k0),ng=as.integer(make_link_out$ng),
                             g=as.integer(g),
                             kk=integer(1),tt=integer(mx),ll=double(sum(forest$t[[1]]>-1)*2-3),
                             kk1=integer(1),tt1=integer(mx),ll1=double(sum(forest$t[[1]]>-1)*2-3),
                             keep.last.k=as.integer(keep.last.k),last.k.n=integer(keep.last.k),last.k.i=integer(keep.last.k),
                             last.k.t=integer(keep.last.k*mx),last.k.l=double(keep.last.k*mx),
                             mx=as.integer(mx))



  # make_link_out<-.C("make_link",n=as.integer(n),nt=as.integer(nt),t=as.integer(t),ne=as.integer(ne),
  #                   max=as.integer(mx),ngd=as.integer(ngd),gd=as.integer(gd),ngdi=as.integer(ngdi),g=as.integer(g),ng=integer(1),
  #                   gt=distinct_edges_out$gt,gte=distinct_edges_out$gte,ti=distinct_edges_out$ti)


  inductive_mean_out$last.k.t<-matrix(inductive_mean_out$last.k.t,mx,keep.last.k);
  inductive_mean_out$last.k.l<-matrix(inductive_mean_out$last.k.l,mx,keep.last.k);

  return(inductive_mean_out)
}


#' @export
#' @useDynLib TreePack
orthantOpt<-function(link_forest,t0,l0,eps0=10^-5,del=10^-7,option='steepst',norm=1)
{

  # void  orthantOpt_in(int* ng, int* g, int *nx, int *ox, double *xl, int *n, int* trn,
  #                     int* tr, double* trl, int *tra,
  #                     int *m, double *eps0,  double *del,
  #                     int *k, int* kx, double *x0,
  #                     int *sm, int* A, int* B, int *active, double *p, double *gr, double *pr, double *eps,
  #                     int *a1, int *b1, int *i1, int *i2, int* g0, int *g1, // storage for input to phylo_tree_geo_no_alloc
  #                     int *a, int *b, int *t1, int *t2, double *l1, double *l2, int *tt2, int *lev_i) // storage for relevant edges
  nx=length(t0)
  m=link_forest$mx
  if (identical(option,'steepst'))
  {
  }
  if (identical(option,'Nesterov'))
  {

  }
  vsd = 0
    opt_out<-.C("orthantOpt_in",ng=as.integer(link_forest$ng),g=as.integer(link_forest$g),nx=as.integer(nx),ox=as.integer(t0),xl=as.double(l0),
                             n=as.integer(link_forest$n),trn=as.integer(link_forest$ne),
                              tr=as.integer(link_forest$ti), trl=as.double(link_forest$trl), tra=integer(length(link_forest$trl)),
                              m=as.integer(m),eps0=as.double(eps0),del=as.double(del),
                              k=integer(1),kx=integer(nx), x0=double(nx),
                              sm=as.integer(cumsum(link_forest$ne)),A=integer(nx*link_forest$n), B=integer(sum(lengths(link_forest$ti))),
                              active=integer(nx),p=double(nx),gr=double(nx),pr=double(nx),eps=double(nx+1),
                              a1=integer(m),b1=integer(m),i1=integer(m),i2=integer(m),g0=integer(link_forest$ng^2),g1=integer(link_forest$ng^2),
                              a=integer(m),b=integer(m),t1=integer(m),t2=integer(m),l1=double(m),l2=double(m),tt2=integer(m),lev_i=integer(m),
                             norm=as.integer(norm),tkn=as.integer(link_forest$nt),tk=as.integer(link_forest$t),
                              gt=as.integer(link_forest$gt),gte=as.integer(link_forest$gte))

  return(opt_out)
}

#' @export
#' @useDynLib TreePack
fss<-function(link_forest,t,l)
{
 #FSS_c(int* k_in, int* t, double* l, int* n_in, int* trn, int* tr, double* trl, int* g, int* ng_in, int* m_in, double* ss)
 fss_out = .C("FSS_c",k=as.integer(length(t)),t=as.integer(t),l=as.double(l),n_in=as.integer(link_forest$n), trn = as.integer(link_forest$ne),
              tr=as.integer(link_forest$ti),trl=as.double(link_forest$trl),
              g=as.integer(link_forest$g),ng_in=as.integer(link_forest$ng),m_in=as.integer(link_forest$mx),ss=double(1))
 return(fss_out$ss)
}

greedyCliques<-function()
{

}
