
#' @export
#' @useDynLib TreePack
"min_weight_cover"<-function(bigraph,w1,w2)
{

  ######################################################
  # check input
  ######################################################
  n1<-dim(bigraph)[1]
  n2<-dim(bigraph)[2]
  if (!is.numeric(bigraph))
  {
    stop("bigraph must be numeric!")
  }
  if (!is.numeric(w1))
  {
    stop("w1 must be numeric")
  }
  if (!is.numeric(w2))
  {
    stop("w2 must be numeric")
  }
  for (i in 1:n1)
  {
    for (j in 1:n2)
    {
      if (!(bigraph[i,j]==1 || bigraph[i,j]==0))
      {
        stop("bigraph must be a matrix of 0 and 1")
      }
    }
  }
  if (length(w1)!=n1)
  {
    stop("length(w1) must equal dim(bigraph)[1]")
  }
  if (length(w2)!=n2)
  {
    stop("length(w2) must equal dim(bigraph)[2]")
  }

  ######################################################
  # create g0, gg1, gn1, gg2, gn2
  ######################################################
  g0<-matrix(0,1,n1*n2)
  gg1<-matrix(0,1,n1*n2)
  gg2<-matrix(0,1,n1*n2)
  gn1<-matrix(0,1,n1)
  gn2<-matrix(0,1,n2)
  for (i in 1:n1)
  {
    for (j in 1:n2)
    {
      g0[(i-1)*n2+j]<-bigraph[i,j]
      if (bigraph[i,j]==1)
      {
        gn1[i]<-gn1[i]+1
        gg1[(i-1)*n2+gn1[i]]<-j-1
        gn2[j]<-gn2[j]+1
        gg2[(j-1)*n1+gn2[j]]<-i-1
      }
    }
  }
  ######################################################
  # call min_weight_cover
  ######################################################
  out<-.C("min_weight_cover_in", n1=as.integer(n1), n2=as.integer(n2), g=as.integer(g0), gg1=as.integer(gg1), gn1=as.integer(gn1),gg2=as.integer(gg2), gn2=as.integer(gn2),
              w1=as.double(w1),w2=as.double(w2),x=double(n1*n2),x1=double(n1),x2=double(n2),c1=integer(n1),c2=integer(n2),nc1=integer(1),nc2=integer(1))
  out$c1<-out$c1+1;
  out$c2<-out$c2+1;
  c<-0.0
  if (out$nc1>0)
  {
    for (i in 1:out$nc1)
    {
      c<-c+w1[out$c1[i]]
    }
  }
  if (out$nc2>0)
  {
    for (i in 1:out$nc2)
    {
      c<-c+w2[out$c2[i]]
    }
  }
  out$c<-c

  #min_weight_cover(int *n1_in, int *n2_in, int *g, int *gg1, int *gn1, int *gg2, int *gn2,
  #                 double *u1, double *u2, double *x, double *x1, double* x2, int *c1, int *c2, int *nc1, int *nc2)

  return(out)
}
