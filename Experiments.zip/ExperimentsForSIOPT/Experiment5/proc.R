# Experiment 5
#
# Goal
# Demonstrate that orthant optimization provides faster local convergence than split proximal point algorithms.
#
#
#
# Procedure
# 1. run inductive mean algorithm for global search to get $X_0$
# 2. a. from $X_0$ continue with inductive mean
#    b. from $X_0$ start orthant optimization
#

# Data
# Symmetric distribution on $\T_30$ around a tree with 8 internal edges collapsed.
# directory for data /Users/sean/Dropbox (Personal)/FM/data/fm/...
#
# sample size 1000

require(TreePack)

filepath = '/Users/sean/Dropbox (Personal)/FM/data/fm/leafs30/settings2/ex1t.tpk'
forest<-read_forest(filepath)


ptm_lnk0 = proc.time()
lnk<-make_link_graph(forest)
ptm_lnk1 = proc.time()-ptm_lnk0
print(paste("Time for link:",ptm_lnk1[1]))



ptm0  = proc.time()
k1=forest$n*10
im1=inductive_mean(forest,k1,make_link_out=lnk)
ptm1 = proc.time()-ptm0

K=k1
ssq=c()
N=50
ptm_im = numeric(length=N)
for (k in 1:N)
{
  ptm_im2_0  = proc.time()
  k2=forest$n*1
  im2=inductive_mean(forest,k2,make_link_out=lnk,t0=im1$tt1[1:im1$kk1],l0=im1$ll1[1:im1$kk1],i0=K)
  ptm_im2 = proc.time()-ptm_im2_0
  ptm_im[k] = ptm_im2[1]
  ssq[k] = fss(lnk,im2$tt1[1:im2$kk1],im2$ll1[1:im2$kk1])
  K=K+k2
}

ptm_oo0 = proc.time()
oo1=orthantOpt(link_forest=lnk,t0=im1$tt1[1:im1$kk1],l0=im1$ll1[1:im1$kk1],eps0 = 0.00000001,del = 0.0000001)
ptm_oo = proc.time()-ptm_oo0



# compute fss
ss=c()
ss$im1 = fss(lnk,im1$tt1[1:im1$kk1],im1$ll1[1:im1$kk1])
ss$oo1 = fss(lnk,oo1$ox[oo1$kx==0],oo1$xl[oo1$kx==0])

print(paste("Time for inductive mean:",ptm1[1]))
print(paste("Time for inductive mean sequence:",ptm_im))
print(paste("Time for orthant optimization:",ptm_oo[1]))
print(sum(ptm_im))

print(ss)
print(ssq[N])
print(ssq[N]-ss$oo1)

print(im1$kk1)
print(im2$kk1)
print(sum(oo1$kx==0))

plot(cumsum(ptm_im),ssq)

